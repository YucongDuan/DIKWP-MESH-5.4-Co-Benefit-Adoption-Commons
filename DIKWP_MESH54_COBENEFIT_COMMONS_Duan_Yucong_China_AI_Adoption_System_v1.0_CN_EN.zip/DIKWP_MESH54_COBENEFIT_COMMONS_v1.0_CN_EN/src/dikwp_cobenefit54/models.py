from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class InstitutionalActor54:
    actor_id: str
    label: str
    role: str
    organization_id: str
    decision_rights: list[str]
    benefits_sought: list[str]
    burdens_feared: list[str]
    resources_at_risk: list[str]
    public_commitments: list[str]
    affected_party: bool
    evidence_hashes: list[str]
    actor_hash: str


@dataclass(frozen=True)
class InstitutionalThreatSignal54:
    signal_id: str
    actor_id: str
    kind: str
    severity: float
    visibility: str
    evidence_refs: list[str]
    interpretation_limits: list[str]
    mitigation_candidates: list[str]
    signal_hash: str


@dataclass(frozen=True)
class TransitionCostMap54:
    map_id: str
    scenario_id: str
    job_transition_cost: float
    authority_transition_cost: float
    budget_transition_cost: float
    liability_transition_cost: float
    workflow_transition_cost: float
    public_face_cost: float
    learning_cost: float
    data_compliance_cost: float
    total_cost: float
    unresolved_items: list[str]
    protected_groups: list[str]
    map_hash: str


@dataclass(frozen=True)
class CoBenefitClause54:
    clause_id: str
    beneficiary_ids: list[str]
    benefit: str
    burden: str
    compensation_or_support: str
    metric: str
    review_time: int
    reversible: bool
    clause_hash: str


@dataclass(frozen=True)
class CoBenefitCovenant54:
    covenant_id: str
    scenario_id: str
    purpose_statement: str
    clauses: list[CoBenefitClause54]
    anti_intents: list[str]
    credit_rules: list[str]
    no_retaliation_rules: list[str]
    correction_rules: list[str]
    appeal_paths: list[str]
    rollback_conditions: list[str]
    open_obligations: list[str]
    mesh54_intent_covenant_hash: str
    covenant_hash: str


@dataclass(frozen=True)
class DecisionRightsMatrix54:
    matrix_id: str
    scenario_id: str
    human_only_decisions: list[str]
    human_authorized_agent_decisions: list[str]
    low_risk_agent_decisions: list[str]
    prohibited_decisions: list[str]
    escalation_owner: str
    appeal_owner: str
    matrix_hash: str


@dataclass(frozen=True)
class PilotCell54:
    pilot_id: str
    scenario_id: str
    stage: str
    scope: list[str]
    excluded_scope: list[str]
    data_classification: str
    human_final_control: bool
    generated_content_labeling: bool
    rollback_available: bool
    appeal_available: bool
    independent_witness_required: bool
    duration_days: int
    success_metrics: list[str]
    kill_conditions: list[str]
    pilot_hash: str


@dataclass(frozen=True)
class CorrectionTicket54:
    ticket_id: str
    scenario_id: str
    issue_type: str
    evidence_refs: list[str]
    immediate_safety_action: str
    private_review_path: str
    public_process_statement: str
    personal_blame_prohibited: bool
    correction_deadline_days: int
    status: str
    ticket_hash: str


@dataclass(frozen=True)
class ContributionCreditReceipt54:
    receipt_id: str
    scenario_id: str
    contributor_id: str
    contribution_type: str
    artifact_hashes: list[str]
    verified_by: list[str]
    credit_scope: list[str]
    reuse_conditions: list[str]
    dispute_path: str
    receipt_hash: str


@dataclass(frozen=True)
class EvidenceEscrow54:
    escrow_id: str
    scenario_id: str
    evidence_hashes: list[str]
    access_roles: list[str]
    release_triggers: list[str]
    retention_days: int
    split_view_protection: bool
    deletion_prohibited: bool
    escrow_hash: str


@dataclass(frozen=True)
class NoRetaliationCovenant54:
    covenant_id: str
    scenario_id: str
    protected_actions: list[str]
    prohibited_responses: list[str]
    confidential_channels: list[str]
    independent_reviewers: list[str]
    remedies: list[str]
    expiry_days: int
    covenant_hash: str


@dataclass(frozen=True)
class InstitutionalChart54:
    chart_id: str
    actor_id: str
    interpretation_vector: list[float]
    decision_rights: list[str]
    evidence_confidence: float
    chart_status: str
    open_residuals: list[str]
    chart_hash: str


@dataclass(frozen=True)
class InstitutionalSeam54:
    seam_id: str
    source_chart_id: str
    target_chart_id: str
    translation_error: float
    contested_dimensions: list[str]
    reversible: bool
    status: str
    seam_hash: str


@dataclass(frozen=True)
class InstitutionalLoop54:
    loop_id: str
    chart_ids: list[str]
    seam_ids: list[str]
    holonomy_error: float
    semantic_curvature: float
    status: str
    loop_hash: str


@dataclass(frozen=True)
class InstitutionalAtlas54:
    atlas_id: str
    scenario_id: str
    dimensions: list[str]
    charts: list[InstitutionalChart54]
    seams: list[InstitutionalSeam54]
    loops: list[InstitutionalLoop54]
    max_holonomy_error: float
    max_translation_error: float
    open_obligations: list[str]
    status: str
    atlas_hash: str


@dataclass(frozen=True)
class AdoptionGateVerdict54:
    verdict_id: str
    scenario_id: str
    gate: str
    reasons: list[str]
    required_actions: list[str]
    evidence_grade: str
    mesh54_status: str
    independent_witness_status: str
    reciprocity_status: str
    split_view_detected: bool
    issued_at: int
    verdict_hash: str


@dataclass(frozen=True)
class PilotOutcome54:
    outcome_id: str
    scenario_id: str
    gate: str
    public_value_score: float
    user_control_score: float
    institutional_fit_score: float
    evidence_score: float
    contribution_protection_score: float
    correction_quality_score: float
    residual_risk_score: float
    observed_failures: list[str]
    learned_changes: list[str]
    next_action: str
    outcome_hash: str


@dataclass(frozen=True)
class InstitutionalLearningRelease54:
    release_id: str
    version: str
    scenario_count: int
    gate_counts: dict[str, int]
    approved_pilot_ids: list[str]
    held_or_blocked_ids: list[str]
    kill_events: list[str]
    credit_receipt_count: int
    open_obligations: list[str]
    ledger_head: str
    evidence_hashes: list[str]
    release_hash: str


@dataclass
class ScenarioAssessment54:
    scenario: dict[str, Any]
    actors: list[InstitutionalActor54] = field(default_factory=list)
    threats: list[InstitutionalThreatSignal54] = field(default_factory=list)
    transition_cost: TransitionCostMap54 | None = None
    atlas: InstitutionalAtlas54 | None = None
    co_benefit_covenant: CoBenefitCovenant54 | None = None
    decision_rights: DecisionRightsMatrix54 | None = None
    pilot: PilotCell54 | None = None
    corrections: list[CorrectionTicket54] = field(default_factory=list)
    credits: list[ContributionCreditReceipt54] = field(default_factory=list)
    evidence_escrow: EvidenceEscrow54 | None = None
    no_retaliation: NoRetaliationCovenant54 | None = None
    verdict: AdoptionGateVerdict54 | None = None
    outcome: PilotOutcome54 | None = None
    mesh54_evidence: dict[str, Any] = field(default_factory=dict)
