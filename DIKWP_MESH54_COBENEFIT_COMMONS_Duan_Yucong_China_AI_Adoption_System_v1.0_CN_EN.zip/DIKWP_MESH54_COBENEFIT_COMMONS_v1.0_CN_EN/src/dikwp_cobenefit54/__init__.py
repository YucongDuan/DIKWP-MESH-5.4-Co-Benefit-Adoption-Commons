"""DIKWP-MESH 5.4 Co-Benefit Commons reference runtime."""

__version__ = "1.0.0"

from .runtime import CoBenefitRuntime54

__all__ = ["CoBenefitRuntime54", "__version__"]
