from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .utils import sha256_obj, to_builtin

ZERO_HASH = "0" * 64


class AppendOnlyLedger54:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def records(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        return [json.loads(line) for line in self.path.read_text(encoding="utf-8").splitlines() if line.strip()]

    def verify(self) -> dict[str, Any]:
        previous = ZERO_HASH
        reasons = []
        records = self.records()
        for index, record in enumerate(records):
            if record.get("index") != index:
                reasons.append(f"index mismatch at {index}")
                break
            if record.get("previous_hash") != previous:
                reasons.append(f"previous hash mismatch at {index}")
                break
            body = {k: v for k, v in record.items() if k != "record_hash"}
            expected = sha256_obj(body)
            if record.get("record_hash") != expected:
                reasons.append(f"record hash mismatch at {index}")
                break
            previous = expected
        report = {
            "valid": not reasons,
            "records": len(records),
            "head_hash": previous if records else ZERO_HASH,
            "reasons": reasons,
        }
        report["report_hash"] = sha256_obj(report)
        return report

    def append(self, event_type: str, payload: Any, logical_time: int) -> dict[str, Any]:
        verification = self.verify()
        if not verification["valid"]:
            raise ValueError("cannot append to invalid ledger")
        records = self.records()
        body = {
            "index": len(records),
            "logical_time": int(logical_time),
            "event_type": str(event_type),
            "payload_hash": sha256_obj(payload),
            "previous_hash": verification["head_hash"],
        }
        record = {**body, "record_hash": sha256_obj(body)}
        with self.path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(to_builtin(record), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        return record
