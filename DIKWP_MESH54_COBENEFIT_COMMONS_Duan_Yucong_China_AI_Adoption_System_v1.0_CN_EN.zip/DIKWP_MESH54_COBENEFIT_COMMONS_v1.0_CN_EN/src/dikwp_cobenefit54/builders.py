from __future__ import annotations

from dataclasses import replace
from itertools import combinations
from typing import Any

from .models import (
    CoBenefitClause54,
    CoBenefitCovenant54,
    ContributionCreditReceipt54,
    CorrectionTicket54,
    DecisionRightsMatrix54,
    EvidenceEscrow54,
    InstitutionalActor54,
    InstitutionalAtlas54,
    InstitutionalChart54,
    InstitutionalLoop54,
    InstitutionalSeam54,
    InstitutionalThreatSignal54,
    NoRetaliationCovenant54,
    PilotCell54,
    TransitionCostMap54,
)
from .utils import clamp, normalized_mean, sha256_obj


ATLAS_DIMENSIONS = [
    "public_value",
    "decision_control",
    "budget_continuity",
    "status_and_credit",
    "liability_exposure",
    "workflow_burden",
    "data_and_compliance",
    "employment_transition",
    "reversibility",
    "evidence_confidence",
]


def _hash_dataclass(prefix: str, body: dict[str, Any]) -> tuple[str, str]:
    digest = sha256_obj(body)
    return f"{prefix}-{digest[:14]}", digest


def build_actor54(spec: dict[str, Any], evidence_hashes: list[str]) -> InstitutionalActor54:
    body = {
        "label": spec["label"],
        "role": spec["role"],
        "organization_id": spec["organization_id"],
        "decision_rights": sorted(spec.get("decision_rights", [])),
        "benefits_sought": sorted(spec.get("benefits_sought", [])),
        "burdens_feared": sorted(spec.get("burdens_feared", [])),
        "resources_at_risk": sorted(spec.get("resources_at_risk", [])),
        "public_commitments": sorted(spec.get("public_commitments", [])),
        "affected_party": bool(spec.get("affected_party", False)),
        "evidence_hashes": sorted(set(evidence_hashes)),
    }
    actor_id, digest = _hash_dataclass("IA54", body)
    return InstitutionalActor54(actor_id=actor_id, actor_hash=digest, **body)


def build_threat_signals54(actor: InstitutionalActor54, scenario: dict[str, Any]) -> list[InstitutionalThreatSignal54]:
    weights = scenario.get("threat_weights", {})
    mapping = {
        "job_transition": ("employment or role transition", actor.burdens_feared, ["role redesign", "training", "redeployment"]),
        "authority_transition": ("decision-right transition", actor.decision_rights, ["decision-right matrix", "human final control"]),
        "budget_transition": ("budget and resource transition", actor.resources_at_risk, ["shared savings rule", "transition budget"]),
        "credit_transition": ("credit, authorship and status transition", actor.resources_at_risk, ["contribution receipt", "public credit rule"]),
        "liability_transition": ("liability transfer", actor.burdens_feared, ["named responsibility owner", "appeal and rollback"]),
        "public_face": ("public embarrassment or blame exposure", actor.burdens_feared, ["dignity-preserving correction", "process-not-person statement"]),
        "data_compliance": ("data and compliance exposure", actor.burdens_feared, ["data classification", "evidence escrow"]),
        "workflow_transition": ("workflow and learning burden", actor.burdens_feared, ["shadow mode", "time-boxed training"]),
    }
    result: list[InstitutionalThreatSignal54] = []
    for kind, (label, source_items, mitigations) in mapping.items():
        severity = clamp(float(weights.get(kind, 0.0)))
        if severity <= 0.0:
            continue
        body = {
            "actor_id": actor.actor_id,
            "kind": kind,
            "severity": severity,
            "visibility": "DECLARED" if scenario.get("declared_transition_costs", True) else "LATENT_UNVERIFIED",
            "evidence_refs": [sha256_obj([actor.actor_hash, kind, source_items, scenario["scenario_id"]])],
            "interpretation_limits": [
                f"This signal records a transition pressure ({label}); it does not establish bad faith.",
                "Do not infer a person's motive from the score alone.",
            ],
            "mitigation_candidates": mitigations,
        }
        signal_id, digest = _hash_dataclass("TS54", body)
        result.append(InstitutionalThreatSignal54(signal_id=signal_id, signal_hash=digest, **body))
    return result


def build_transition_cost54(scenario: dict[str, Any]) -> TransitionCostMap54:
    weights = scenario.get("threat_weights", {})
    fields = {
        "job_transition_cost": clamp(weights.get("job_transition", 0.0)),
        "authority_transition_cost": clamp(weights.get("authority_transition", 0.0)),
        "budget_transition_cost": clamp(weights.get("budget_transition", 0.0)),
        "liability_transition_cost": clamp(weights.get("liability_transition", 0.0)),
        "workflow_transition_cost": clamp(weights.get("workflow_transition", 0.0)),
        "public_face_cost": clamp(weights.get("public_face", 0.0)),
        "learning_cost": clamp(weights.get("learning_cost", weights.get("workflow_transition", 0.0))),
        "data_compliance_cost": clamp(weights.get("data_compliance", 0.0)),
    }
    total = normalized_mean(list(fields.values()))
    unresolved = list(scenario.get("unresolved_transition_items", []))
    if total >= 0.65 and not unresolved:
        unresolved.append("high transition cost requires explicit co-benefit and burden-sharing plan")
    body = {
        "scenario_id": scenario["scenario_id"],
        **fields,
        "total_cost": total,
        "unresolved_items": sorted(set(unresolved)),
        "protected_groups": sorted(set(scenario.get("protected_groups", []))),
    }
    map_id, digest = _hash_dataclass("TCM54", body)
    return TransitionCostMap54(map_id=map_id, map_hash=digest, **body)


def _actor_vector(actor: InstitutionalActor54, scenario: dict[str, Any]) -> list[float]:
    base = scenario.get("actor_vectors", {}).get(actor.role, {})
    values = []
    for dim in ATLAS_DIMENSIONS:
        default = 0.5
        if dim == "public_value":
            default = 0.8 if actor.affected_party else 0.65
        elif dim == "decision_control":
            default = 0.8 if actor.decision_rights else 0.4
        elif dim == "reversibility":
            default = 0.8 if scenario.get("rollback_available", False) else 0.2
        elif dim == "evidence_confidence":
            default = float(scenario.get("evidence_confidence", 0.55))
        values.append(clamp(base.get(dim, default)))
    return values


def build_institutional_atlas54(actors: list[InstitutionalActor54], scenario: dict[str, Any]) -> InstitutionalAtlas54:
    charts: list[InstitutionalChart54] = []
    for actor in actors:
        vector = _actor_vector(actor, scenario)
        body = {
            "actor_id": actor.actor_id,
            "interpretation_vector": vector,
            "decision_rights": actor.decision_rights,
            "evidence_confidence": vector[-1],
            "chart_status": "ACTIVE" if vector[-1] >= 0.4 else "OPEN_RESIDUAL",
            "open_residuals": list(scenario.get("actor_residuals", {}).get(actor.role, [])),
        }
        chart_id, digest = _hash_dataclass("IC54", body)
        charts.append(InstitutionalChart54(chart_id=chart_id, chart_hash=digest, **body))

    seams: list[InstitutionalSeam54] = []
    chart_map = {c.actor_id: c for c in charts}
    role_map = {a.actor_id: a.role for a in actors}
    for left, right in combinations(charts, 2):
        differences = [abs(a - b) for a, b in zip(left.interpretation_vector, right.interpretation_vector)]
        error = normalized_mean(differences)
        contested = [ATLAS_DIMENSIONS[i] for i, value in enumerate(differences) if value >= 0.35]
        reversible = bool(scenario.get("rollback_available", False))
        status = "ACTIVE_SEAM" if error < 0.30 else ("OPEN_SEAM" if reversible else "BROKEN_SEAM")
        body = {
            "source_chart_id": left.chart_id,
            "target_chart_id": right.chart_id,
            "translation_error": error,
            "contested_dimensions": contested,
            "reversible": reversible,
            "status": status,
        }
        seam_id, digest = _hash_dataclass("IS54", body)
        seams.append(InstitutionalSeam54(seam_id=seam_id, seam_hash=digest, **body))

    loops: list[InstitutionalLoop54] = []
    preferred_roles = ["sponsor", "operator", "affected_party"]
    selected = []
    for role in preferred_roles:
        match = next((a for a in actors if a.role == role), None)
        if match:
            selected.append(chart_map[match.actor_id])
    if len(selected) >= 3:
        cycle = selected[:3]
        seam_lookup = {(s.source_chart_id, s.target_chart_id): s for s in seams}
        seam_lookup.update({(s.target_chart_id, s.source_chart_id): s for s in seams})
        cycle_seams = [
            seam_lookup[(cycle[0].chart_id, cycle[1].chart_id)],
            seam_lookup[(cycle[1].chart_id, cycle[2].chart_id)],
            seam_lookup[(cycle[2].chart_id, cycle[0].chart_id)],
        ]
        holonomy = normalized_mean([s.translation_error for s in cycle_seams])
        # Curvature increases when the same proposed benefit changes sign across charts.
        public_values = [c.interpretation_vector[0] for c in cycle]
        curvature = clamp((max(public_values) - min(public_values)) + holonomy * 0.5)
        status = "LOW_CURVATURE" if curvature < 0.35 else ("OPEN_CURVATURE" if curvature < 0.65 else "HIGH_CURVATURE")
        body = {
            "chart_ids": [c.chart_id for c in cycle],
            "seam_ids": [s.seam_id for s in cycle_seams],
            "holonomy_error": holonomy,
            "semantic_curvature": curvature,
            "status": status,
        }
        loop_id, digest = _hash_dataclass("IL54", body)
        loops.append(InstitutionalLoop54(loop_id=loop_id, loop_hash=digest, **body))

    max_holonomy = max((item.holonomy_error for item in loops), default=0.0)
    max_translation = max((item.translation_error for item in seams), default=0.0)
    open_obligations = list(scenario.get("open_obligations", []))
    if max_translation >= 0.30:
        open_obligations.append("stakeholder charts require explicit translation and joint review")
    if max_holonomy >= 0.35:
        open_obligations.append("institutional loop returns materially different meaning; pilot must remain reversible")
    status = "ACTIVE_OPEN_ATLAS" if max_translation < 0.65 else "QUARANTINED_ATLAS"
    body = {
        "scenario_id": scenario["scenario_id"],
        "dimensions": ATLAS_DIMENSIONS,
        "charts": charts,
        "seams": seams,
        "loops": loops,
        "max_holonomy_error": max_holonomy,
        "max_translation_error": max_translation,
        "open_obligations": sorted(set(open_obligations)),
        "status": status,
    }
    atlas_id, digest = _hash_dataclass("IAT54", body)
    return InstitutionalAtlas54(atlas_id=atlas_id, atlas_hash=digest, **body)


def build_decision_rights54(scenario: dict[str, Any]) -> DecisionRightsMatrix54:
    rights = scenario.get("decision_rights", {})
    body = {
        "scenario_id": scenario["scenario_id"],
        "human_only_decisions": sorted(rights.get("human_only", [])),
        "human_authorized_agent_decisions": sorted(rights.get("human_authorized", [])),
        "low_risk_agent_decisions": sorted(rights.get("agent_low_risk", [])),
        "prohibited_decisions": sorted(rights.get("prohibited", [])),
        "escalation_owner": rights.get("escalation_owner", "unassigned"),
        "appeal_owner": rights.get("appeal_owner", "unassigned"),
    }
    matrix_id, digest = _hash_dataclass("DRM54", body)
    return DecisionRightsMatrix54(matrix_id=matrix_id, matrix_hash=digest, **body)


def build_pilot_cell54(scenario: dict[str, Any]) -> PilotCell54:
    body = {
        "scenario_id": scenario["scenario_id"],
        "stage": scenario.get("pilot_stage", "SHADOW_RECOMMENDATION"),
        "scope": sorted(scenario.get("scope", [])),
        "excluded_scope": sorted(scenario.get("excluded_scope", [])),
        "data_classification": scenario.get("data_classification", "SYNTHETIC_OR_PUBLIC"),
        "human_final_control": bool(scenario.get("human_final_control", False)),
        "generated_content_labeling": bool(scenario.get("generated_content_labeling", False)),
        "rollback_available": bool(scenario.get("rollback_available", False)),
        "appeal_available": bool(scenario.get("appeal_available", False)),
        "independent_witness_required": bool(scenario.get("independent_witness_required", True)),
        "duration_days": int(scenario.get("duration_days", 30)),
        "success_metrics": sorted(scenario.get("success_metrics", [])),
        "kill_conditions": sorted(scenario.get("kill_conditions", [])),
    }
    pilot_id, digest = _hash_dataclass("PC54", body)
    return PilotCell54(pilot_id=pilot_id, pilot_hash=digest, **body)


def build_co_benefit_covenant54(
    scenario: dict[str, Any], transition: TransitionCostMap54, mesh54_intent_hash: str
) -> CoBenefitCovenant54:
    clauses: list[CoBenefitClause54] = []
    for index, item in enumerate(scenario.get("co_benefit_clauses", []), start=1):
        body = {
            "beneficiary_ids": sorted(item.get("beneficiary_ids", [])),
            "benefit": item.get("benefit", ""),
            "burden": item.get("burden", ""),
            "compensation_or_support": item.get("compensation_or_support", ""),
            "metric": item.get("metric", ""),
            "review_time": int(item.get("review_time", 30)),
            "reversible": bool(item.get("reversible", True)),
        }
        clause_id, digest = _hash_dataclass(f"CBC54-{index}", body)
        clauses.append(CoBenefitClause54(clause_id=clause_id, clause_hash=digest, **body))
    body = {
        "scenario_id": scenario["scenario_id"],
        "purpose_statement": scenario.get("purpose_statement", ""),
        "clauses": clauses,
        "anti_intents": sorted(scenario.get("anti_intents", [])),
        "credit_rules": sorted(scenario.get("credit_rules", [])),
        "no_retaliation_rules": sorted(scenario.get("no_retaliation_rules", [])),
        "correction_rules": sorted(scenario.get("correction_rules", [])),
        "appeal_paths": sorted(scenario.get("appeal_paths", [])),
        "rollback_conditions": sorted(scenario.get("rollback_conditions", [])),
        "open_obligations": sorted(set(scenario.get("open_obligations", []) + transition.unresolved_items)),
        "mesh54_intent_covenant_hash": mesh54_intent_hash,
    }
    covenant_id, digest = _hash_dataclass("CBC54", body)
    return CoBenefitCovenant54(covenant_id=covenant_id, covenant_hash=digest, **body)


def build_corrections54(scenario: dict[str, Any]) -> list[CorrectionTicket54]:
    result = []
    for item in scenario.get("correction_tickets", []):
        body = {
            "scenario_id": scenario["scenario_id"],
            "issue_type": item.get("issue_type", "PROCESS_DEFECT"),
            "evidence_refs": sorted(item.get("evidence_refs", [])),
            "immediate_safety_action": item.get("immediate_safety_action", "pause affected operation"),
            "private_review_path": item.get("private_review_path", "independent evidence review"),
            "public_process_statement": item.get("public_process_statement", "publish process correction without personal humiliation"),
            "personal_blame_prohibited": bool(item.get("personal_blame_prohibited", True)),
            "correction_deadline_days": int(item.get("correction_deadline_days", 14)),
            "status": item.get("status", "OPEN"),
        }
        ticket_id, digest = _hash_dataclass("CT54", body)
        result.append(CorrectionTicket54(ticket_id=ticket_id, ticket_hash=digest, **body))
    return result


def build_credits54(scenario: dict[str, Any]) -> list[ContributionCreditReceipt54]:
    result = []
    for item in scenario.get("contributions", []):
        body = {
            "scenario_id": scenario["scenario_id"],
            "contributor_id": item.get("contributor_id", "unknown"),
            "contribution_type": item.get("contribution_type", "unspecified"),
            "artifact_hashes": sorted(item.get("artifact_hashes", [])),
            "verified_by": sorted(item.get("verified_by", [])),
            "credit_scope": sorted(item.get("credit_scope", [])),
            "reuse_conditions": sorted(item.get("reuse_conditions", [])),
            "dispute_path": item.get("dispute_path", "independent credit review"),
        }
        receipt_id, digest = _hash_dataclass("CCR54", body)
        result.append(ContributionCreditReceipt54(receipt_id=receipt_id, receipt_hash=digest, **body))
    return result


def build_escrow54(scenario: dict[str, Any]) -> EvidenceEscrow54:
    body = {
        "scenario_id": scenario["scenario_id"],
        "evidence_hashes": sorted(set(scenario.get("evidence_hashes", []))),
        "access_roles": sorted(scenario.get("evidence_access_roles", [])),
        "release_triggers": sorted(scenario.get("evidence_release_triggers", [])),
        "retention_days": int(scenario.get("evidence_retention_days", 365)),
        "split_view_protection": bool(scenario.get("split_view_protection", True)),
        "deletion_prohibited": bool(scenario.get("audit_deletion_prohibited", True)),
    }
    escrow_id, digest = _hash_dataclass("EE54", body)
    return EvidenceEscrow54(escrow_id=escrow_id, escrow_hash=digest, **body)


def build_no_retaliation54(scenario: dict[str, Any]) -> NoRetaliationCovenant54:
    body = {
        "scenario_id": scenario["scenario_id"],
        "protected_actions": sorted(scenario.get("protected_actions", [])),
        "prohibited_responses": sorted(scenario.get("prohibited_responses", [])),
        "confidential_channels": sorted(scenario.get("confidential_channels", [])),
        "independent_reviewers": sorted(scenario.get("independent_reviewers", [])),
        "remedies": sorted(scenario.get("retaliation_remedies", [])),
        "expiry_days": int(scenario.get("no_retaliation_expiry_days", 365)),
    }
    covenant_id, digest = _hash_dataclass("NRC54", body)
    return NoRetaliationCovenant54(covenant_id=covenant_id, covenant_hash=digest, **body)
