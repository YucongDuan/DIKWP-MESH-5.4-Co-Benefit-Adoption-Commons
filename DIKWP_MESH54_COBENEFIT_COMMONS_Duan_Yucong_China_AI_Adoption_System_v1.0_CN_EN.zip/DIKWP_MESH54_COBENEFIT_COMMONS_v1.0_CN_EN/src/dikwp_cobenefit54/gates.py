from __future__ import annotations

from typing import Any

from .models import (
    AdoptionGateVerdict54,
    CoBenefitCovenant54,
    DecisionRightsMatrix54,
    InstitutionalAtlas54,
    NoRetaliationCovenant54,
    PilotCell54,
    PilotOutcome54,
    TransitionCostMap54,
)
from .utils import clamp, normalized_mean, sha256_obj


KILL_FLAGS = {
    "retaliation_detected": "retaliation against contributor, reporter or affected party",
    "evidence_suppression": "negative evidence was suppressed",
    "split_view": "different audiences were shown inconsistent evidence views",
    "covert_benefit_exchange": "undisclosed personal benefit exchange attempted",
    "audit_deletion": "audit evidence deletion or tampering attempted",
    "human_control_bypass": "human final control was bypassed",
}

BLOCK_FLAGS = {
    "prohibited_use": "scenario includes a prohibited use",
    "unauthorized_data": "data use lacks authorization or lawful basis",
    "unlabelled_generated_content": "public-facing generated content lacks required labeling",
    "public_launch_without_shadow": "higher-risk system was moved to public launch without shadow validation",
    "coercive_automation": "automation is imposed without meaningful human or worker choice",
}


def _verdict_hash_body(body: dict[str, Any]) -> tuple[str, str]:
    digest = sha256_obj(body)
    return f"AGV54-{digest[:14]}", digest


def evaluate_adoption_gate54(
    scenario: dict[str, Any],
    transition: TransitionCostMap54,
    atlas: InstitutionalAtlas54,
    co_benefit: CoBenefitCovenant54,
    decision_rights: DecisionRightsMatrix54,
    pilot: PilotCell54,
    no_retaliation: NoRetaliationCovenant54,
    mesh54_evidence: dict[str, Any],
    *,
    issued_at: int,
) -> AdoptionGateVerdict54:
    reasons: list[str] = []
    actions: list[str] = []
    flags = scenario.get("flags", {})

    for flag, reason in KILL_FLAGS.items():
        if flags.get(flag, False) or (flag == "split_view" and mesh54_evidence.get("split_view_detected", False)):
            reasons.append(reason)
    if reasons:
        gate = "KILL"
        actions.extend([
            "stop the pilot and preserve evidence",
            "activate independent investigation and no-retaliation remedies",
            "revoke capability leases and publish a versioned incident notice",
        ])
    else:
        for flag, reason in BLOCK_FLAGS.items():
            if flags.get(flag, False):
                reasons.append(reason)
        if reasons:
            gate = "BLOCK"
            actions.extend([
                "do not perform the proposed action",
                "reframe the task within lawful, authorized and low-risk scope",
                "obtain required labels, data permissions and human control",
            ])
        else:
            hold_reasons = []
            independence = mesh54_evidence.get("witness_independence", {})
            if pilot.independent_witness_required and independence.get("status") != "MET":
                hold_reasons.append("independent witness threshold is not met")
            if not pilot.appeal_available:
                hold_reasons.append("affected parties lack an appeal path")
            if not pilot.rollback_available:
                hold_reasons.append("pilot lacks a tested rollback path")
            if not pilot.human_final_control and scenario.get("risk_level") in {"MEDIUM", "HIGH", "CRITICAL"}:
                hold_reasons.append("human final control is absent in a non-low-risk scenario")
            if decision_rights.escalation_owner == "unassigned" or decision_rights.appeal_owner == "unassigned":
                hold_reasons.append("decision and appeal owners are not assigned")
            if transition.total_cost >= 0.62 and not co_benefit.clauses:
                hold_reasons.append("high transition cost has no explicit co-benefit burden-sharing clauses")
            if scenario.get("cross_border_data_unknown", False):
                hold_reasons.append("cross-border data conditions remain unresolved")
            if scenario.get("evidence_confidence", 0.0) < 0.35:
                hold_reasons.append("evidence confidence is below the pilot threshold")
            if atlas.status != "ACTIVE_OPEN_ATLAS":
                hold_reasons.append("institutional atlas is quarantined")
            if mesh54_evidence.get("mesh54_status") != "S5.4-OPERABLE-OPEN":
                hold_reasons.extend(mesh54_evidence.get("mesh54_reasons", []))
            if hold_reasons:
                gate = "HOLD"
                reasons.extend(hold_reasons)
                actions.extend([
                    "keep the system in synthetic, replay or shadow mode",
                    "close decision-right, appeal, rollback and witness gaps",
                    "reassess after stakeholder translations and open residuals are updated",
                ])
            else:
                review_reasons = []
                if transition.total_cost >= 0.35:
                    review_reasons.append("material transition costs require negotiated allocation")
                if atlas.max_holonomy_error >= 0.25 or atlas.max_translation_error >= 0.30:
                    review_reasons.append("stakeholder meanings drift across the institutional loop")
                if scenario.get("status_credit_conflict", False):
                    review_reasons.append("credit or status allocation remains contested")
                if scenario.get("liability_shift_unresolved", False):
                    review_reasons.append("liability allocation remains contested")
                if scenario.get("worker_transition_unresolved", False):
                    review_reasons.append("employment or role transition remains unresolved")
                if review_reasons:
                    gate = "REVIEW"
                    reasons.extend(review_reasons)
                    actions.extend([
                        "convene a time-boxed co-benefit review with affected parties",
                        "publish the decision-right and contribution-credit matrix",
                        "continue only in reversible human-confirmed co-pilot mode",
                    ])
                else:
                    gate = "ALLOW"
                    reasons.extend([
                        "scope is low or bounded risk",
                        "human final control, appeal and rollback are available",
                        "independent evidence and contribution protections are present",
                    ])
                    actions.extend([
                        "run the time-boxed pilot",
                        "publish run receipts, correction tickets and residuals",
                        "reassess before any scope or authority expansion",
                    ])

    body = {
        "scenario_id": scenario["scenario_id"],
        "gate": gate,
        "reasons": sorted(set(reasons)),
        "required_actions": sorted(set(actions)),
        "evidence_grade": scenario.get("evidence_grade", "E2 deterministic synthetic reference"),
        "mesh54_status": mesh54_evidence.get("mesh54_status", "S5.4-QUARANTINED"),
        "independent_witness_status": mesh54_evidence.get("witness_independence", {}).get("status", "NOT_MET"),
        "reciprocity_status": mesh54_evidence.get("reciprocity", {}).get("status", "UNRESOLVED"),
        "split_view_detected": bool(mesh54_evidence.get("split_view_detected", False)),
        "issued_at": int(issued_at),
    }
    verdict_id, digest = _verdict_hash_body(body)
    return AdoptionGateVerdict54(verdict_id=verdict_id, verdict_hash=digest, **body)


def evaluate_outcome54(
    scenario: dict[str, Any],
    verdict: AdoptionGateVerdict54,
    transition: TransitionCostMap54,
    atlas: InstitutionalAtlas54,
    co_benefit: CoBenefitCovenant54,
    pilot: PilotCell54,
    credit_count: int,
    correction_count: int,
) -> PilotOutcome54:
    public_value = clamp(scenario.get("public_value", 0.6))
    user_control = normalized_mean([
        1.0 if pilot.human_final_control else 0.0,
        1.0 if pilot.appeal_available else 0.0,
        1.0 if pilot.rollback_available else 0.0,
    ])
    institutional_fit = clamp(1.0 - transition.total_cost * 0.55 - atlas.max_holonomy_error * 0.45)
    evidence = clamp(scenario.get("evidence_confidence", 0.5))
    contribution_protection = clamp(0.35 + min(credit_count, 3) * 0.2 + (0.2 if co_benefit.credit_rules else 0.0))
    correction_quality = clamp(0.3 + min(correction_count, 2) * 0.25 + (0.2 if co_benefit.correction_rules else 0.0))
    residual_risk = clamp(
        0.25 * transition.total_cost
        + 0.30 * atlas.max_holonomy_error
        + 0.20 * (1.0 - evidence)
        + (0.50 if verdict.gate == "KILL" else 0.30 if verdict.gate == "BLOCK" else 0.10 if verdict.gate == "HOLD" else 0.0)
    )
    failures = list(scenario.get("observed_failures", []))
    learned = list(scenario.get("learned_changes", []))
    next_action = {
        "ALLOW": "complete pilot and prepare independent scale review",
        "REVIEW": "run negotiated co-benefit review before scope expansion",
        "HOLD": "close control, witness, appeal or evidence gaps in shadow mode",
        "BLOCK": "redesign the use case; no deployment",
        "KILL": "terminate, preserve evidence and activate incident and retaliation remedies",
    }[verdict.gate]
    body = {
        "scenario_id": scenario["scenario_id"],
        "gate": verdict.gate,
        "public_value_score": public_value,
        "user_control_score": user_control,
        "institutional_fit_score": institutional_fit,
        "evidence_score": evidence,
        "contribution_protection_score": contribution_protection,
        "correction_quality_score": correction_quality,
        "residual_risk_score": residual_risk,
        "observed_failures": failures,
        "learned_changes": learned,
        "next_action": next_action,
    }
    digest = sha256_obj(body)
    return PilotOutcome54(outcome_id=f"PO54-{digest[:14]}", outcome_hash=digest, **body)
