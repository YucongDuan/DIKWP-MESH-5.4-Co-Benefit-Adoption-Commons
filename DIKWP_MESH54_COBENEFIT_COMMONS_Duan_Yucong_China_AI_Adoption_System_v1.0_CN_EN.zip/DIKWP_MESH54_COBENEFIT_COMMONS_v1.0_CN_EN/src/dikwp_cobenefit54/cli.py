from __future__ import annotations

import argparse
import json
from pathlib import Path

from .dashboard import generate_dashboard
from .ledger import AppendOnlyLedger54
from .runtime import CoBenefitRuntime54
from .scenarios import reference_scenarios54
from .utils import to_builtin


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="dikwp-cobenefit54", description="DIKWP-MESH 5.4 Co-Benefit Adoption Commons")
    sub = p.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="run all reference scenarios")
    demo.add_argument("--out", default="outputs/demo")
    one = sub.add_parser("assess", help="assess one scenario id or JSON file")
    one.add_argument("target")
    one.add_argument("--out", default="outputs/assessment")
    val = sub.add_parser("validate", help="validate reference gates")
    val.add_argument("--out", default="outputs/validation")
    led = sub.add_parser("verify-ledger", help="verify an institutional learning ledger")
    led.add_argument("ledger")
    dash = sub.add_parser("dashboard", help="generate dashboard from an output directory")
    dash.add_argument("--out", default="outputs/demo")
    dash.add_argument("--html", default="dashboard/index.html")
    return p


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if args.command == "demo":
        runtime = CoBenefitRuntime54(args.out)
        result = runtime.run_reference(reset=True)
        html = generate_dashboard(args.out, Path(args.out) / "dashboard.html")
        print(json.dumps({"summary": result["summary"], "dashboard": str(html)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "assess":
        runtime = CoBenefitRuntime54(args.out)
        path = Path(args.target)
        result = runtime.assess_file(path) if path.exists() else runtime.run_one(args.target)
        html = generate_dashboard(args.out, Path(args.out) / "dashboard.html")
        print(json.dumps({"summary": result["summary"], "dashboard": str(html)}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "validate":
        runtime = CoBenefitRuntime54(args.out)
        result = runtime.run_reference(reset=True)
        expected = len(reference_scenarios54())
        ok = result["summary"]["expected_gate_matches"] == expected and result["summary"]["ledger"]["valid"]
        print(json.dumps({"valid": ok, **result["summary"]}, ensure_ascii=False, indent=2))
        return 0 if ok else 1
    if args.command == "verify-ledger":
        report = AppendOnlyLedger54(args.ledger).verify()
        print(json.dumps(to_builtin(report), ensure_ascii=False, indent=2))
        return 0 if report["valid"] else 1
    if args.command == "dashboard":
        target = generate_dashboard(args.out, args.html)
        print(target)
        return 0
    return 2
