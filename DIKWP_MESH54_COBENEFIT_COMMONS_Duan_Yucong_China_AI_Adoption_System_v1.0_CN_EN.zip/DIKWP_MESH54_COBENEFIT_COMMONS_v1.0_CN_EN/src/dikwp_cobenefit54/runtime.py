from __future__ import annotations

import json
import shutil
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

from dikwp_phi0.intent54 import verify_intent_field_covenant54
from dikwp_phi0.utils import to_builtin as mesh_to_builtin

from .builders import (
    build_actor54,
    build_co_benefit_covenant54,
    build_corrections54,
    build_credits54,
    build_decision_rights54,
    build_escrow54,
    build_institutional_atlas54,
    build_no_retaliation54,
    build_pilot_cell54,
    build_threat_signals54,
    build_transition_cost54,
)
from .gates import evaluate_adoption_gate54, evaluate_outcome54
from .ledger import AppendOnlyLedger54
from .mesh54_bridge import (
    build_mesh54_intent_covenant,
    build_reciprocity_evidence,
    build_transparency_evidence,
    build_witness_evidence,
    extension_mesh54_status,
)
from .models import InstitutionalLearningRelease54, ScenarioAssessment54
from .scenarios import reference_scenarios54, scenario_by_id
from .utils import read_json, sha256_obj, to_builtin, write_json


class CoBenefitRuntime54:
    framework = "DIKWP-MESH 5.4 Co-Benefit Adoption Commons"
    version = "1.0.0"

    def __init__(self, out_dir: str | Path) -> None:
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.ledger = AppendOnlyLedger54(self.out_dir / "institutional_learning_ledger.jsonl")

    def reset(self) -> None:
        if self.out_dir.exists():
            shutil.rmtree(self.out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.ledger = AppendOnlyLedger54(self.out_dir / "institutional_learning_ledger.jsonl")

    def assess(self, scenario: dict[str, Any], *, logical_time: int) -> ScenarioAssessment54:
        evidence_hashes = list(scenario.get("evidence_hashes", [])) + [scenario["scenario_hash"]]
        actors = [build_actor54(spec, evidence_hashes) for spec in scenario["actor_specs"]]
        threats = [item for actor in actors for item in build_threat_signals54(actor, scenario)]
        transition = build_transition_cost54(scenario)
        atlas = build_institutional_atlas54(actors, scenario)
        decision_rights = build_decision_rights54(scenario)
        pilot = build_pilot_cell54(scenario)
        mesh_covenant = build_mesh54_intent_covenant(scenario, actors)
        co_benefit = build_co_benefit_covenant54(scenario, transition, mesh_covenant.covenant_hash)
        corrections = build_corrections54(scenario)
        credits = build_credits54(scenario)
        escrow = build_escrow54(scenario)
        no_retaliation = build_no_retaliation54(scenario)

        reciprocity = build_reciprocity_evidence(scenario)
        subject_hash = sha256_obj(
            {
                "scenario": scenario["scenario_hash"],
                "intent": mesh_covenant.covenant_hash,
                "atlas": atlas.atlas_hash,
                "co_benefit": co_benefit.covenant_hash,
                "decision_rights": decision_rights.matrix_hash,
                "pilot": pilot.pilot_hash,
            }
        )
        witness = build_witness_evidence(
            scenario,
            subject_hash,
            [mesh_covenant.covenant_hash, atlas.atlas_hash, co_benefit.covenant_hash, pilot.pilot_hash],
        )
        events: list[tuple[str, Any]] = [
            ("SCENARIO", scenario),
            ("MESH54_INTENT_FIELD", mesh_to_builtin(mesh_covenant)),
            ("INSTITUTIONAL_ATLAS", atlas),
            ("COBENEFIT_COVENANT", co_benefit),
            ("DECISION_RIGHTS", decision_rights),
            ("PILOT_CELL", pilot),
            ("EVIDENCE_ESCROW", escrow),
            ("NO_RETALIATION", no_retaliation),
        ]
        transparency = build_transparency_evidence(self.out_dir / "transparency", scenario, events)
        mesh_status, mesh_reasons = extension_mesh54_status(
            covenant_valid=verify_intent_field_covenant54(mesh_covenant),
            reciprocity_status=reciprocity["status"],
            witness_status=witness["independence"]["status"],
            checkpoint_valid=bool(transparency["checkpoint_valid"]),
            split_view_detected=bool(transparency["split_view_detected"]),
            atlas_status=atlas.status,
        )
        mesh_evidence = {
            "intent_field_covenant": mesh_to_builtin(mesh_covenant),
            "reciprocity": reciprocity,
            "witness_identities": witness["identities"],
            "witness_attestations": witness["attestations"],
            "witness_independence": witness["independence"],
            "transparency": transparency,
            "split_view_detected": bool(transparency["split_view_detected"]),
            "mesh54_status": mesh_status,
            "mesh54_reasons": mesh_reasons,
            "extension_note": "S5.4-OPERABLE-OPEN is an extension-level local status, not a claim of global semantic closure.",
        }
        verdict = evaluate_adoption_gate54(
            scenario,
            transition,
            atlas,
            co_benefit,
            decision_rights,
            pilot,
            no_retaliation,
            mesh_evidence,
            issued_at=logical_time,
        )
        outcome = evaluate_outcome54(
            scenario,
            verdict,
            transition,
            atlas,
            co_benefit,
            pilot,
            len(credits),
            len(corrections),
        )
        assessment = ScenarioAssessment54(
            scenario=scenario,
            actors=actors,
            threats=threats,
            transition_cost=transition,
            atlas=atlas,
            co_benefit_covenant=co_benefit,
            decision_rights=decision_rights,
            pilot=pilot,
            corrections=corrections,
            credits=credits,
            evidence_escrow=escrow,
            no_retaliation=no_retaliation,
            verdict=verdict,
            outcome=outcome,
            mesh54_evidence=mesh_evidence,
        )
        for event_type, payload in [
            ("SCENARIO_ASSESSED", scenario),
            ("INTENT_FIELD_COMPILED", mesh_to_builtin(mesh_covenant)),
            ("INSTITUTIONAL_ATLAS_COMPILED", atlas),
            ("COBENEFIT_COVENANT_COMPILED", co_benefit),
            ("ADOPTION_GATE_VERDICT", verdict),
            ("PILOT_OUTCOME", outcome),
        ]:
            self.ledger.append(event_type, payload, logical_time)
            logical_time += 1
        return assessment

    def run_reference(self, *, reset: bool = True) -> dict[str, Any]:
        if reset:
            self.reset()
        assessments: list[ScenarioAssessment54] = []
        logical_time = 1000
        for scenario in reference_scenarios54():
            assessments.append(self.assess(scenario, logical_time=logical_time))
            logical_time += 100
        return self._write_release(assessments)

    def run_one(self, scenario_id: str, *, reset: bool = True) -> dict[str, Any]:
        if reset:
            self.reset()
        assessment = self.assess(scenario_by_id(scenario_id), logical_time=1000)
        return self._write_release([assessment])

    def assess_file(self, path: str | Path, *, reset: bool = True) -> dict[str, Any]:
        if reset:
            self.reset()
        scenario = read_json(path)
        if "scenario_hash" not in scenario:
            scenario["scenario_hash"] = sha256_obj({k: v for k, v in scenario.items() if k != "scenario_hash"})
        assessment = self.assess(scenario, logical_time=1000)
        return self._write_release([assessment])

    def _write_release(self, assessments: list[ScenarioAssessment54]) -> dict[str, Any]:
        records = [to_builtin(item) for item in assessments]
        gate_counts = Counter(item.verdict.gate for item in assessments if item.verdict)
        ledger_report = self.ledger.verify()
        approved = [item.pilot.pilot_id for item in assessments if item.verdict and item.verdict.gate == "ALLOW" and item.pilot]
        held = [
            item.scenario["scenario_id"]
            for item in assessments
            if item.verdict and item.verdict.gate in {"REVIEW", "HOLD", "BLOCK"}
        ]
        kill_events = [item.scenario["scenario_id"] for item in assessments if item.verdict and item.verdict.gate == "KILL"]
        open_obligations = sorted(
            {
                obligation
                for item in assessments
                for obligation in (item.co_benefit_covenant.open_obligations if item.co_benefit_covenant else [])
            }
        )
        evidence_hashes = [item.verdict.verdict_hash for item in assessments if item.verdict]
        body = {
            "version": self.version,
            "scenario_count": len(assessments),
            "gate_counts": dict(sorted(gate_counts.items())),
            "approved_pilot_ids": approved,
            "held_or_blocked_ids": held,
            "kill_events": kill_events,
            "credit_receipt_count": sum(len(item.credits) for item in assessments),
            "open_obligations": open_obligations,
            "ledger_head": ledger_report["head_hash"],
            "evidence_hashes": evidence_hashes,
        }
        digest = sha256_obj(body)
        release = InstitutionalLearningRelease54(release_id=f"ILR54-{digest[:14]}", release_hash=digest, **body)
        summary = {
            "framework": self.framework,
            "version": self.version,
            "mesh_mode": "5.4 / S5.4-OPERABLE-OPEN",
            "scenario_count": len(assessments),
            "gate_counts": dict(sorted(gate_counts.items())),
            "expected_gate_matches": sum(
                1 for item in assessments if item.verdict and item.verdict.gate == item.scenario.get("expected_gate")
            ),
            "institutional_atlas_count": len(assessments),
            "intent_field_count": len(assessments),
            "credit_receipt_count": sum(len(item.credits) for item in assessments),
            "correction_ticket_count": sum(len(item.corrections) for item in assessments),
            "split_view_events": sum(
                1 for item in assessments if item.mesh54_evidence.get("split_view_detected", False)
            ),
            "one_way_objectification_events": sum(
                1 for item in assessments if item.mesh54_evidence.get("reciprocity", {}).get("status") == "ONE_WAY_OBJECTIFICATION"
            ),
            "ledger": ledger_report,
            "release_id": release.release_id,
            "release_hash": release.release_hash,
        }
        write_json(self.out_dir / "assessments.json", records)
        write_json(self.out_dir / "summary.json", summary)
        write_json(self.out_dir / "institutional_learning_release.json", release)
        write_json(
            self.out_dir / "adoption_gate_table.json",
            [
                {
                    "scenario_id": item.scenario["scenario_id"],
                    "title": item.scenario["title"],
                    "domain": item.scenario["domain"],
                    "expected_gate": item.scenario["expected_gate"],
                    "actual_gate": item.verdict.gate,
                    "match": item.verdict.gate == item.scenario["expected_gate"],
                    "reasons": item.verdict.reasons,
                    "next_action": item.outcome.next_action,
                    "atlas_status": item.atlas.status,
                    "max_holonomy_error": item.atlas.max_holonomy_error,
                    "transition_cost": item.transition_cost.total_cost,
                    "mesh54_status": item.verdict.mesh54_status,
                }
                for item in assessments
            ],
        )
        return {"summary": summary, "release": to_builtin(release), "assessments": records}
