from __future__ import annotations

from pathlib import Path
from typing import Any

from dikwp_phi0.intent54 import (
    build_intent_edge54,
    build_intent_field_covenant54,
    build_intent_node54,
    build_revision_trigger54,
    verify_intent_field_covenant54,
)
from dikwp_phi0.observer54 import evaluate_observer_reciprocity54
from dikwp_phi0.signing54 import Ed25519Identity54
from dikwp_phi0.transparency import CertificateTransparencyLog
from dikwp_phi0.transparency54 import (
    build_gossip_checkpoint54,
    compare_transparency_views54,
    verify_gossip_checkpoint54,
)
from dikwp_phi0.utils import to_builtin as mesh_to_builtin
from dikwp_phi0.witness54 import (
    attest54,
    build_witness_identity54,
    evaluate_witness_independence54,
    reference_witnesses54,
)

from .utils import sha256_obj, to_builtin


ROLE_CAPABILITIES = {
    "sponsor": ("approve-pilot", "allocate-transition-budget", "appoint-independent-review"),
    "operator": ("run-shadow-mode", "submit-run-receipt", "request-escalation"),
    "innovator": ("propose-change", "submit-evidence", "claim-contribution-credit"),
    "affected_party": ("appeal", "withdraw-consent", "request-correction"),
    "governance": ("audit", "suspend", "require-remediation"),
    "data_steward": ("classify-data", "approve-data-use", "revoke-data-access"),
    "reviewer": ("replicate", "red-team", "attest"),
}


def build_mesh54_intent_covenant(scenario: dict[str, Any], actors: list[Any]):
    nodes = []
    for index, actor in enumerate(actors, start=1):
        allowed = ROLE_CAPABILITIES.get(actor.role, ("observe",))
        prohibited = list(scenario.get("global_prohibited_capabilities", []))
        if actor.role == "affected_party":
            polarity = "PRESERVE"
        elif actor.role == "governance":
            polarity = "INQUIRE"
        elif actor.role in {"operator", "innovator", "sponsor"}:
            polarity = "ATTRACT"
        else:
            polarity = "DEFER"
        nodes.append(
            build_intent_node54(
                f"INT-{scenario['scenario_id']}-{index:02d}",
                actor.actor_id,
                polarity,
                f"OH-{sha256_obj([scenario['scenario_id'], actor.actor_id])[:16]}",
                protected_relation_ids=(
                    "REL-HUMAN-FINAL-CONTROL",
                    "REL-CONTRIBUTION-CREDIT",
                    "REL-NO-RETALIATION",
                    "REL-APPEAL",
                ),
                allowed_capabilities=allowed,
                prohibited_capabilities=prohibited,
                active_from=0,
                active_until=int(scenario.get("covenant_valid_until", 10_000)),
                source_hashes=(actor.actor_hash,),
            )
        )
    # Explicit anti-intents are first-class nodes, not hidden assumptions.
    anti_specs = [
        ("ANTI-RETALIATION", "AVOID", "holder:protected-contributor", ("retaliation", "coercive-transfer")),
        ("ANTI-EVIDENCE-SUPPRESSION", "AVOID", "holder:evidence-steward", ("audit-delete", "split-view")),
        ("ANTI-COERCIVE-AUTOMATION", "AVOID", "holder:affected-party", ("forced-automation", "human-control-bypass")),
        ("PRESERVE-OPEN-RESIDUAL", "PRESERVE", "holder:mesh54-residual", ()),
    ]
    for offset, (name, polarity, holder, prohibited) in enumerate(anti_specs, start=1):
        nodes.append(
            build_intent_node54(
                f"INT-{scenario['scenario_id']}-{name}",
                holder,
                polarity,
                f"OH-A-{offset:02d}-{sha256_obj([scenario['scenario_id'], name])[:10]}",
                protected_relation_ids=("REL-RESIDUAL-HONESTY", "REL-AFFECTED-PARTY-APPEAL"),
                allowed_capabilities=("register-uax", "request-review") if polarity == "PRESERVE" else ("block-prohibited-action",),
                prohibited_capabilities=prohibited,
                source_hashes=(sha256_obj([scenario["scenario_id"], name]),),
            )
        )

    edges = []
    # Connect every actor intent to anti-retaliation and human-control preservation.
    actor_nodes = [n for n in nodes if n.holder_id.startswith("IA54-")]
    anti_retaliation = next(n for n in nodes if "ANTI-RETALIATION" in n.intent_id)
    anti_suppression = next(n for n in nodes if "ANTI-EVIDENCE-SUPPRESSION" in n.intent_id)
    residual = next(n for n in nodes if "PRESERVE-OPEN-RESIDUAL" in n.intent_id)
    for index, node in enumerate(actor_nodes, start=1):
        relation = "CONSTRAINS" if node.holder_id else "DEPENDS_ON"
        edges.append(
            build_intent_edge54(
                f"IE-{scenario['scenario_id']}-R-{index:02d}",
                anti_retaliation.intent_id,
                node.intent_id,
                relation,
                strength=1.0,
                reversible=False,
                evidence_hashes=(anti_retaliation.node_hash, node.node_hash),
            )
        )
        edges.append(
            build_intent_edge54(
                f"IE-{scenario['scenario_id']}-E-{index:02d}",
                anti_suppression.intent_id,
                node.intent_id,
                "CONSTRAINS",
                strength=1.0,
                reversible=False,
                evidence_hashes=(anti_suppression.node_hash, node.node_hash),
            )
        )
        edges.append(
            build_intent_edge54(
                f"IE-{scenario['scenario_id']}-U-{index:02d}",
                node.intent_id,
                residual.intent_id,
                "DEPENDS_ON",
                strength=0.7,
                reversible=True,
                evidence_hashes=(node.node_hash, residual.node_hash),
            )
        )

    triggers = [
        build_revision_trigger54(
            f"RT-{scenario['scenario_id']}-RETALIATION",
            "retaliation-signal",
            [n.intent_id for n in nodes if "ANTI-RETALIATION" in n.intent_id],
            threshold=0.01,
            action="SUSPEND",
        ),
        build_revision_trigger54(
            f"RT-{scenario['scenario_id']}-SPLITVIEW",
            "transparency-split-view",
            [n.intent_id for n in nodes if "ANTI-EVIDENCE-SUPPRESSION" in n.intent_id],
            threshold=0.01,
            action="REVOKE",
        ),
        build_revision_trigger54(
            f"RT-{scenario['scenario_id']}-CURVATURE",
            "institutional-semantic-curvature",
            [n.intent_id for n in actor_nodes],
            threshold=float(scenario.get("curvature_review_threshold", 0.35)),
            action="REVIEW",
        ),
        build_revision_trigger54(
            f"RT-{scenario['scenario_id']}-OUTCOME",
            "negative-pilot-outcome",
            [n.intent_id for n in actor_nodes],
            threshold=float(scenario.get("negative_outcome_threshold", 0.25)),
            action="REOPEN",
        ),
    ]
    covenant = build_intent_field_covenant54(
        observer_ids=[a.actor_id for a in actors],
        intent_nodes=nodes,
        intent_edges=edges,
        revision_triggers=triggers,
        allowed_environment_ids=(
            "CN-INSTITUTION-SYNTHETIC",
            "CN-INSTITUTION-HISTORICAL-REPLAY",
            "CN-INSTITUTION-SHADOW",
            "CN-INSTITUTION-HUMAN-CONFIRMED",
        ),
        protected_relation_ids=(
            "REL-HUMAN-FINAL-CONTROL",
            "REL-CONTRIBUTION-CREDIT",
            "REL-NO-RETALIATION",
            "REL-APPEAL",
            "REL-RESIDUAL-HONESTY",
        ),
        human_review_required=True,
        appeal_available=bool(scenario.get("appeal_available", False)),
        issued_at=0,
        expires_at=int(scenario.get("covenant_valid_until", 10_000)),
        evidence_grade="E2 deterministic institutional reference; requires real independent witnesses before deployment",
        open_obligations=tuple(scenario.get("open_obligations", []))
        + (
            "institutional motives are not inferred from scores",
            "real legal, labor, procurement and sector review remains required",
            "S5.4 remains operable-open rather than globally closed",
        ),
    )
    if not verify_intent_field_covenant54(covenant):
        raise ValueError("generated Mesh 5.4 intent covenant is invalid")
    return covenant


def build_witness_evidence(scenario: dict[str, Any], subject_hash: str, evidence_hashes: list[str]) -> dict[str, Any]:
    mode = scenario.get("witness_mode", "independent")
    if mode == "collapsed":
        roles = ["replicator", "red-team", "governance", "affected-party"]
        signers = {}
        identities = []
        for role in roles:
            signer = Ed25519Identity54.from_seed(f"W54-COLLAPSED-{role}", f"collapsed:{scenario['scenario_id']}:{role}")
            signers[signer.identity_id] = signer
            identities.append(
                build_witness_identity54(
                    signer,
                    role=role,
                    organization_id="ORG-SAME-CONTROL",
                    funding_domain="FUND-SAME-CONTROL",
                    software_lineage="SW-SAME-CONTROL",
                    data_lineage="DATA-SAME-CONTROL",
                    jurisdiction="CN",
                )
            )
    else:
        signers, identities = reference_witnesses54()
    verdict = "APPROVE" if not scenario.get("witness_reject", False) else "REJECT"
    attestations = []
    for index, identity in enumerate(identities, start=1):
        attestations.append(
            attest54(
                signers[identity.witness_id],
                identity,
                subject_hash,
                verdict,
                evidence_hashes,
                issued_at=100 + index,
            )
        )
    independence = evaluate_witness_independence54(
        identities, attestations, required_independent_count=int(scenario.get("required_independent_count", 3))
    )
    return {
        "identities": [mesh_to_builtin(x) for x in identities],
        "attestations": [mesh_to_builtin(x) for x in attestations],
        "independence": mesh_to_builtin(independence),
    }


def build_reciprocity_evidence(scenario: dict[str, Any]) -> dict[str, Any]:
    item = evaluate_observer_reciprocity54(
        "observer:institutional-pilot-team",
        f"subject:{scenario['scenario_id']}",
        seed=f"cobenefit54:{scenario['scenario_id']}",
        one_way=bool(scenario.get("one_way_objectification", False)),
    )
    return mesh_to_builtin(item)


def build_transparency_evidence(
    out_dir: str | Path,
    scenario: dict[str, Any],
    events: list[tuple[str, Any]],
) -> dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    log = CertificateTransparencyLog(out / f"{scenario['scenario_id']}.transparency.jsonl")
    for logical_time, (event_type, payload) in enumerate(events, start=1):
        log.append(event_type, payload, logical_time=logical_time)
    signer = Ed25519Identity54.from_seed(
        f"GOSSIP-{scenario['scenario_id']}", f"cobenefit-gossip:{scenario['scenario_id']}"
    )
    checkpoint = build_gossip_checkpoint54(
        log,
        signer,
        node_id=f"node:{scenario['scenario_id']}:public",
        log_id=f"log:{scenario['scenario_id']}",
        logical_time=len(events) + 1,
    )
    valid = verify_gossip_checkpoint54(checkpoint, signer.public_key_hex)
    comparison = None
    split_detected = False
    if scenario.get("split_view", False):
        # Build a conflicting same-size view with one substituted event.
        fork = CertificateTransparencyLog(out / f"{scenario['scenario_id']}.fork.jsonl")
        for logical_time, (event_type, payload) in enumerate(events, start=1):
            if logical_time == max(1, len(events) // 2):
                payload = {"redacted_for_one_audience": True, "original_hash": sha256_obj(payload)}
            fork.append(event_type, payload, logical_time=logical_time)
        fork_signer = Ed25519Identity54.from_seed(
            f"GOSSIP-{scenario['scenario_id']}-FORK", f"cobenefit-gossip-fork:{scenario['scenario_id']}"
        )
        fork_checkpoint = build_gossip_checkpoint54(
            fork,
            fork_signer,
            node_id=f"node:{scenario['scenario_id']}:restricted",
            log_id=f"log:{scenario['scenario_id']}",
            logical_time=len(events) + 1,
        )
        comparison_item = compare_transparency_views54(checkpoint, fork_checkpoint, log.entries(), fork.entries())
        comparison = mesh_to_builtin(comparison_item)
        split_detected = bool(comparison_item.split_view_detected)
    return {
        "checkpoint": mesh_to_builtin(checkpoint),
        "checkpoint_valid": valid,
        "comparison": comparison,
        "split_view_detected": split_detected,
        "log_verification": log.verify(),
    }


def extension_mesh54_status(
    *,
    covenant_valid: bool,
    reciprocity_status: str,
    witness_status: str,
    checkpoint_valid: bool,
    split_view_detected: bool,
    atlas_status: str,
) -> tuple[str, list[str]]:
    reasons = []
    if not covenant_valid:
        reasons.append("intent field covenant invalid")
    if reciprocity_status != "RECIPROCAL":
        reasons.append("observer-subject reciprocity is not reciprocal")
    if witness_status != "MET":
        reasons.append("effective independent witness threshold not met")
    if not checkpoint_valid:
        reasons.append("signed transparency checkpoint invalid")
    if split_view_detected:
        reasons.append("transparency split view detected")
    if atlas_status != "ACTIVE_OPEN_ATLAS":
        reasons.append("institutional atlas is quarantined")
    return ("S5.4-OPERABLE-OPEN" if not reasons else "S5.4-QUARANTINED", reasons)
