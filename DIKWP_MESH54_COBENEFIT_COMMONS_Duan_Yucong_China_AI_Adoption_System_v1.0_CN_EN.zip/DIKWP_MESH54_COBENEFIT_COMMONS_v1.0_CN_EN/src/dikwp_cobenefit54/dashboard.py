from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

from .utils import read_json


def generate_dashboard(output_dir: str | Path, destination: str | Path) -> Path:
    out = Path(output_dir)
    summary = read_json(out / "summary.json")
    rows = read_json(out / "adoption_gate_table.json")
    assessments = read_json(out / "assessments.json")
    payload = {"summary": summary, "rows": rows, "assessments": assessments}
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    page = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-MESH 5.4 共益落地系统</title>
<style>
:root{{--bg:#f5f7fb;--ink:#14213d;--muted:#5f6b7a;--card:#fff;--line:#d9e1ec;--a:#1d4ed8;--allow:#0f766e;--review:#9a6700;--hold:#9a6700;--block:#b42318;--kill:#7f1d1d}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}}
header{{background:linear-gradient(135deg,#0f172a,#1e3a8a);color:white;padding:34px 5vw 28px}}
h1{{margin:0 0 8px;font-size:clamp(28px,4vw,48px)}}header p{{max-width:1100px;line-height:1.7;color:#dbeafe}}
main{{max-width:1500px;margin:auto;padding:24px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-bottom:18px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px;box-shadow:0 8px 24px rgba(15,23,42,.05)}}
.kpi b{{display:block;font-size:30px;margin-top:8px}}.kpi span{{color:var(--muted)}}
.controls{{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:18px 0}}select,input{{border:1px solid var(--line);border-radius:10px;padding:10px 12px;background:white}}
table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{padding:11px 9px;border-bottom:1px solid var(--line);vertical-align:top;text-align:left}}th{{position:sticky;top:0;background:#eef3fb}}
.badge{{display:inline-block;padding:4px 9px;border-radius:999px;color:white;font-weight:700;font-size:12px}}.ALLOW{{background:var(--allow)}}.REVIEW,.HOLD{{background:var(--review)}}.BLOCK{{background:var(--block)}}.KILL{{background:var(--kill)}}
.small{{color:var(--muted);font-size:12px}}.drawer{{margin-top:18px}}details{{background:white;border:1px solid var(--line);border-radius:12px;padding:12px;margin:8px 0}}summary{{cursor:pointer;font-weight:700}}pre{{white-space:pre-wrap;word-break:break-word;background:#0b1220;color:#dbeafe;padding:14px;border-radius:10px;max-height:460px;overflow:auto}}
footer{{padding:24px;color:var(--muted);text-align:center}}
</style>
</head>
<body>
<header><h1>DIKWP-MESH 5.4 共益落地系统</h1><p>中国AI试点共益协商、体面纠错、贡献保护与组织适配运行时。核心不是隐藏能力、购买忠诚或操纵关系，而是把改革中的权利、预算、信用、责任、工作量、数据与公共价值差异编译为可复核的意图场、机构图册、试点门禁和追加式证据。</p></header>
<main>
<div id="kpis" class="grid"></div>
<div class="card">
<h2>18类中国机构落地情景</h2>
<div class="controls"><label>门禁 <select id="gate"><option value="">全部</option><option>ALLOW</option><option>REVIEW</option><option>HOLD</option><option>BLOCK</option><option>KILL</option></select></label><label>领域 <select id="domain"><option value="">全部</option></select></label><input id="q" placeholder="搜索情景、原因或下一步"></div>
<div style="overflow:auto;max-height:660px"><table><thead><tr><th>情景</th><th>领域</th><th>门禁</th><th>转型成本</th><th>最大闭环漂移</th><th>关键原因</th><th>下一步</th></tr></thead><tbody id="body"></tbody></table></div>
</div>
<div class="drawer card"><h2>Mesh 5.4 对象与证据</h2><div id="details"></div></div>
</main>
<footer>离线参考实现 · 无网络请求 · 结果为合成场景，不构成真实项目审批或法律合规认证。</footer>
<script>
const DATA={data};
const esc=s=>String(s??'').replace(/[&<>\"']/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}}[c]));
const s=DATA.summary;
const kpis=[['情景',s.scenario_count],['门禁匹配',s.expected_gate_matches+'/'+s.scenario_count],['Intent Field',s.intent_field_count],['机构图册',s.institutional_atlas_count],['贡献回执',s.credit_receipt_count],['纠错工单',s.correction_ticket_count],['分裂视图',s.split_view_events],['账本记录',s.ledger.records]];
document.getElementById('kpis').innerHTML=kpis.map(x=>`<div class="card kpi"><span>${{esc(x[0])}}</span><b>${{esc(x[1])}}</b></div>`).join('');
const domain=document.getElementById('domain');[...new Set(DATA.rows.map(r=>r.domain))].sort().forEach(v=>domain.insertAdjacentHTML('beforeend',`<option>${{esc(v)}}</option>`));
function render(){{const g=document.getElementById('gate').value,d=domain.value,q=document.getElementById('q').value.toLowerCase();const rows=DATA.rows.filter(r=>(!g||r.actual_gate===g)&&(!d||r.domain===d)&&(!q||JSON.stringify(r).toLowerCase().includes(q)));document.getElementById('body').innerHTML=rows.map(r=>`<tr><td><b>${{esc(r.scenario_id)}}</b><br>${{esc(r.title)}}</td><td>${{esc(r.domain)}}</td><td><span class="badge ${{r.actual_gate}}">${{r.actual_gate}}</span></td><td>${{Number(r.transition_cost).toFixed(3)}}</td><td>${{Number(r.max_holonomy_error).toFixed(3)}}</td><td>${{esc((r.reasons||[]).slice(0,3).join('；'))}}</td><td>${{esc(r.next_action)}}</td></tr>`).join('');}}
['gate','domain','q'].forEach(id=>document.getElementById(id).addEventListener(id==='q'?'input':'change',render));render();
document.getElementById('details').innerHTML=DATA.assessments.map(a=>`<details><summary>${{esc(a.scenario.scenario_id)}} · ${{esc(a.verdict.gate)}} · ${{esc(a.scenario.title)}}</summary><p><b>Mesh状态：</b>${{esc(a.verdict.mesh54_status)}}；<b>互反状态：</b>${{esc(a.verdict.reciprocity_status)}}；<b>独立见证：</b>${{esc(a.verdict.independent_witness_status)}}</p><p><b>开放义务：</b>${{esc((a.co_benefit_covenant.open_obligations||[]).join('；'))}}</p><pre>${{esc(JSON.stringify({{intent_field:a.mesh54_evidence.intent_field_covenant,atlas:a.atlas,co_benefit:a.co_benefit_covenant,decision_rights:a.decision_rights,verdict:a.verdict}},null,2))}}</pre></details>`).join('');
</script>
</body></html>"""
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target
