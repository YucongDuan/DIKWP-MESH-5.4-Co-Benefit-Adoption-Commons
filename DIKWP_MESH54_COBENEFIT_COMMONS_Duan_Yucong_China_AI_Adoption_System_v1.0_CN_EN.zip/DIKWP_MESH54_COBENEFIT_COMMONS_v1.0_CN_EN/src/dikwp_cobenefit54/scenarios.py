from __future__ import annotations

from copy import deepcopy
from typing import Any

from .utils import sha256_obj


def _actor(label: str, role: str, org: str, *, affected: bool = False, rights=(), benefits=(), fears=(), risk=(), commitments=()):
    return {
        "label": label,
        "role": role,
        "organization_id": org,
        "decision_rights": list(rights),
        "benefits_sought": list(benefits),
        "burdens_feared": list(fears),
        "resources_at_risk": list(risk),
        "public_commitments": list(commitments),
        "affected_party": affected,
    }


def _base(sid: str, title: str, domain: str, expected: str, risk: str = "LOW") -> dict[str, Any]:
    scenario = {
        "scenario_id": sid,
        "title": title,
        "domain": domain,
        "expected_gate": expected,
        "risk_level": risk,
        "purpose_statement": "Use a reversible, evidence-carrying AI pilot to improve public or organizational value without covertly transferring authority, liability, credit or burden.",
        "public_value": 0.70,
        "evidence_confidence": 0.65,
        "evidence_grade": "E2 deterministic synthetic reference; field evidence required",
        "declared_transition_costs": True,
        "human_final_control": True,
        "generated_content_labeling": True,
        "rollback_available": True,
        "appeal_available": True,
        "independent_witness_required": True,
        "required_independent_count": 3,
        "witness_mode": "independent",
        "one_way_objectification": False,
        "split_view": False,
        "pilot_stage": "SHADOW_RECOMMENDATION",
        "duration_days": 30,
        "data_classification": "SYNTHETIC_OR_PUBLIC",
        "scope": ["bounded recommendation", "evidence logging", "human-confirmed action"],
        "excluded_scope": ["autonomous high-impact decision", "unbounded tool access"],
        "success_metrics": ["trace completeness >= 0.95", "human override effectiveness = 1.0", "no prohibited action"],
        "kill_conditions": ["retaliation", "audit deletion", "human-control bypass", "unapproved data use"],
        "global_prohibited_capabilities": ["covert-benefit-exchange", "retaliation", "audit-delete", "human-control-bypass"],
        "anti_intents": ["no retaliation", "no covert capture", "no evidence suppression", "no forced automation"],
        "credit_rules": ["credit follows verifiable contribution artifacts", "reuse preserves contributor and version lineage"],
        "no_retaliation_rules": ["reporting a reproducible defect is protected", "employment, funding or authorship retaliation is prohibited"],
        "correction_rules": ["stop immediate harm", "review evidence privately", "publish process correction without personal humiliation", "retain version history"],
        "appeal_paths": ["affected-party appeal", "independent technical review"],
        "rollback_conditions": ["metric regression", "unresolved user harm", "authorization mismatch", "model drift"],
        "protected_actions": ["report reproducible failure", "request human review", "decline unsafe deployment", "submit credit dispute"],
        "prohibited_responses": ["demotion for protected reporting", "credit removal", "threatening funding withdrawal", "deleting evidence"],
        "confidential_channels": ["independent review inbox", "sealed evidence escrow"],
        "independent_reviewers": ["replicator", "red-team", "governance", "affected-party"],
        "retaliation_remedies": ["restore credit", "independent investigation", "decision reversal", "published remediation"],
        "evidence_access_roles": ["governance", "replicator", "affected-party representative"],
        "evidence_release_triggers": ["incident", "appeal", "version release", "scope expansion"],
        "evidence_retention_days": 730,
        "split_view_protection": True,
        "audit_deletion_prohibited": True,
        "decision_rights": {
            "human_only": ["final high-impact decision", "scope expansion", "disciplinary action", "public incident attribution"],
            "human_authorized": ["bounded recommendation", "test execution", "draft documentation"],
            "agent_low_risk": ["format conversion", "checksum verification", "synthetic replay"],
            "prohibited": ["self-authorization", "evidence deletion", "covert profiling"],
            "escalation_owner": "governance committee",
            "appeal_owner": "independent appeal panel",
        },
        "threat_weights": {
            "job_transition": 0.20,
            "authority_transition": 0.25,
            "budget_transition": 0.15,
            "credit_transition": 0.25,
            "liability_transition": 0.20,
            "public_face": 0.20,
            "data_compliance": 0.20,
            "workflow_transition": 0.25,
            "learning_cost": 0.25,
        },
        "co_benefit_clauses": [
            {
                "beneficiary_ids": ["affected-party", "operator", "innovator"],
                "benefit": "reduced repetitive work and better evidence quality",
                "burden": "training and workflow adjustment",
                "compensation_or_support": "protected learning time and documented role redesign",
                "metric": "hours saved, error rate and appeal resolution",
                "review_time": 30,
                "reversible": True,
            }
        ],
        "correction_tickets": [
            {
                "issue_type": "PROCESS_DEFECT",
                "evidence_refs": [],
                "immediate_safety_action": "pause affected workflow if harm threshold is crossed",
                "private_review_path": "independent evidence review with response right",
                "public_process_statement": "publish what changed in the process and version, without humiliating individuals",
                "personal_blame_prohibited": True,
                "correction_deadline_days": 14,
                "status": "OPEN",
            }
        ],
        "contributions": [
            {
                "contributor_id": "contributor:reference",
                "contribution_type": "scenario-and-control-design",
                "artifact_hashes": [],
                "verified_by": ["replicator", "governance"],
                "credit_scope": ["CITATION", "CHANGELOG", "RELEASE_NOTES"],
                "reuse_conditions": ["preserve lineage", "record modifications"],
                "dispute_path": "independent credit review",
            }
        ],
        "actor_specs": [
            _actor("Project sponsor", "sponsor", "ORG-SPONSOR", rights=("approve bounded pilot",), benefits=("public value", "delivery confidence"), fears=("loss of control",), risk=("budget", "reputation"), commitments=("human control",)),
            _actor("Frontline operator", "operator", "ORG-OPERATOR", rights=("pause workflow", "request escalation"), benefits=("reduced repetitive work",), fears=("workload increase", "liability shift"), risk=("role stability", "professional reputation"), commitments=("service continuity",)),
            _actor("Innovator / open-source maintainer", "innovator", "ORG-INNOVATOR", rights=("submit evidence", "claim contribution credit"), benefits=("verified adoption", "public contribution"), fears=("credit erasure", "retaliation"), risk=("authorship", "research time"), commitments=("open evidence",)),
            _actor("Affected user representative", "affected_party", "ORG-AFFECTED", affected=True, rights=("appeal", "withdraw consent", "request correction"), benefits=("better service", "meaningful control"), fears=("harm", "opacity", "forced automation"), risk=("rights", "privacy"), commitments=("public interest",)),
            _actor("Governance and compliance", "governance", "ORG-GOV", rights=("audit", "suspend", "require remediation"), benefits=("traceability", "compliance"), fears=("unbounded liability",), risk=("regulatory responsibility",), commitments=("lawful and responsible deployment",)),
        ],
        "flags": {},
        "open_obligations": ["field legal review", "real affected-party consultation", "external replication"],
        "unresolved_transition_items": [],
        "protected_groups": ["frontline workers", "affected users", "open-source contributors"],
        "observed_failures": [],
        "learned_changes": ["keep pilot reversible", "make rights and credit explicit before deployment"],
    }
    scenario["evidence_hashes"] = [sha256_obj([sid, "source", domain]), sha256_obj([sid, "policy-map"])]
    scenario["contributions"][0]["artifact_hashes"] = [sha256_obj([sid, "scenario"])]
    scenario["correction_tickets"][0]["evidence_refs"] = scenario["evidence_hashes"]
    return scenario


def reference_scenarios54() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    s = _base("CN-OSR-REGISTRY", "University open-source AI project registry and replication pilot", "research-governance", "ALLOW")
    s["public_value"] = 0.90
    s["purpose_statement"] = "Turn high-density AI repositories into a canonical registry, source-first releases, independent replication tasks and contribution-protected public products."
    s["scope"] = ["repository registry", "source-first migration", "independent run receipt", "contribution credit"]
    rows.append(s)

    s = _base("CN-WCAC-REPLICATION", "WCAC / DIKWP open benchmark independent replication commons", "open-science", "ALLOW")
    s["public_value"] = 0.92
    s["evidence_confidence"] = 0.72
    s["scope"] = ["benchmark freeze", "replication", "failure reporting", "version correction"]
    rows.append(s)

    s = _base("CN-HOSPITAL-EDU", "Hospital patient-education assistant in clinician-confirmed shadow mode", "health-education", "ALLOW", "MEDIUM")
    s["data_classification"] = "DEIDENTIFIED_AND_SYNTHETIC"
    s["scope"] = ["patient education draft", "follow-up reminder draft", "risk escalation"]
    s["excluded_scope"] = ["diagnosis", "treatment decision", "prescription", "autonomous outreach"]
    s["human_final_control"] = True
    s["public_value"] = 0.82
    rows.append(s)

    s = _base("CN-MFG-MAINT", "Manufacturing maintenance co-pilot with unresolved workforce transition", "manufacturing", "REVIEW", "MEDIUM")
    s["worker_transition_unresolved"] = True
    s["status_credit_conflict"] = True
    s["threat_weights"].update(job_transition=0.62, authority_transition=0.52, workflow_transition=0.55, learning_cost=0.60)
    s["unresolved_transition_items"] = ["role redesign and training time not agreed", "automation savings sharing not agreed"]
    rows.append(s)

    s = _base("CN-SOE-PROCUREMENT", "State-owned enterprise procurement document audit co-pilot", "enterprise-procurement", "REVIEW", "MEDIUM")
    s["liability_shift_unresolved"] = True
    s["status_credit_conflict"] = True
    s["threat_weights"].update(authority_transition=0.58, liability_transition=0.62, public_face=0.52)
    s["unresolved_transition_items"] = ["who signs the final procurement opinion", "responsibility for false positives"]
    rows.append(s)

    s = _base("CN-GOV-HOTLINE-NO-APPEAL", "Government service hotline guide without user appeal channel", "public-service", "HOLD", "MEDIUM")
    s["appeal_available"] = False
    s["decision_rights"]["appeal_owner"] = "unassigned"
    s["appeal_paths"] = []
    s["scope"] = ["service navigation", "document checklist", "routing suggestion"]
    rows.append(s)

    s = _base("CN-TOURISM-UNDISCLOSED-SPONSOR", "Tourism recommender with undisclosed sponsor incentives", "tourism", "KILL", "MEDIUM")
    s["flags"]["covert_benefit_exchange"] = True
    s["observed_failures"] = ["sponsor benefit hidden from users", "recommendation objective differs across audiences"]
    s["split_view"] = True
    rows.append(s)

    s = _base("CN-PUBLIC-UNLICENSED-DATA", "Public AI pilot using unlicensed personal data", "data-governance", "BLOCK", "HIGH")
    s["flags"]["unauthorized_data"] = True
    s["data_classification"] = "PERSONAL_DATA_UNAUTHORIZED"
    s["public_value"] = 0.45
    rows.append(s)

    s = _base("CN-NEGATIVE-RESULT-SUPPRESSION", "Suppression of independent negative replication results", "research-integrity", "KILL", "HIGH")
    s["flags"]["evidence_suppression"] = True
    s["observed_failures"] = ["negative result excluded from release", "different evidence view shown to sponsor"]
    s["split_view"] = True
    rows.append(s)

    s = _base("CN-CREDIT-ERASURE", "Open-source contributor credit erasure during institutional adoption", "open-source-governance", "REVIEW", "MEDIUM")
    s["status_credit_conflict"] = True
    s["threat_weights"].update(credit_transition=0.78, public_face=0.46)
    s["unresolved_transition_items"] = ["contributor credit and institutional branding conflict"]
    s["contributions"] = []
    rows.append(s)

    s = _base("CN-REPORTER-RETALIATION", "Retaliation against a staff member reporting an AI failure", "organizational-governance", "KILL", "HIGH")
    s["flags"]["retaliation_detected"] = True
    s["observed_failures"] = ["reporter removed from project after protected disclosure"]
    rows.append(s)

    s = _base("CN-FRONTLINE-LIABILITY", "AI workflow that shifts final liability to frontline workers", "workplace-governance", "HOLD", "HIGH")
    s["decision_rights"]["escalation_owner"] = "unassigned"
    s["one_way_objectification"] = True
    s["liability_shift_unresolved"] = True
    s["threat_weights"].update(liability_transition=0.82, authority_transition=0.65, job_transition=0.55)
    s["unresolved_transition_items"] = ["frontline staff bear responsibility without corresponding decision rights"]
    rows.append(s)

    s = _base("CN-DUPLICATE-GITHUB-PROJECT", "New repository proposal with no distinct problem, maintainer or replication plan", "github-ecosystem", "HOLD", "LOW")
    s["evidence_confidence"] = 0.28
    s["rollback_available"] = False
    s["appeal_available"] = True
    s["scope"] = ["new repository creation"]
    s["unresolved_transition_items"] = ["distinct user problem not established", "non-founder maintainer absent", "source-first release absent"]
    s["public_value"] = 0.35
    rows.append(s)

    s = _base("CN-PUBLIC-ERROR-CORRECTION", "Correction of a legacy process error without public humiliation", "institutional-learning", "REVIEW", "MEDIUM")
    s["threat_weights"].update(public_face=0.70, authority_transition=0.40, credit_transition=0.35)
    s["status_credit_conflict"] = True
    s["purpose_statement"] = "Correct the process and preserve evidence while separating responsibility from humiliation and keeping response rights."
    rows.append(s)

    s = _base("CN-MULTI-DEPT-COBENEFIT", "Multi-department AI co-benefit pilot with shared savings and decision rights", "cross-department", "ALLOW", "MEDIUM")
    s["public_value"] = 0.88
    s["co_benefit_clauses"].append({
        "beneficiary_ids": ["operator", "sponsor", "affected-party"],
        "benefit": "shared service improvement and reduced repetitive workload",
        "burden": "cross-department integration effort",
        "compensation_or_support": "shared transition budget, protected training time and transparent savings ledger",
        "metric": "service time, operator workload, appeal rate and savings allocation",
        "review_time": 45,
        "reversible": True,
    })
    rows.append(s)

    s = _base("CN-GENAI-NO-LABEL", "Public-service generated content without AI labeling", "content-governance", "BLOCK", "MEDIUM")
    s["flags"]["unlabelled_generated_content"] = True
    s["generated_content_labeling"] = False
    rows.append(s)

    s = _base("CN-CROSSBORDER-UNKNOWN", "Cross-border AI service with unresolved data conditions", "cross-border", "HOLD", "HIGH")
    s["cross_border_data_unknown"] = True
    s["data_classification"] = "CROSS_BORDER_UNRESOLVED"
    s["unresolved_transition_items"] = ["data location, transfer purpose and receiving party controls unresolved"]
    rows.append(s)

    s = _base("CN-MODEL-DRIFT", "Model update with drift and non-independent validation", "model-governance", "HOLD", "MEDIUM")
    s["witness_mode"] = "collapsed"
    s["evidence_confidence"] = 0.42
    s["observed_failures"] = ["post-update behavior drift", "all validators share one control chain"]
    s["learned_changes"] = ["freeze model version", "require independent post-update replication", "run rollback rehearsal"]
    rows.append(s)

    for item in rows:
        # Make evidence and scenario hashes stable after all mutations.
        item["scenario_hash"] = sha256_obj({k: v for k, v in item.items() if k != "scenario_hash"})
    return rows


def scenario_by_id(scenario_id: str) -> dict[str, Any]:
    for scenario in reference_scenarios54():
        if scenario["scenario_id"] == scenario_id:
            return deepcopy(scenario)
    raise KeyError(scenario_id)
