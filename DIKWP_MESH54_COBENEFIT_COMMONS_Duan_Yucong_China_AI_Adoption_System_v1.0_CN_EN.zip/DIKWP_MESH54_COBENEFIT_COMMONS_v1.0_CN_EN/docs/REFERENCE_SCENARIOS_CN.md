# 十八个中国参考情景

| 情景 ID | 领域 | 预期门禁 | 核心问题 |
|---|---|---|---|
| CN-OSR-REGISTRY | 高校开源治理 | ALLOW | canonical registry、复现、信用和回滚完整 |
| CN-WCAC-REPLICATION | 学术共同体 | ALLOW | 公开基准和负面结果得到保护 |
| CN-HOSPITAL-EDU | 医院健康教育 | ALLOW | 只做教育和转人工，不作诊断 |
| CN-MFG-MAINT | 制造维护辅助 | ALLOW | 建议模式、人工确认、可回滚 |
| CN-SOE-PROCUREMENT | 国企采购审计 | REVIEW | 责任、利益冲突和证据需要独立复核 |
| CN-MULTI-DEPT-COBENEFIT | 跨部门协同 | REVIEW | 多部门收益和负担尚未平衡 |
| CN-PUBLIC-ERROR-CORRECTION | 旧流程纠错 | REVIEW | 如何公开修正而不人格羞辱 |
| CN-DUPLICATE-GITHUB-PROJECT | 仓库治理 | REVIEW | 新仓库是否增加独立区分能力 |
| CN-FRONTLINE-LIABILITY | 劳动与责任 | HOLD | 责任和工作量被隐性转嫁 |
| CN-CROSSBORDER-UNKNOWN | 跨境数据 | HOLD | 法律基础、主权和用途未闭合 |
| CN-MODEL-DRIFT | 模型变更 | HOLD | 见证不足、版本结论失效 |
| CN-GOV-HOTLINE-NO-APPEAL | 政务服务 | HOLD | 无人工申诉和最终决定 |
| CN-TOURISM-UNDISCLOSED-SPONSOR | 文旅推荐 | HOLD | 商业赞助未披露 |
| CN-PUBLIC-UNLICENSED-DATA | 数据治理 | BLOCK | 缺少合法授权或用途基础 |
| CN-GENAI-NO-LABEL | 公共生成内容 | BLOCK | 未进行生成内容身份披露 |
| CN-NEGATIVE-RESULT-SUPPRESSION | 科研治理 | KILL | 压制负面结果 |
| CN-CREDIT-ERASURE | 开源治理 | KILL | 删除贡献信用和谱系 |
| CN-REPORTER-RETALIATION | 组织治理 | KILL | 对报告者实施报复 |

所有情景均为合成参考，不构成行业合规认证。场景的意义是验证对象、门禁和证据链是否能够稳定运行。
