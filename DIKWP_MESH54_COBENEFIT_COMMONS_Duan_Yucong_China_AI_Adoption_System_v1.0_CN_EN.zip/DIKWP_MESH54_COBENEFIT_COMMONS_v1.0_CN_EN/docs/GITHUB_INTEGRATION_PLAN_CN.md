# 段玉聪 GitHub 生态接入计划

## 1. 当前结构信号

2026-07-23 的公开快照显示，账户约有 231 个仓库、0 个 Projects、0 个 Packages 和 251 Stars。最近一天仍在密集增加 PHENOMESH、UNBOUND-GENESIS、PARALLAX、HYPERWEAVE、ANTITHESIS、MESHFORMER、ALOGOS 等项目。这个结构不代表项目质量低，而说明概念和原型生成速度远高于外部选择、复现和共同维护速度。

CIVICLOOP、TRUSTDISTILL 等代表性仓库已经交付了完整参考系统和严格边界，但公开根目录仍主要是 ZIP、README 和 LICENSE，且 Issue、Pull Request、Fork 较少。最缺失的不是内容，而是“外部如何进入并改变项目”的公共工作流。

## 2. 本系统的接入位置

Co-Benefit Adoption Commons 不应成为第 232 个平级终极系统。建议作为以下三种形式之一：

1. `DIKWP-MESH54-RUNTIME` 的 `institutional_adoption` 子包；
2. NEXUS / RELAY / SIWEN / CIVICLOOP 的共用试点治理模块；
3. 一个 canonical 中国落地 Project 的工作台，而非新理论主线。

## 3. 先建立 Project，不先建立新仓库

GitHub Project 建议使用以下字段：

- Mission；
- Root Problem；
- Repository / Module；
- Pilot Stage；
- Gate；
- Evidence Grade；
- Affected Parties；
- Credit Receipts；
- Independent Witnesses；
- Open Obligations；
- Kill Condition；
- Next Review。

## 4. Repo Birth Gate

新仓库必须同时满足：

- 存在无法在现有模块中表达的独立问题；
- 有 source-first 代码和测试；
- 有独立用户或采用方；
- 有至少一名非创始维护者候选；
- 有证据计划、失败分类和 Kill 条件；
- 有明确归并和归档路径；
- 通过共益、信用、反报复和转型成本审查。

否则保存为 Issue、Scenario、Schema、Adapter、Benchmark 或 Horizon Hypothesis。

## 5. 首批接入对象

| 现有方向 | 接入方式 |
|---|---|
| MESH 5.4 | 复用 Intent Field、reciprocity、witness 和 transparency |
| RUNTIME Commons | 复用对象、Schema、TCK 和 Package 发布 |
| CIVICLOOP | 复用人类控制、申诉和普惠收益对象 |
| SIWEN | 对接中国政策条款和场景门禁 |
| TRUSTFABRIC | 对接跨组织信任和公共产品网关 |
| NEXUS | 实施 source-first 迁移和模块注册 |
| RELAY | 分配外部复现、维护者和场景任务 |
| PACT | 复用 Purpose / Permission / Trace 评测 |

## 6. 第一批 Issues

1. 建立 canonical repository registry；
2. 把三个旗舰仓库迁移为 source-first；
3. 冻结共益宪约 Schema v1；
4. 建立信用争议和报复报告模板；
5. 运行 18 个参考情景；
6. 邀请两名非创始见证者；
7. 完成第一个高校开源项目登记影子试点；
8. 发布第一次 InstitutionalLearningRelease。
