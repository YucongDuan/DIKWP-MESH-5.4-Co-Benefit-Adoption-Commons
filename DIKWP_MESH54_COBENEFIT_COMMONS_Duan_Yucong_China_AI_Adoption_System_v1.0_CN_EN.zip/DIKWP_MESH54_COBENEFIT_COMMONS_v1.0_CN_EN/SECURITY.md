# Security and Misuse Boundaries

Report vulnerabilities through the repository security channel before public disclosure when exploitation could cause harm.

The system must not be used for:

- covert persuasion, bribery, patronage or personal-vulnerability exploitation;
- identifying or punishing so-called vested interests;
- employment, disciplinary, credit, insurance, benefit or political-likelihood decisions;
- bypassing human final control or lawful approval;
- hiding negative results from one audience while showing them to another;
- deleting, rewriting or selectively presenting audit evidence;
- medical diagnosis, autonomous public authority or critical infrastructure control.

Hard-stop indicators include retaliation, evidence suppression, split views, covert benefit exchange, audit deletion and human-control bypass.
