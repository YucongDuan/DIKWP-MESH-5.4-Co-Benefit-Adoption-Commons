# 快速启动

## 1. 安装

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install vendor/dikwp_mesh5_phi0-5.4.0-py3-none-any.whl
python -m pip install -e .
```

Windows PowerShell：

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
py -m pip install vendor\dikwp_mesh5_phi0-5.4.0-py3-none-any.whl
py -m pip install -e .
```

## 2. 运行18个参考情景

```bash
dikwp-cobenefit54 demo --out outputs/demo
```

打开：

```text
outputs/demo/dashboard.html
```

## 3. 评估单个情景

```bash
dikwp-cobenefit54 assess CN-OSR-REGISTRY --out outputs/one
```

或评估自定义 JSON：

```bash
dikwp-cobenefit54 assess examples/scenarios/CN-MFG-MAINT.json --out outputs/custom
```

## 4. 验证参考结果和账本

```bash
dikwp-cobenefit54 validate --out outputs/validation
dikwp-cobenefit54 verify-ledger outputs/validation/institutional_learning_ledger.jsonl
pytest -q
```

## 5. 阅读输出

- `summary.json`：总体指标。
- `adoption_gate_table.json`：18类情景的门禁、原因与下一步。
- `assessments.json`：完整 Mesh 5.4 意图场、机构图册、共益契约、权利矩阵和证据。
- `institutional_learning_ledger.jsonl`：追加式学习账本。
- `institutional_learning_release.json`：版本结算。
- `transparency/`：每个情景的签名透明日志和必要的分裂视图测试。

## 6. 自定义情景的最低字段

以 `examples/scenarios/CN-OSR-REGISTRY.json` 为模板。至少明确：

- 项目目的和风险等级；
- 主体与受影响方；
- 决策权；
- 数据条件；
- 人类最终控制；
- 申诉和回滚；
- 独立见证；
- 共益条款；
- 贡献信用；
- 反报复；
- 纠错和 Kill 条件。
