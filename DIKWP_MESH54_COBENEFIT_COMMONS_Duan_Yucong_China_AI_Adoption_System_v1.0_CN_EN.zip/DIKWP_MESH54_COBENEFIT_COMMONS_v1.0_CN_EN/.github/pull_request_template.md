## Purpose / 目的

## Affected parties / 受影响主体

## Evidence and tests / 证据与测试

## Contribution credit / 贡献信用

## New burdens or rights changes / 新增负担或权利变化

## Rollback and kill conditions / 回滚与终止条件

## Open residuals / 开放残余
