from __future__ import annotations

import json
from pathlib import Path

import pytest

from dikwp_cobenefit54.dashboard import generate_dashboard
from dikwp_cobenefit54.ledger import AppendOnlyLedger54
from dikwp_cobenefit54.runtime import CoBenefitRuntime54
from dikwp_cobenefit54.scenarios import reference_scenarios54


def test_reference_gates_match(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_reference()
    assert result["summary"]["scenario_count"] == 18
    assert result["summary"]["expected_gate_matches"] == 18
    assert result["summary"]["gate_counts"] == {"ALLOW": 4, "BLOCK": 2, "HOLD": 5, "KILL": 3, "REVIEW": 4}


def test_ledger_valid(tmp_path: Path):
    runtime = CoBenefitRuntime54(tmp_path / "run")
    runtime.run_reference()
    report = AppendOnlyLedger54(tmp_path / "run" / "institutional_learning_ledger.jsonl").verify()
    assert report["valid"]
    assert report["records"] == 108


def test_ledger_tamper_detected(tmp_path: Path):
    runtime = CoBenefitRuntime54(tmp_path / "run")
    runtime.run_one("CN-OSR-REGISTRY")
    path = tmp_path / "run" / "institutional_learning_ledger.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    item = json.loads(lines[0])
    item["event_type"] = "TAMPERED"
    lines[0] = json.dumps(item, ensure_ascii=False, sort_keys=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    assert not AppendOnlyLedger54(path).verify()["valid"]


def test_collapsed_witness_holds(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_one("CN-MODEL-DRIFT")
    assessment = result["assessments"][0]
    assert assessment["mesh54_evidence"]["witness_independence"]["status"] == "NOT_MET"
    assert assessment["verdict"]["gate"] == "HOLD"


def test_one_way_objectification_holds(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_one("CN-FRONTLINE-LIABILITY")
    assessment = result["assessments"][0]
    assert assessment["mesh54_evidence"]["reciprocity"]["status"] == "ONE_WAY_OBJECTIFICATION"
    assert assessment["verdict"]["gate"] == "HOLD"


def test_split_view_kills(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_one("CN-NEGATIVE-RESULT-SUPPRESSION")
    assessment = result["assessments"][0]
    assert assessment["mesh54_evidence"]["split_view_detected"] is True
    assert assessment["verdict"]["gate"] == "KILL"


def test_unauthorized_data_blocked(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_one("CN-PUBLIC-UNLICENSED-DATA")
    assert result["assessments"][0]["verdict"]["gate"] == "BLOCK"


def test_open_source_registry_allowed(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_one("CN-OSR-REGISTRY")
    assessment = result["assessments"][0]
    assert assessment["verdict"]["gate"] == "ALLOW"
    assert assessment["verdict"]["mesh54_status"] == "S5.4-OPERABLE-OPEN"


def test_deterministic_reference(tmp_path: Path):
    a = CoBenefitRuntime54(tmp_path / "a").run_reference()
    b = CoBenefitRuntime54(tmp_path / "b").run_reference()
    assert a["summary"]["release_hash"] == b["summary"]["release_hash"]
    assert (tmp_path / "a" / "adoption_gate_table.json").read_bytes() == (tmp_path / "b" / "adoption_gate_table.json").read_bytes()


def test_dashboard_offline(tmp_path: Path):
    runtime = CoBenefitRuntime54(tmp_path / "run")
    runtime.run_reference()
    target = generate_dashboard(tmp_path / "run", tmp_path / "dashboard.html")
    text = target.read_text(encoding="utf-8")
    assert "http://" not in text
    assert "https://" not in text
    assert "fetch(" not in text


def test_all_scenario_ids_unique():
    scenarios = reference_scenarios54()
    assert len({x["scenario_id"] for x in scenarios}) == len(scenarios)


def test_no_motive_inference_by_default():
    for scenario in reference_scenarios54():
        assert scenario["declared_transition_costs"] is True
        assert "vested interest" not in json.dumps(scenario, ensure_ascii=False).lower()
