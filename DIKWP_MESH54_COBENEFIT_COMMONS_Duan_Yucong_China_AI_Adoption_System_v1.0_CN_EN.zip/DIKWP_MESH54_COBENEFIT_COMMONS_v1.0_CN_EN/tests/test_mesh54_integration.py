from __future__ import annotations

from dikwp_phi0.intent54 import verify_intent_field_covenant54

from dikwp_cobenefit54.builders import build_actor54
from dikwp_cobenefit54.mesh54_bridge import build_mesh54_intent_covenant
from dikwp_cobenefit54.scenarios import scenario_by_id


def test_real_mesh54_intent_covenant_is_valid():
    scenario = scenario_by_id("CN-OSR-REGISTRY")
    actors = [build_actor54(spec, scenario["evidence_hashes"]) for spec in scenario["actor_specs"]]
    covenant = build_mesh54_intent_covenant(scenario, actors)
    assert covenant.framework_version == "5.4"
    assert verify_intent_field_covenant54(covenant)
    assert len(covenant.intent_nodes) >= len(actors) + 4
    assert any(node.polarity == "AVOID" for node in covenant.intent_nodes)
