from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

from dikwp_cobenefit54.runtime import CoBenefitRuntime54

ROOT = Path(__file__).resolve().parents[1]


def test_all_schemas_are_valid():
    for path in sorted((ROOT / "schemas").glob("*.json")):
        Draft202012Validator.check_schema(json.loads(path.read_text(encoding="utf-8")))


def test_reference_objects_validate(tmp_path: Path):
    result = CoBenefitRuntime54(tmp_path / "run").run_reference()
    schemas = {p.stem.replace(".schema", ""): json.loads(p.read_text(encoding="utf-8")) for p in (ROOT / "schemas").glob("*.json")}
    validators = {name: Draft202012Validator(schema) for name, schema in schemas.items()}
    checked = 0
    for a in result["assessments"]:
        for actor in a["actors"]:
            validators["institutional_actor54"].validate(actor); checked += 1
        for signal in a["threats"]:
            validators["institutional_threat_signal54"].validate(signal); checked += 1
        validators["transition_cost_map54"].validate(a["transition_cost"]); checked += 1
        validators["co_benefit_covenant54"].validate(a["co_benefit_covenant"]); checked += 1
        validators["decision_rights_matrix54"].validate(a["decision_rights"]); checked += 1
        validators["pilot_cell54"].validate(a["pilot"]); checked += 1
        validators["institutional_atlas54"].validate(a["atlas"]); checked += 1
        validators["adoption_gate_verdict54"].validate(a["verdict"]); checked += 1
        validators["pilot_outcome54"].validate(a["outcome"]); checked += 1
    validators["institutional_learning_release54"].validate(result["release"]); checked += 1
    assert checked > 250
