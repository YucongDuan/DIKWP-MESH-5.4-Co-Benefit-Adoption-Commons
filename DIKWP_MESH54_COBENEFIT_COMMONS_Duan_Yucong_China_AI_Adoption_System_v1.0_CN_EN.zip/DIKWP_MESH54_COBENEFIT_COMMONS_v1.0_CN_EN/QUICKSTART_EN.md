# Quick Start

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install vendor/dikwp_mesh5_phi0-5.4.0-py3-none-any.whl
python -m pip install -e .
dikwp-cobenefit54 demo --out outputs/demo
```

Open `outputs/demo/dashboard.html`.

Assess one reference scenario:

```bash
dikwp-cobenefit54 assess CN-OSR-REGISTRY --out outputs/one
```

Validate all gates and the append-only ledger:

```bash
dikwp-cobenefit54 validate --out outputs/validation
pytest -q
```
