# Governance

## Purpose

The project governs bounded AI pilots, not people. It must never be used as a loyalty score, personality score, political-risk score or hidden-interest detector.

## Decision bodies

- Protocol maintainers: maintain code, schemas and conformance tests.
- Independent reviewers: replicate results and audit gate changes.
- Affected-party panel: reviews user rights, appeals, burden transfer and exclusion.
- Release steward: compiles a versioned public release; cannot unilaterally change protected rules.

## Protected rules

Changes to no-retaliation, evidence preservation, human final control, appeal, contributor credit, split-view detection and rollback require:

1. a public proposal;
2. a before/after diff;
3. a shadow evaluation;
4. approval by at least three independent witness components, including an affected-party role;
5. a rollback path;
6. a new version and changelog.

## Conflict of interest

Reviewers disclose organization, funding, software lineage, data lineage and jurisdiction. Multiple reviewers controlled by the same chain count as one independent component.

## Appeals

Any person whose rights, work, credit, reputation or data may be affected can request correction, evidence access within lawful limits, independent review, suspension or rollback.
