# Contributing

Contributions are accepted as code, schemas, documentation, scenarios, translations, replication receipts, negative results, security findings and field-learning reports.

Every contribution should include:

- problem and affected parties;
- source and license;
- test or reproducible evidence;
- expected benefit and burden;
- risk and rollback;
- contributor credit request;
- conflicts of interest.

A reproducible failure is a valid contribution. Maintainers must not suppress or devalue negative results merely because they challenge a flagship claim.
