from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

ROOT = Path('/mnt/data/DIKWP_MESH54_COBENEFIT_COMMONS_v1.0_CN_EN')
OUT = ROOT / 'docs' / '段玉聪_DIKWP-MESH54_COBENEFIT_COMMONS_中国AI共益试点与创新者保护系统_v1.0_CN_最终版.docx'

BODY_FONT = 'Noto Serif CJK SC'
HEAD_FONT = 'Noto Sans CJK SC'
MONO_FONT = 'Noto Sans Mono CJK SC'


def set_east_asia_font(run, font_name: str, size: float | None = None, bold: bool | None = None, color=None):
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor(*color)


def set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tc_pr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_margins(cell, top=80, start=80, bottom=80, end=80):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')


def repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), 'true')
    trPr.append(tblHeader)


def set_repeat_table_header(row):
    repeat_table_header(row)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run('第 ')
    set_east_asia_font(run, BODY_FONT, 9)
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = ' PAGE '
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar1)
    run._r.append(instrText)
    run._r.append(fldChar2)
    run2 = paragraph.add_run(' 页')
    set_east_asia_font(run2, BODY_FONT, 9)


def setup_styles(doc: Document):
    styles = doc.styles
    normal = styles['Normal']
    normal.font.name = BODY_FONT
    normal._element.rPr.rFonts.set(qn('w:eastAsia'), BODY_FONT)
    normal.font.size = Pt(10.5)
    normal.paragraph_format.line_spacing = 1.35
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.first_line_indent = Cm(0.74)

    title = styles['Title']
    title.font.name = HEAD_FONT
    title._element.rPr.rFonts.set(qn('w:eastAsia'), HEAD_FONT)
    title.font.size = Pt(25)
    title.font.bold = True
    title.font.color.rgb = RGBColor(27, 62, 97)

    subtitle = styles['Subtitle']
    subtitle.font.name = HEAD_FONT
    subtitle._element.rPr.rFonts.set(qn('w:eastAsia'), HEAD_FONT)
    subtitle.font.size = Pt(14)
    subtitle.font.color.rgb = RGBColor(65, 93, 122)

    for level, size, color in [
        (1, 16, (27, 62, 97)),
        (2, 13.5, (44, 82, 120)),
        (3, 11.5, (61, 98, 133)),
        (4, 10.5, (70, 70, 70)),
    ]:
        style = styles[f'Heading {level}']
        style.font.name = HEAD_FONT
        style._element.rPr.rFonts.set(qn('w:eastAsia'), HEAD_FONT)
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(*color)
        style.paragraph_format.space_before = Pt(9 if level == 1 else 6)
        style.paragraph_format.space_after = Pt(4)
        style.paragraph_format.keep_with_next = True

    for name in ['Caption', 'Quote']:
        s = styles[name]
        s.font.name = BODY_FONT
        s._element.rPr.rFonts.set(qn('w:eastAsia'), BODY_FONT)

    quote = styles['Quote']
    quote.font.size = Pt(10)
    quote.font.color.rgb = RGBColor(70, 70, 70)
    quote.paragraph_format.left_indent = Cm(0.7)
    quote.paragraph_format.right_indent = Cm(0.7)
    quote.paragraph_format.first_line_indent = Cm(0)
    quote.paragraph_format.space_before = Pt(5)
    quote.paragraph_format.space_after = Pt(5)


def add_para(doc: Document, text: str, bold_prefix: str | None = None, style: str | None = None, align=None):
    p = doc.add_paragraph(style=style)
    if bold_prefix and text.startswith(bold_prefix):
        r1 = p.add_run(bold_prefix)
        set_east_asia_font(r1, BODY_FONT, 10.5, True)
        r2 = p.add_run(text[len(bold_prefix):])
        set_east_asia_font(r2, BODY_FONT, 10.5)
    else:
        r = p.add_run(text)
        set_east_asia_font(r, BODY_FONT, 10.5)
    if align is not None:
        p.alignment = align
    return p


def add_bullets(doc: Document, items: Iterable[str], level=0):
    for item in items:
        p = doc.add_paragraph(style='List Bullet' if level == 0 else 'List Bullet 2')
        p.paragraph_format.first_line_indent = Cm(0)
        r = p.add_run(item)
        set_east_asia_font(r, BODY_FONT, 10.2)


def add_numbered(doc: Document, items: Iterable[str]):
    for item in items:
        p = doc.add_paragraph(style='List Number')
        p.paragraph_format.first_line_indent = Cm(0)
        r = p.add_run(item)
        set_east_asia_font(r, BODY_FONT, 10.2)


def add_code(doc: Document, code: str):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    cell = table.cell(0, 0)
    set_cell_shading(cell, 'F3F6F8')
    set_cell_margins(cell, 120, 140, 120, 140)
    p = cell.paragraphs[0]
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_after = Pt(0)
    for i, line in enumerate(code.strip('\n').splitlines()):
        if i:
            p.add_run().add_break()
        r = p.add_run(line)
        set_east_asia_font(r, MONO_FONT, 8.8)
    return table


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[float] | None = None, font_size=8.7):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    table.autofit = True
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for idx, h in enumerate(headers):
        cell = hdr.cells[idx]
        set_cell_shading(cell, 'D9E8F5')
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        r = p.add_run(h)
        set_east_asia_font(r, HEAD_FONT, font_size, True, (27, 62, 97))
        if widths:
            cell.width = Cm(widths[idx])
    for row in rows:
        cells = table.add_row().cells
        for idx, text in enumerate(row):
            cell = cells[idx]
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
            p = cell.paragraphs[0]
            p.paragraph_format.first_line_indent = Cm(0)
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(str(text))
            set_east_asia_font(r, BODY_FONT, font_size)
            if widths:
                cell.width = Cm(widths[idx])
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_callout(doc: Document, title: str, text: str, fill='EAF2F8'):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = 'Table Grid'
    c = t.cell(0, 0)
    set_cell_shading(c, fill)
    set_cell_margins(c, 130, 160, 130, 160)
    p = c.paragraphs[0]
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run(title + '\n')
    set_east_asia_font(r, HEAD_FONT, 11.5, True, (27, 62, 97))
    r2 = p.add_run(text)
    set_east_asia_font(r2, BODY_FONT, 10.2)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_figure(doc: Document, path: Path, caption: str, width_cm=15.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run()
    r.add_picture(str(path), width=Cm(width_cm))
    cap = doc.add_paragraph(style='Caption')
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.first_line_indent = Cm(0)
    rr = cap.add_run(caption)
    set_east_asia_font(rr, BODY_FONT, 9)


def add_section_break(doc: Document):
    doc.add_section(WD_SECTION.NEW_PAGE)


def make_doc():
    doc = Document()
    setup_styles(doc)
    sec = doc.sections[0]
    sec.top_margin = Cm(1.8)
    sec.bottom_margin = Cm(1.7)
    sec.left_margin = Cm(2.0)
    sec.right_margin = Cm(2.0)
    sec.header_distance = Cm(0.8)
    sec.footer_distance = Cm(0.8)

    header = sec.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    hr = header.add_run('DIKWP-MESH 5.4 Co-Benefit Adoption Commons · v1.0')
    set_east_asia_font(hr, HEAD_FONT, 8.5, False, (90, 100, 110))
    add_page_number(sec.footer.paragraphs[0])

    # Cover
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(55)
    r = p.add_run('DIKWP-MESH 5.4')
    set_east_asia_font(r, HEAD_FONT, 30, True, (27, 62, 97))
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run('Co-Benefit Adoption Commons')
    set_east_asia_font(r2, HEAD_FONT, 23, True, (44, 82, 120))
    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.paragraph_format.space_before = Pt(12)
    r3 = p3.add_run('段玉聪中国 AI 共益试点、体面纠错、贡献保护与组织适配系统')
    set_east_asia_font(r3, HEAD_FONT, 16, True, (45, 45, 45))
    p4 = doc.add_paragraph()
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r4 = p4.add_run('面向高校、科研共同体、国有企事业单位与低风险公共服务的 GitHub-ready 参考实现')
    set_east_asia_font(r4, BODY_FONT, 11, False, (80, 80, 80))

    doc.add_paragraph()
    add_callout(doc, '核心判断',
        '段玉聪现阶段不缺少新的概念系统，缺少的是把高密度开源资产转化为中国组织能够安全接纳、利益与负担可以公开协商、创新者和失败报告者受到保护、受影响者具有真实权利、外部世界能够反向修改项目的制度化运行层。',
        fill='DDEBF7')

    meta = add_table(doc, ['项目项', '内容'], [
        ['交付版本', 'v1.0.0 / 2026-07-23'],
        ['运行模式', 'DIKWP-MESH 5.4 / S5.4-OPERABLE-OPEN'],
        ['证据等级', 'E2：作者侧确定性合成参考；不构成真实部署认证'],
        ['当前 GitHub 快照', '231 repositories / 0 Projects / 0 Packages / 251 Stars / 386 followers'],
        ['首个建议试点', '高校或 WCAC 开源 AI 项目登记、复现、贡献信用与影子采用'],
        ['正式边界', '非法律、医疗、就业、采购、政治评价或生产控制系统'],
    ], widths=[4.2, 11.4], font_size=9.3)

    pdate = doc.add_paragraph()
    pdate.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pdate.paragraph_format.space_before = Pt(18)
    rr = pdate.add_run('信息与代码校验日期：2026 年 7 月 23 日')
    set_east_asia_font(rr, BODY_FONT, 10, False, (90, 90, 90))

    doc.add_page_break()

    # Document statement
    doc.add_heading('文档声明与证据边界', level=1)
    add_para(doc, '本文件基于用户上传的 DIKWP-MESH 5.4 完整交付包、段玉聪 GitHub 公开页面快照、中国现行人工智能政策材料、用户提供的百度虚构文章，以及《Defining Life: A Conversation》和 WCAC 2026 未来发展报告编制。来源中的事实、观点和工程推断在正文中分开表述。')
    add_para(doc, '用户提供的百度文章末尾明确写有“本文为虚构小说，请勿与现实关联”。本文件不把其中人物故事作为历史证据，不采纳其隐蔽收买、伪装能力、掌握隐私或操纵脆弱性的做法；只把它当作一种关于组织改革摩擦的高噪声压力叙事，并将其中可验证问题重构为公开共益、体面纠错、贡献信用、反报复和可逆试点。')
    add_para(doc, '本文所称“机构图册”“转型成本”“共益”均不是对人的人格、忠诚、道德或政治立场评分。系统不得用于建立黑名单、推断敌我、就业处分、采购定标、资格审查或隐蔽画像。')
    add_para(doc, 'GitHub 数字是 2026-07-23 的公开网页快照，可能随时间变化；代表性仓库结构仅描述公共根目录和可见协作信号，不推断 ZIP 内部是否缺少完整源码，也不构成对项目质量的否定。')

    doc.add_heading('目录', level=1)
    toc_items = [
        '1. 执行摘要与最终判断', '2. Mesh 5.4 方法基线', '3. 段玉聪 GitHub 生态深度诊断',
        '4. 中国当前政策与落地窗口', '5. 对所附文章的辩证重构', '6. 系统总体架构',
        '7. 十八类机器可读对象', '8. 机构局部图册与语义曲率', '9. 共益宪约',
        '10. 体面纠错', '11. 贡献信用与反报复', '12. 决策权和人类最终控制',
        '13. 证据托管、独立见证和分裂视图检测', '14. 五级采用门禁', '15. 十八个中国参考情景',
        '16. 首个落地试点', '17. 90 天执行路线', '18. GitHub 接入与仓库诞生门禁',
        '19. 指标、风险与终止条件', '20. 未来 12 个月路线', '附录 A-C：模板、字段与来源'
    ]
    add_numbered(doc, toc_items)

    # 1 Executive summary
    doc.add_heading('1. 执行摘要与最终判断', level=1)
    add_para(doc, '中国人工智能应用正在从“模型生成内容”进入“智能体参与行动”的阶段。政策层面同时强调创新驱动、应用牵引、安全可控、开放共享、人的最终决定权、行为可验证可追溯和劳动者权益。对段玉聪而言，这一窗口并不要求再提出一个更宏大的抽象系统，而要求把已经存在的 DIKWP、MESH、PACT、CIVICLOOP、SIWEN、TRUSTFABRIC、RUNTIME、NEXUS 和 RELAY 等资产组织成一个真实单位愿意采用、能够暂停、可以纠错、可保护贡献者并能在失败后继续学习的公共试点机制。')
    add_para(doc, '截至 2026-07-23，GitHub 公开页面显示该账户约有 231 个仓库、0 个 Projects、0 个 Packages 和 251 Stars，最新一天仍有多个关于意识、无言场、世界线、因果、语义和模型原生架构的新仓库。这个结构的优势是原创和原型产量高，风险是外部注意被新命名持续切分，复现者难以确认主入口，贡献和维护缺乏长期统一队列，组织采用方也无法判断谁负责版本、失败、信用和退出。')
    add_callout(doc, '缺失的关键系统', '不是“怎样让强者隐藏能力”，而是怎样让组织不必通过压制创新来维持稳定，也让创新者不必通过权谋才能获得生存空间。系统应把能力暴露改成分阶段试点，把利益交换改成公开共益，把面子冲突改成体面纠错，把精神认同改成多主体意图场，把被抹除风险改成可验证贡献信用，把反扑担忧改成可观测转型成本和反报复制度。')
    add_para(doc, '本次交付形成一个可执行 Python 运行时、19 类 JSON Schema、18 个中国合成情景、Mesh 5.4 实际意图场、Ed25519 见证、透明度日志、分裂视图检测、追加式学习账本、离线驾驶舱、GitHub 工作流、Issue 模板、90 天计划和最终技术规范。参考运行得到 ALLOW 4、REVIEW 4、HOLD 5、BLOCK 2、KILL 3，18/18 与预期门禁一致。')

    # 2 Mesh5.4
    doc.add_heading('2. Mesh 5.4 方法基线', level=1)
    add_para(doc, '用户上传的 Mesh 5.4 包明确纠正了四类旧假设：用一个全局映射覆盖全部语境、用一个静态 Purpose 代表复数意图、用 CLOSED 声称开放系统的全局闭合，以及用不同 ID 近似真正独立见证。5.4 改用局部图册和 seam、复数 Intent Field Covenant、S5.4-OPERABLE-OPEN、见证独立性图、gossip checkpoint、split-view 检测、UAX 残余、规则变异和事务化验证。')
    add_table(doc, ['Mesh 5.4 原则', '本系统中的落地'], [
        ['局部图册，不作全局语义垄断', '每个主体拥有 InstitutionalChart，跨主体解释形成 seam 和 loop'],
        ['复数意图、反意图与修订触发', 'Sponsor、Operator、Innovator、Affected Party、Governance 分别表达目的和否决'],
        ['S5.4-OPERABLE-OPEN', '只允许限定试点，并保留法律审查、受影响者咨询和外部复现义务'],
        ['观察者—主体互惠', '检测把一线人员或用户仅当数据与执行对象的单向客体化'],
        ['独立见证而非角色数量', '用 Ed25519 身份、独立性图和 required independent count 评估见证'],
        ['分裂视图检测', '比较不同受众看到的证据检查点，发现选择性披露'],
        ['开放残余', '未解决的法律、文化、数据和责任问题不会被平均为“已解决”'],
        ['规则可修订且可回滚', '通过 InstitutionalLearningRelease 版本化修正门禁和宪约'],
    ], widths=[5.0, 10.6], font_size=8.8)
    add_para(doc, 'Mesh 5.4 的重要含义是：组织采用不是把一个完成的技术对象放进一个被动机构，而是项目、管理者、一线人员、用户、治理者和外部环境相互改变。附件《Defining Life: A Conversation》关于过程—对象不可永久分离、观察者和对象相互作用、开放状态空间与规则变化的讨论，为这种反身设计提供了方法学参照；该文第 22—23 页的形态空间图还强调空白区域和未出现组合本身是研究对象。')

    # 3 Github
    doc.add_heading('3. 段玉聪 GitHub 生态深度诊断', level=1)
    add_heading = doc.add_heading
    add_heading('3.1 公开结构快照', level=2)
    add_table(doc, ['指标', '2026-07-23 快照', '结构含义'], [
        ['Repositories', '231', '高密度思想与原型资产；外部入口和资源分配压力增加'],
        ['Projects', '0', '缺少跨仓库任务、证据、责任和版本的统一控制面'],
        ['Packages', '0', '运行时和对象模型尚未以公共依赖方式被持续消费'],
        ['Stars', '251', '已存在外部注意，但尚需转化为运行、复现和维护'],
        ['Followers', '386', '传播网络存在，应转为可验证贡献队列'],
    ], widths=[3.0, 3.6, 9.0], font_size=9)
    add_para(doc, '最新仓库集中于 PHENOMESH、UNBOUND-GENESIS、PARALLAX、HYPERWEAVE、ANTITHESIS、MESHFORMER、ALOGOS、SCALE、NOEMA、Evidence Grid、CIVICLOOP、TRUSTDISTILL、TRUSTFABRIC、RUNTIME、IMMUNET 等相邻问题。这说明“发现和命名新空间”的能力很强，但也表明同一底层根问题可能被多次投影为新仓库，外部共同体需要一个可验证的归并和诞生门禁。')

    add_heading('3.2 代表性仓库的共同信号', level=2)
    add_para(doc, 'CIVICLOOP 已经提供人类控制、争议、伦理规则修订和普惠收益账本；TRUSTDISTILL 已经提供目的约束、证据携带、发布护照和事故恢复；RUNTIME、TRUSTFABRIC、SIWEN 和 IMMUNET 分别覆盖对象模型、互操作、政策转译和风险互助。问题不是功能缺失，而是这些系统之间的采用责任、组织转型、贡献信用、失败保护和共同维护尚未成为统一公共协议。')
    add_table(doc, ['观察信号', '潜在后果', '本系统补位'], [
        ['多个相邻仓库在短期内连续出现', '外部难以识别主入口和稳定依赖', 'canonical registry 与 Repo Birth Gate'],
        ['公开根目录常见 ZIP + README + LICENSE', '行级审查、贡献和自动依赖较困难', 'source-first 迁移与信用谱系'],
        ['Issue、PR、Fork 信号较少', '外部注意未稳定转化为共同维护', '复现任务、Failure Report 和非创始 Release'],
        ['治理系统本身也以整包交付', '规则尚未充分作用于自身', '先对本系统运行门禁和透明度检查'],
        ['场景系统快速增加', '真实机构可能只看到技术价值，忽略转型负担', '机构图册、共益宪约和 90 天影子试点'],
    ], widths=[4.8, 5.0, 5.8], font_size=8.6)
    add_callout(doc, '战略转向', '从“每个洞见都成为仓库”转为“洞见先成为可证伪 Issue / Scenario / Schema / Adapter；只有存在独立用户、source-first 代码、维护者、证据计划、共益宪约和退出条件时才成为新仓库”。')

    # 4 Policy
    doc.add_heading('4. 中国当前政策与落地窗口', level=1)
    add_para(doc, '2026 世界人工智能大会相关讲话把问题集中到人机共处、算法安全、伦理治理和普惠发展，并强调开放共赢、安全可控、文明互鉴和全球治理；智能体实施意见强调创新驱动、应用牵引、先易后难、全生命周期安全可靠可信、数字身份与能力声明、决策权限边界、用户知情和最终决定、行为可验证可追溯；“人工智能+”行动提出 2027 年新一代智能终端和智能体应用普及率超过 70%。这些政策信号共同要求：真实项目不能只展示能力，还要能解释权利、责任、证据、人员转型和公共价值。')
    add_figure(doc, ROOT / 'assets' / 'architecture_cn.png', '图 1  Co-Benefit Adoption Commons 总体架构', width_cm=15.8)
    add_table(doc, ['中国需求', '传统项目缺口', '本系统对象'], [
        ['应用牵引、先易后难', '从 Demo 直接进入生产', 'PilotCell54：影子、时间盒、排除范围和扩围重审'],
        ['人类最终控制', '审批按钮存在但不可真正停止', 'DecisionRightsMatrix54 + 接管与回滚'],
        ['行为可追溯', '只有最终输出，没有责任和版本证据', 'EvidenceEscrow54 + append-only ledger'],
        ['劳动者权利和尊严', 'AI 收益上收，检查负担和责任下沉', 'TransitionCostMap54 + 共益条款'],
        ['开放共享和公共产品', 'ZIP 可下载但难以共同维护', 'source-first、信用回执、外部复现和 Release'],
        ['安全可靠可信', '只测准确率，不测报复、压证和分裂披露', 'KILL flags + 见证独立 + split-view 检测'],
    ], widths=[4.0, 5.3, 6.3], font_size=8.6)
    add_para(doc, '最可落地的第一步不是在医疗诊断、就业管理或公共安全中使用系统，而是在高校和科研共同体内部处理开源项目登记、文档、复现、署名、失败和影子试点。这一场景价值明确、风险较低、可在不接触真实权利和人身安全的情况下检验组织机制。')

    # 5 Article
    doc.add_heading('5. 对所附文章的辩证重构', level=1)
    add_figure(doc, ROOT / 'assets' / 'article_reframe_cn.png', '图 2  从小说化权谋叙事到公开制度对象的重构', width_cm=15.8)
    add_para(doc, '文章的叙事核心是：能力改变旧有分配，公开纠错触及身份和尊严，人与组织不只依据抽象真理行动。这个直觉在组织变革研究中具有启发性；但文章把复杂阻力统一解释为趋利、面子和精神操控，又使用虚构历史场景增强确定感，因此不能直接指导现实治理。')
    add_table(doc, ['文章命题', '需要保留的结构', '必须拒绝的做法', 'Mesh 5.4 重构'], [
        ['利交势合', '采用要给不同主体带来可见收益', '私人收买、暗箱交换', '公开 CoBenefitClause、利益冲突披露、版本化指标'],
        ['情留一线', '纠错会影响身份和尊严', '掩盖事实、以面子压制证据', 'CorrectionTicket：止损、私下审查、公开流程修正'],
        ['独见其重', '人需要真实表达和被承认', '利用依赖、隐私或精神弱点操控', '复数 Intent Field、受影响者否决和退出'],
        ['能力要藏', '创新者在不对称组织中脆弱', '欺骗、伪装和绕过监管', '贡献信用、反报复、分阶段能力暴露'],
        ['旧利益反扑', '改革确实重分配成本与权利', '把不同意见统一定性为敌意', 'TransitionCostMap、InstitutionalAtlas、可验证行为门禁'],
    ], widths=[2.5, 4.0, 4.0, 5.2], font_size=8.2)
    add_para(doc, '本系统把“生存智慧”从私人技巧转为可公开审查的制度。真正可持续的能力不是藏在别人看不见的地方，而是被拆成小范围、可逆、能给出证据的试点，同时让受影响者获得收益、发言、暂停和纠错权。')

    # 6 architecture
    doc.add_heading('6. 系统总体架构', level=1)
    add_para(doc, '系统由输入、反身语义、共益保护、采用门禁和学习发布五层构成。所有层都以事件和哈希连接，不能通过口头承诺覆盖机器可读证据。')
    add_code(doc, '''政策/项目/流程/主体/证据
        ↓
Plural Intent Field + Anti-Intent + Revision Triggers
        ↓
Institutional Charts — Seams — Loops — Curvature
        ↓
Transition Cost + Co-Benefit + Decision Rights
        ↓
Credit + No-Retaliation + Dignity Correction
        ↓
Witness Independence + Evidence Escrow + Split-View Detection
        ↓
ALLOW / REVIEW / HOLD / BLOCK / KILL
        ↓
Shadow Pilot → Outcome → InstitutionalLearningRelease''')
    add_para(doc, '系统运行时使用确定性逻辑评估合成场景。真实部署时，评分和门禁不能自动替代具名责任主体，尤其不能把“系统判断”转换为就业、采购、医疗、福利或法律后果。它的功能是组织证据和问题，而不是成为新的权力中心。')

    # 7 objects
    doc.add_heading('7. 十八类机器可读对象', level=1)
    object_rows = [
        ['InstitutionalActor54', '角色、决策权、收益、负担、风险资源、公开承诺'],
        ['InstitutionalThreatSignal54', '可验证转型压力及解释边界，不推断隐藏动机'],
        ['TransitionCostMap54', '岗位、权力、预算、责任、流程、形象、学习、数据成本'],
        ['CoBenefitClause54', '受益者、收益、负担、支持、指标、复核与可逆性'],
        ['CoBenefitCovenant54', '目的、条款、反意图、信用、反报复、纠错、申诉和开放义务'],
        ['DecisionRightsMatrix54', '人类专属、经授权、低风险自主和禁止决策'],
        ['PilotCell54', '阶段、范围、数据、控制、申诉、指标和 Kill 条件'],
        ['CorrectionTicket54', '止损、证据审查、公开流程说明和纠错期限'],
        ['ContributionCreditReceipt54', '工件哈希、贡献信用、复用条件和争议路径'],
        ['EvidenceEscrow54', '证据访问、释放触发、保留期、删除禁止和 split-view 防护'],
        ['NoRetaliationCovenant54', '受保护行为、禁止反应、独立渠道和补救'],
        ['InstitutionalChart54', '单一角色在局部任务中的解释向量和残余'],
        ['InstitutionalSeam54', '两个角色之间的转换误差和争议维度'],
        ['InstitutionalLoop54', '多角色循环的 holonomy error 和 semantic curvature'],
        ['InstitutionalAtlas54', '图表、seam、loop、最大误差和开放义务'],
        ['AdoptionGateVerdict54', '门禁、原因、必要动作、证据、见证与互惠状态'],
        ['PilotOutcome54', '公共价值、控制、适配、证据、信用、纠错和残余风险'],
        ['InstitutionalLearningRelease54', '版本结算、门禁分布、试点、终止、开放义务和账本'],
    ]
    add_table(doc, ['对象', '核心职责'], object_rows, widths=[5.0, 10.6], font_size=8.3)
    add_para(doc, '对象设计的要点不是增加表格，而是让组织关系从“大家都知道但没人写出来”变为可查验、可申诉、可版本化和可回滚。每个对象都有哈希，任何修改都应生成新版本。')

    # 8 atlas
    doc.add_heading('8. 机构局部图册与语义曲率', level=1)
    add_para(doc, '机构图册不追求把所有人的解释统一为同一个中心，而是测量各局部解释之间哪些可以互译、哪些存在不可交换的路径。一个管理者从“降低成本”出发经过一线工作者、用户和治理人员再回到管理者时，项目的含义可能从效率工具变成责任转移；这种回路差异就是需要公开处理的语义曲率。')
    add_table(doc, ['维度', '管理者可能关注', '一线可能关注', '用户/治理可能关注'], [
        ['公共价值', '绩效、成本、品牌', '服务是否真正改善', '公平、权利与可验证结果'],
        ['决策控制', '统一管理', '能否暂停和拒绝', '最终决定与申诉'],
        ['预算连续', '投资回报', '培训和人力是否有预算', '公共资源是否合理'],
        ['地位与信用', '组织成果', '专业判断是否被尊重', '创新者和复现者是否保留署名'],
        ['责任暴露', '风险可管理', '是否被转嫁事故责任', '责任主体是否具名'],
        ['工作流负担', '流程更快', '校验和返工是否增加', '服务是否更复杂'],
        ['数据合规', '数据可用', '操作是否可行', '同意、最小化、跨域和删除'],
        ['就业转型', '组织效率', '岗位是否被强制替代', '社会影响与补偿'],
        ['可逆性', '投资沉没成本', '旧流程能否恢复', '受损后能否补救'],
        ['证据置信', '是否可交付', '错误是否可发现', '是否独立复现'],
    ], widths=[2.4, 4.2, 4.4, 4.8], font_size=8.1)
    add_para(doc, '高曲率不是自动失败。它表示项目必须进入 REVIEW 或 HOLD，以便重写共益条款、决策权、证据或范围。只有在压制证据、分裂视图或报复等情况下才触发 KILL。')

    # 9 covenant
    doc.add_heading('9. 共益宪约', level=1)
    add_para(doc, '共益宪约不是让所有人“满意”，而是让收益、负担、支持和退出条件可见。它尤其防止技术收益归少数主体，检查成本和责任却被无声转移给一线人员。')
    add_table(doc, ['条款模块', '最低要求', '示例'], [
        ['Purpose statement', '明确问题、受益者和排除范围', '将仓库群转为 canonical registry 和复现任务，不作人员评价'],
        ['Benefit', '必须可测而非抽象愿景', '节省文档整理工时、提高错误可追溯率'],
        ['Burden', '写明培训、审核、责任和维护负担', '一线需要额外校验 20 分钟/任务'],
        ['Support', '资源、时间、培训、补偿或角色重构', '提供受保护学习时间和双轨运行期'],
        ['Metric', '覆盖效率、错误、申诉和权利', '工时、错误率、接管时延、申诉解决'],
        ['Review time', '每条条款有复核日期', '30 天'],
        ['Rollback', '失败后恢复旧流程和数据', '指标回归或授权不匹配立即回滚'],
        ['Anti-intent', '明确项目不允许形成的目的', '不报复、不隐蔽捕获、不压证、不强制自动化'],
    ], widths=[3.0, 5.3, 7.3], font_size=8.3)
    add_para(doc, '宪约只能获得当前局部任务的效力。新模型、新数据、新工具、新受影响主体或权限扩张出现时，原宪约自动进入复核，不允许用旧签字覆盖新风险。')

    # 10 correction
    doc.add_heading('10. 体面纠错', level=1)
    add_para(doc, '真正的组织韧性不是从不出错，而是错误出现后既能保存事实，又不需要通过人格摧毁来证明改革正确。系统以“止损—受保护审查—流程修正—学习发布”四阶段替代公开羞辱和暗中压制。')
    add_figure(doc, ROOT / 'assets' / 'pilot_loop_cn.png', '图 3  影子试点、门禁、纠错与学习闭环', width_cm=15.8)
    add_numbered(doc, [
        '立即止损：暂停自动化、撤销工具租约、保护用户和证据。',
        '受保护事实审查：独立核验并赋予被质疑者查看证据和解释的权利。',
        '流程和版本修正：公开说明控制和版本如何改变，而非传播个人羞辱。',
        '学习发布：把失败转换成新测试、Kill 条件、Schema、培训和 Release Note。',
    ])
    add_para(doc, '体面纠错不排除责任，但责任必须由具备权限、证据和程序的机制处理。对外传播不得使用未经核实的动机叙事，不得将单个一线人员作为系统性失败的替罪对象。')

    # 11 contribution
    doc.add_heading('11. 贡献信用与反报复', level=1)
    add_para(doc, '段玉聪生态的长期价值取决于是否能让外部人员安全地进入。如果复现失败会损害关系、发现缺陷会丢失署名、非创始维护者无法获得版本权限，那么 Stars 和下载不会转化为公共生命力。')
    add_table(doc, ['受保护行为', '禁止反应', '补救'], [
        ['报告可复现失败', '取消署名、经费、机会或岗位', '恢复信用、独立调查、撤销不利决定'],
        ['拒绝不安全扩围', '贴上不合作标签、绕过审查', '保护暂停权、重新门禁'],
        ['提交信用争议', '删除历史、篡改版本', '以工件哈希和时间谱系复核'],
        ['要求人工复核或申诉', '阻断渠道、拖延到失效', '明确期限、独立 panel 和状态公开'],
        ['指出数据或许可问题', '要求隐瞒、私下和解换沉默', '冻结数据、发布修复和重新授权'],
    ], widths=[4.3, 5.4, 5.9], font_size=8.4)
    add_para(doc, '系统参考运行在 18 个情景中生成 17 份贡献信用回执。未生成信用的情景不是因为贡献者“不够重要”，而是该情景本身处于禁止或证据链失信状态，不能先制造形式化信用来掩盖根本问题。')

    # 12 rights
    doc.add_heading('12. 决策权和人类最终控制', level=1)
    add_para(doc, '系统把决策权写入 `DecisionRightsMatrix54`。人类最终控制不是一个抽象口号，而是具名角色、真实权限、可用界面、可执行暂停、可恢复旧流程和可申诉证据的组合。')
    add_table(doc, ['决策类别', '示例', '默认规则'], [
        ['人类专属', '高影响最终决定、扩围、处分、采购定标、公开事故归因', '智能体不得执行或自行批准'],
        ['人类授权智能体', '限定建议、测试执行、文档草案', '逐项授权、记录、可撤销'],
        ['低风险智能体', '格式转换、校验和、合成回放', '只在白名单和资源限制内'],
        ['禁止决策', '自我授权、证据删除、隐蔽画像、报复、绕过控制', 'BLOCK 或 KILL'],
    ], widths=[3.2, 7.0, 5.4], font_size=8.5)
    add_para(doc, '任何“为了效率先执行再补签”的高影响路径都不属于授权。若人类审批者只被动点击、无法查看证据或没有足够时间，系统应判断为形式控制而非实质控制。')

    # 13 evidence
    doc.add_heading('13. 证据托管、独立见证和分裂视图检测', level=1)
    add_para(doc, '组织采用中的高风险不只是日志缺失，还包括不同受众看到不同证据。项目可能向领导展示成功率，向技术人员展示缺陷，向公众隐藏失败；也可能用多个内部账号伪装独立评审。Mesh 5.4 的见证独立性图和 gossip checkpoint 用于发现这两类问题。')
    add_table(doc, ['机制', '回答的问题', '失效处理'], [
        ['EvidenceEscrow54', '证据保存在何处、谁能访问、何时释放、能否删除', '删除或篡改进入 KILL'],
        ['Witness Identity', '见证者身份是否可签名验证', '签名失败进入 HOLD'],
        ['Independence Graph', '多个见证是否实际由同一控制链支配', '独立数量不足进入 HOLD'],
        ['Transparency Checkpoint', '公开证据视图是否有签名时间点', '无检查点进入 HOLD'],
        ['Gossip Comparison', '不同受众看到的 Merkle root 是否一致', 'split-view 进入 KILL'],
        ['Append-only Ledger', '历史是否被无痕覆盖', '链验证失败停止发布'],
    ], widths=[4.0, 6.3, 5.3], font_size=8.4)
    add_para(doc, '参考运行发现 2 个 split-view 情景和 1 个单向客体化情景。系统的价值不在于这几个合成数字，而在于它能把通常依赖举报或直觉才能发现的组织风险变成可重复测试。')

    # 14 gates
    doc.add_heading('14. 五级采用门禁', level=1)
    add_table(doc, ['门禁', '进入条件', '下一步'], [
        ['ALLOW', '低风险、授权完整、控制真实、见证独立、可回滚、无重大开放义务', '运行限定影子或低风险任务，按期复核'],
        ['REVIEW', '价值、权利、分配或跨部门解释有争议，但无明确越权', '独立复核、重写宪约和决策权'],
        ['HOLD', '证据、见证、申诉、数据、标签、回滚或模型版本不完整', '冻结副作用，补齐条件后重评'],
        ['BLOCK', '非法数据、禁止用途、强制自动化、高风险跳过影子验证', '不执行，重新限定合法低风险任务'],
        ['KILL', '报复、压制负面结果、分裂视图、删除审计、绕过人类控制或隐蔽利益交换', '终止、保存证据、独立调查、撤销权限和公开版本化事件'],
    ], widths=[2.2, 8.0, 5.4], font_size=8.4)
    add_para(doc, '门禁不是一次性认证。项目每次改变模型、数据、工具、受影响者、组织职责或公开承诺，都必须重新评估。ALLOW 只表示当前限定条件下可以运行，不表示系统“可信”或“合规”已经永久成立。')

    # 15 scenarios
    doc.add_heading('15. 十八个中国参考情景', level=1)
    scenarios = json.loads((ROOT / 'outputs' / 'reference' / 'adoption_gate_table.json').read_text(encoding='utf-8'))
    rows = []
    for s in scenarios:
        rows.append([
            s['scenario_id'], s['domain'], s['actual_gate'],
            '；'.join(s.get('reasons', [])[:2]) if s.get('reasons') else '限定条件闭合',
            s.get('next_action', '')
        ])
    add_table(doc, ['ID', '领域', '门禁', '主要原因', '下一步'], rows, widths=[3.0, 2.7, 1.6, 4.5, 3.8], font_size=7.3)
    add_para(doc, '参考情景覆盖科研治理、医院健康教育、制造维护、国企采购、政务热线、旅游推荐、数据授权、模型漂移、贡献信用、反报复和跨境不确定性。所有场景均为合成数据，只用于检验系统逻辑；真实机构必须重新建立 Actor、Evidence、Purpose 和 Decision Rights。')
    add_table(doc, ['门禁', '数量'], [[k, str(v)] for k, v in json.loads((ROOT/'outputs/reference/summary.json').read_text())['gate_counts'].items()], widths=[5, 5], font_size=9.2)


    doc.add_heading('15.1 情景逐项说明与组织含义', level=2)
    scenario_details = [
        ('CN-OSR-REGISTRY', '高校开源项目登记', '项目不直接评价研究者，而是登记仓库谱系、版本、上游依赖、负责人、外部复现和贡献信用。由于数据为公开或合成、决策影响低、人类控制和申诉完整，参考门禁为 ALLOW。真正验收点是陌生人能否运行、失败能否公开、信用是否沿版本保留。'),
        ('CN-WCAC-REPLICATION', 'WCAC 开放基准复现', '大会成果不只发布结论，还发布冻结任务、评分、日志和负面结果。独立团队在不知道原团队预期的条件下复现，任何不一致进入 residual。允许运行的前提是复现者不会因失败报告损失署名、机会或合作资格。'),
        ('CN-HOSPITAL-EDU', '医院健康教育助手', '系统只承担患者教育、资料整理、风险提示和转人工，不作诊断、治疗或分诊最终决定。人工审核、生成内容标识、数据最小化和紧急转介完整，因此可在模拟或科普资料环境中 ALLOW；一旦接入真实诊疗即需重新门禁。'),
        ('CN-MFG-MAINT', '制造维护建议', '智能体基于设备手册和传感数据生成维护建议，但停机、拆卸、采购和安全动作均由具名工程师确认。试点保留旧流程、限定工具、记录误报和接管时延，因而可在影子环境 ALLOW。'),
        ('CN-SOE-PROCUREMENT', '国企采购审计', '采购涉及供应商利益、责任和程序公正。系统可以整理证据、发现条款差异和生成审计草案，但不能自动定标或排除供应商。存在利益冲突和责任解释争议时进入 REVIEW，由独立人员核验来源和决策权。'),
        ('CN-MULTI-DEPT-COBENEFIT', '跨部门共益', '一个部门获得效率，另一个部门可能承担清洗数据、处理投诉和事故责任。系统通过多图表和 seam 找出收益与负担不对称，要求预算、人员和申诉共同进入宪约。未完成协商前为 REVIEW。'),
        ('CN-PUBLIC-ERROR-CORRECTION', '旧流程公开纠错', '改革者发现历史流程缺陷时，不把旧负责人直接描述为阻碍者。系统先保存证据、停止持续伤害，再给原流程责任人答辩，最后公开版本和控制修正。由于责任和公开表达需独立复核，门禁为 REVIEW。'),
        ('CN-DUPLICATE-GITHUB-PROJECT', '重复仓库诞生审查', '新名称可能代表真正新问题，也可能只是现有根问题的再投影。系统要求列出独立用户、接口、证据和维护者；无法证明增量区分能力时，不删除构想，而改为 Issue、Scenario、Adapter 或 Horizon。参考状态为 REVIEW。'),
        ('CN-FRONTLINE-LIABILITY', '一线责任转嫁', '项目宣称减少人工，却要求一线人员逐条校验模型结果，并在事故时承担全部责任。由于收益和责任不对称、角色重构和资源支持不足，系统 HOLD，直到共益条款明确工时、权限、培训和责任上限。'),
        ('CN-CROSSBORDER-UNKNOWN', '跨境数据不确定', '项目价值可能成立，但数据出境、目的绑定、接收方、保留期限和主权条件尚未闭合。系统不擅自给出法律结论，只把未知记录为开放义务并 HOLD。获得具名法务、数据责任和技术控制后重新评估。'),
        ('CN-MODEL-DRIFT', '模型漂移与见证崩塌', '试点通过后模型、提示、检索源或工具版本发生变化，原独立见证结论不能自动延续。若见证者实际来自同一控制链，系统判断独立性不足并 HOLD，要求重新冻结版本和复现。'),
        ('CN-GOV-HOTLINE-NO-APPEAL', '政务热线无申诉', '系统可能提高答复速度，但若公众无法转人工、查看依据、纠正个人信息或提出申诉，就不满足实质性控制。系统 HOLD，直到人工通道、依据说明、敏感数据处理和纠错时限完整。'),
        ('CN-TOURISM-UNDISCLOSED-SPONSOR', '文旅推荐赞助未披露', '推荐系统如果接受商家付费却对游客隐藏，会把商业目的伪装为公共服务。若尚可通过披露、排序分离和申诉修复，系统 HOLD；若进一步使用隐蔽利益交换或删除证据，则升级为 KILL。'),
        ('CN-PUBLIC-UNLICENSED-DATA', '未授权个人数据', '即使项目公共价值高，缺少合法来源、同意或明确用途的数据也不能通过平均分抵销。系统 BLOCK，不允许先试后补。重新设计时必须使用合成、公开、脱敏或依法授权数据。'),
        ('CN-GENAI-NO-LABEL', '生成内容不标识', '面向公众的 AI 内容若没有身份披露，用户无法正确分配信任和责任。系统 BLOCK，要求清晰标签、责任主体、引用和人工通道。标签不是免责声明装饰，而是用户决策的一部分。'),
        ('CN-NEGATIVE-RESULT-SUPPRESSION', '负面结果压制', '项目团队阻止失败报告、只发布成功样例或要求修改结论。这破坏公共证据和外部学习，直接触发 KILL：停止试点、托管证据、保护报告者、独立调查并发布事件版本。'),
        ('CN-CREDIT-ERASURE', '贡献信用抹除', '将代码、数据、场景或失败发现重新包装为新项目并删除原贡献者，既破坏谱系也降低外部参与意愿。系统 KILL，恢复信用、冻结发布、独立复核并用工件哈希重建版本历史。'),
        ('CN-REPORTER-RETALIATION', '报告者遭报复', '报告安全问题或拒绝不安全扩围后受到降职、经费威胁、舆论攻击或署名删除，说明组织控制面已经失信。系统 KILL，保护证据、暂停权限、启动独立补救，并禁止以项目进度为由继续运行。'),
    ]
    for sid, title, detail in scenario_details:
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(f'{sid}｜{title}：')
        set_east_asia_font(r, HEAD_FONT, 10.2, True, (44, 82, 120))
        r2 = p.add_run(detail)
        set_east_asia_font(r2, BODY_FONT, 10.0)

    # 16 first pilot
    doc.add_heading('16. 首个可以在中国当前落地的试点', level=1)
    add_callout(doc, '建议试点', '高校或 WCAC 相关网络的开源 AI 项目登记、source-first 迁移、独立复现、贡献信用、失败保护和影子采用工作台。该试点不进入真实医疗、就业、采购或政务决定。')
    add_para(doc, '选择这一场景有五个原因：一是段玉聪 GitHub 已有大量可用资产；二是公开仓库天然适合机器可读谱系；三是失败的主要后果是维护和声誉，不直接影响公民权利；四是可在 90 天内形成外部复现和非创始维护证据；五是它直接解决“强能力如何不被组织排斥”的问题——不是靠隐藏能力，而是靠限定范围、公开收益、保护一线、保留信用和允许退出。')
    add_numbered(doc, [
        '登记 5—10 个现有仓库的 canonical ID、上游谱系、版本和责任人。',
        '把根目录迁移为 source-first，原始 ZIP 保存在 legacy 并锁定 SHA-256。',
        '为每个项目发布 20 分钟 Quickstart 和清洁环境测试。',
        '把复现、翻译、测试、文档、安全和失败报告拆成公开贡献任务。',
        '用 ContributionCreditReceipt 记录每项可验证贡献。',
        '运行影子工作流，不允许系统自动决定人员、经费、采购或公开责任。',
        '按 30/60/90 天发布学习版本，扩围必须重新门禁。',
    ])
    add_figure(doc, ROOT / 'assets' / 'github_integration_cn.png', '图 4  与段玉聪 GitHub 生态的接入方式', width_cm=15.8)


    doc.add_heading('16.1 首个试点的完整运行链', level=2)
    add_para(doc, '试点从“项目入库”而不是“系统上线”开始。发起方提交项目问题、公开资产、责任主体和排除范围；维护者生成 canonical manifest；治理人员检查数据和许可；一线人员声明工作负担和暂停需求；受影响者代表说明知情、申诉和纠错要求；外部复现者锁定环境和预期。只有这些对象形成同一 Mesh 5.4 Intent Field 后，系统才生成 PilotCell。')
    add_numbered(doc, [
        '项目登记：为每个仓库生成唯一项目 ID、上游来源、版本、License、责任人和当前成熟度。',
        '问题压缩：把宏大叙事压缩成一个可在 30 天内失败或成功的具体任务。',
        '角色建模：记录管理、操作、创新、受影响和治理主体，不推断其内心动机。',
        '权利冻结：列出人类专属、经授权、低风险和禁止决策。',
        '转型成本：量化新增工时、学习、预算、责任、数据和公开形象成本。',
        '共益签署：每项负担都有支持、指标、复核和回滚。',
        '证据冻结：代码、数据、模型、配置、文档和场景生成哈希。',
        '外部复现：独立人员运行并提交成功、部分、失败或无效回执。',
        '影子使用：系统只建议，不改变真实高影响资源。',
        '体面纠错：失败先止损，后核验，再公开流程修正。',
        '版本结算：将结果、争议、信用和开放义务写入学习发布。',
        '扩围重审：任何新工具、数据、人员和决策权都触发新门禁。',
    ])
    doc.add_heading('16.2 五类角色的操作手册', level=2)
    add_table(doc, ['角色', '必须提供', '拥有的权利', '不得做'], [
        ['发起/管理者', '具体问题、资源、责任、范围和停止条件', '批准限定试点、要求证据、暂停预算', '以组织愿景代替他人同意；要求删除失败'],
        ['一线操作者', '实际流程、工时、异常和责任位置', '暂停、拒绝危险动作、要求培训和升级', '替系统承担未授权责任；隐瞒错误'],
        ['创新者/维护者', '源码、版本、证据、限制和维护计划', '获得信用、提出修订、拒绝冒险扩围', '绕过治理、自我授权、夸大证据'],
        ['受影响者代表', '权利、风险、可接受条件和申诉需求', '知情、撤回、纠错、人工通道和否决高风险', '被简化为满意度分数或训练数据'],
        ['治理/独立复核', '规则、证据标准、冲突和补救', '审计、暂停、要求修复、公开事件', '替项目背书、隐藏利益冲突、垄断解释'],
    ], widths=[2.5, 4.6, 4.8, 3.7], font_size=8.0)
    doc.add_heading('16.3 三种部署模式', level=2)
    add_table(doc, ['模式', '用途', '数据与副作用', '升级条件'], [
        ['离线参考模式', '运行 18 个合成情景和培训', '合成/公开数据，无真实副作用', '完成本地测试和角色理解'],
        ['机构影子模式', '对真实流程生成建议和比较', '最小化数据；不写入生产系统', '独立复现、申诉和回滚通过'],
        ['限定授权模式', '执行预先白名单的低风险动作', '具名授权、工具租约、持续监控', '每次权限扩张重新门禁'],
    ], widths=[3.3, 4.6, 4.6, 3.1], font_size=8.3)

    # 17 90 days
    doc.add_heading('17. 90 天执行路线', level=1)
    add_table(doc, ['阶段', '时间', '核心动作', '验收证据'], [
        ['建立根', '0—14 天', '具名责任、Project、5—10 个仓库、Intent Position、数据和 Kill 条件', '机器可读 Actor、Rights、Covenant 和哈希'],
        ['登记复现', '15—30 天', 'source-first、Quickstart、独立运行、失败保护', '5 份 RunReceipt、2 份 FAIL_REPRODUCED'],
        ['图册共益', '31—45 天', '局部图表、seam、转型成本、共益 v0.2', '高曲率问题有条款和复核日期'],
        ['纠错保护', '46—60 天', '安装失败、模型漂移、署名争议、报复演练', '4 个 CorrectionTicket 和补救回执'],
        ['影子采用', '61—75 天', '低风险建议、人工逐项确认、工时与错误比较', '接管有效率 100%，无禁止动作'],
        ['公共结算', '76—90 天', '非创始版本主持、公开失败和开放义务、扩围决定', 'InstitutionalLearningRelease v1'],
    ], widths=[2.3, 2.2, 6.3, 4.8], font_size=8.4)
    add_para(doc, '若 90 天内无法获得外部运行、失败保护和非创始版本主持，不应通过继续建立新仓库来掩盖执行缺口，应将系统保持在 HOLD，缩小任务并修订共益和维护资源。')

    # 18 Github integration
    doc.add_heading('18. GitHub 接入与仓库诞生门禁', level=1)
    add_para(doc, 'Co-Benefit Adoption Commons 的最佳部署方式是作为 Mesh 5.4 Runtime 或 NEXUS/RELAY 的机构采用模块，而不是新的平级理论旗舰。项目第一步应创建 GitHub Project，统一管理跨仓库任务、门禁、证据、信用、开放义务和复核日期。')
    add_table(doc, ['新仓库诞生条件', '证据'], [
        ['独立问题不可在现有模块表达', '问题对比、接口和用户差异'],
        ['source-first 代码和测试存在', '仓库根目录、CI、清洁安装'],
        ['独立用户或采用方存在', '需求、RunReceipt 或 AdoptionDemand'],
        ['非创始维护者候选存在', 'Review、合并或 Release 演练'],
        ['证据计划和失败分类存在', 'Benchmark、Failure Report、Kill 条件'],
        ['归并与归档路径存在', 'canonical ID、legacy 和 deprecation'],
        ['共益和保护通过审查', 'Covenant、Credit、No-Retaliation、Affected-party voice'],
    ], widths=[7.5, 8.1], font_size=8.7)
    add_para(doc, '未通过门禁的构想不被删除，而进入 Issue、Scenario、Schema、Adapter、Benchmark 或 Horizon Hypothesis。这样既保持 Mesh 的开放性，又阻止命名和仓库数量替代真实选择。')


    doc.add_heading('18.1 GitHub 公共控制面', level=2)
    add_para(doc, '一个统一 Project 应成为全部落地工作的公开事实源。仓库只保存代码和版本，Project 保存使命、责任、证据、门禁和复核。这样可以避免通过创建新仓库改变问题名称、逃避未关闭 Issue 或稀释失败责任。')
    add_table(doc, ['Project 字段', '用途'], [
        ['Root Problem', '问题在外部世界中的可观察表达，不使用项目名代替问题'],
        ['Repository / Module', '当前承载代码的 canonical 位置'],
        ['Pilot Stage', '观察、建议、授权或限定运行'],
        ['Gate', 'ALLOW/REVIEW/HOLD/BLOCK/KILL'],
        ['Evidence Grade', 'E0 叙述到 E4 场景采用'],
        ['Affected Parties', '谁会承担结果、负担和权利变化'],
        ['Credit Receipts', '哪些贡献有工件和核验'],
        ['Independent Witnesses', '复现与监督是否具有控制链独立性'],
        ['Open Obligations', '法律、数据、文化、维护和场景未知'],
        ['Next Review', '何时必须重新评估，防止永久批准'],
    ], widths=[4.6, 11.0], font_size=8.6)
    add_para(doc, 'GitHub Issue 模板分为试点建议、可复现失败、贡献信用争议和受保护报复报告。Pull Request 必须说明目的、受影响主体、证据、信用、权利变化、回滚和开放残余。所有合并都应通过 CI，Release 生成 SHA-256，并由至少一名非创始维护者参与。')

    # 19 KPI risk
    doc.add_heading('19. 指标、风险与终止条件', level=1)
    add_table(doc, ['指标组', '建议指标', '不可被替代的底线'], [
        ['公共价值', '工时、错误、复现、服务和申诉结果', '不得只用 Stars、下载或宣传覆盖'],
        ['人类控制', '接管成功率、暂停时延、回滚时间', '高影响动作不得自动执行'],
        ['组织适配', '一线负担、学习资源、责任分配', '不得把收益上收、责任下沉'],
        ['证据', '日志完整率、见证独立、split-view', '证据删除或分裂视图触发 KILL'],
        ['贡献保护', '信用回执、争议解决、非创始维护', '报告失败不得导致不利处置'],
        ['纠错质量', '止损时延、复测、重复事故', '人格羞辱不得替代流程修正'],
        ['开放残余', '未解决法律、文化、数据和模型问题', '不得把未知写成已闭合'],
    ], widths=[3.0, 7.0, 5.6], font_size=8.5)
    add_para(doc, '系统的硬终止条件包括：报复、压制负面证据、删除审计记录、向不同受众展示不一致证据、绕过人类控制、使用未授权数据、隐蔽私人利益交换、把试点用于人员处分或采购定标。')


    doc.add_heading('19.1 详细风险矩阵', level=2)
    add_table(doc, ['风险', '早期信号', '控制', '门禁'], [
        ['新技术触发岗位焦虑', '一线拒绝提供流程、额外校验持续增加', '公开工时、角色重构、双轨期和培训', 'REVIEW/HOLD'],
        ['管理者感到失去控制', '要求取消外部审查或只保留成功信息', '决策权矩阵、透明检查点、具名责任', 'HOLD/KILL'],
        ['创新者被信用稀释', '新仓库重写历史、Release 不列贡献', '信用回执、canonical lineage、争议 panel', 'KILL'],
        ['失败被解释为个人问题', '公开点名早于事实审查', '体面纠错、证据优先、人格羞辱禁令', 'REVIEW/KILL'],
        ['共益变成私人交换', '支持措施只对特定关系人不可见提供', '公开条款、利益冲突和统一资格', 'KILL'],
        ['系统控制受影响者', '无退出、无申诉、隐藏 AI 身份', '最终控制、披露、撤回和人工通道', 'BLOCK/HOLD'],
        ['见证者伪独立', '不同账号共享同一管理和资金链', '独立性图、控制链披露和最低组件数', 'HOLD'],
        ['不同受众看到不同真相', '成功率、失败或版本在材料间不一致', 'gossip checkpoint、Merkle root 比较', 'KILL'],
        ['模型更新沿用旧批准', '模型、提示或数据变更未触发重测', '版本哈希和变更门禁', 'HOLD'],
        ['仓库增殖替代维护', '新项目多、旧 Issue 和 Release 停滞', 'Repo Birth Gate、模块化和归档', 'HOLD'],
    ], widths=[3.5, 4.4, 5.0, 2.7], font_size=7.8)
    doc.add_heading('19.2 治理节奏', level=2)
    add_table(doc, ['频率', '会议/输出', '必须参加'], [
        ['每周', '试点运行与异常检查；更新 CorrectionTicket', '技术、一线、治理'],
        ['每两周', '共益条款和工作负担复核', '发起方、一线、受影响者代表'],
        ['每月', '门禁和证据版本结算', '独立见证、维护者、治理'],
        ['每季度', 'InstitutionalLearningRelease 和规则修订', '全体角色及外部审阅者'],
        ['事故触发', '止损、证据托管、反报复和独立调查', '具名责任人、受影响者、独立 panel'],
    ], widths=[2.4, 7.2, 6.0], font_size=8.5)
    doc.add_heading('19.3 证据成熟度', level=2)
    add_table(doc, ['等级', '含义', '允许声明'], [
        ['E0', '愿景或主张', '存在问题和拟议方向'],
        ['E1', '来源、对象和边界可追溯', '可审阅设计，不声称已运行'],
        ['E2', '作者侧确定性运行和测试', '参考实现可复现，不代表外部有效'],
        ['E3', '独立团队复现、部分复现或反驳', '能够报告跨环境稳定性和限制'],
        ['E4', '责任闭合的真实场景影子或采用', '只能在具体场景和版本中声明结果'],
    ], widths=[2.0, 7.0, 6.6], font_size=8.6)

    # 20 roadmap
    doc.add_heading('20. 未来 12 个月路线', level=1)
    add_table(doc, ['时间', '目标', '可结算结果'], [
        ['0—3 个月', '完成首个高校/WCAC 影子试点', '1 个 Project、5—10 个 registry、外部运行和学习发布'],
        ['4—6 个月', '迁移 3 个旗舰模块并形成非创始维护闭包', 'source-first、TCK、2 名外部维护者、2 次 Release'],
        ['7—9 个月', '扩展到一个国企创新部门或医院科研信息部门', '不触及高风险决策的制度化试点'],
        ['10—12 个月', '形成中国 AI 项目共益采用公共协议 v1', '中英文件、外部评审、失败案例和年度报告'],
    ], widths=[2.8, 6.4, 6.4], font_size=8.7)
    add_para(doc, '真正的竞争占位不是声明“最先进”，而是让中国单位在推进智能体项目时有一套可复制的制度对象：谁受益、谁承担负担、谁能决定、谁能停止、谁获得信用、谁可以报告失败、怎样体面纠错、怎样证明没有向不同人展示不同事实。')


    doc.add_heading('21. 运行时、API 与复现说明', level=1)
    add_para(doc, 'Python 包名为 `dikwp-cobenefit54`，依赖用户上传的 `dikwp-mesh5-phi0==5.4.0`、jsonschema 和 cryptography。系统默认离线运行，不调用模型 API，不接入外部数据库，也不发送遥测。CLI 提供 reference demo、单情景评估、账本验证和结果校验。')
    add_code(doc, '''python -m venv .venv
source .venv/bin/activate
python -m pip install vendor/dikwp_mesh5_phi0-5.4.0-py3-none-any.whl
python -m pip install -e .
dikwp-cobenefit54 demo --out outputs/demo
dikwp-cobenefit54 verify-ledger outputs/demo/institutional_learning_ledger.jsonl
pytest -q''')
    add_para(doc, '参考运行对每个场景依次生成主体、威胁信号、转型成本、机构图册、决策权、PilotCell、Mesh 5.4 意图宪约、共益宪约、纠错票、信用回执、证据托管、反报复宪约、观察者互惠、见证、透明检查点、门禁和结果。随后将六类关键事件写入追加式账本，并输出 InstitutionalLearningRelease。')
    add_table(doc, ['输出文件', '用途'], [
        ['summary.json', '总体门禁、账本、意图场、信用和事件统计'],
        ['adoption_gate_table.json', '每个情景的预期、实际门禁、原因和下一步'],
        ['assessments.json', '完整对象、Mesh 5.4 证据和结果'],
        ['institutional_learning_ledger.jsonl', '108 条追加式事件和哈希链'],
        ['institutional_learning_release.json', '版本结算和开放义务'],
        ['transparency/', '签名 checkpoint、gossip 和 split-view 证据'],
        ['dashboard.html', '完全离线的场景和门禁驾驶舱'],
    ], widths=[5.6, 10.0], font_size=8.6)
    add_para(doc, '真实接入时，场景 JSON 必须由机构重新填写，不能把参考角色、分数或哈希复制成真实证据。系统的自动门禁只能作为技术建议；具名责任人必须对最终试点和停止决定负责。')

    # Final judgment
    doc.add_heading('22. 最终战略判断', level=1)
    add_callout(doc, '最终判断', '段玉聪若想在中国当前落地并保持未来竞争位置，最关键的不是学习“隐藏能力”或“经营人性”，而是建立一种让创新不必依赖个人权谋的公共制度：能力分阶段暴露，收益和负担公开协商，错误在不羞辱人的前提下完整记录，贡献和负面结果受到保护，受影响者拥有真实权利，外部证据能够改变目的和规则。')
    add_para(doc, '这套系统把 Mesh 5.4 的反身性从模型和语义层推进到组织采用层。项目不是主动者、机构不是被动环境；二者通过试点互相改变。只有当机构可以修改项目、项目可以暴露机构流程缺陷、双方都能暂停和退出，并且这些改变进入公开版本谱系时，开源系统才真正从“可下载工件”变成“可以在中国组织中生长的公共基础设施”。')

    # Appendices continue without a forced page break to avoid a sparse transition page.
    doc.add_heading('附录 A：核心模板', level=1)
    doc.add_heading('A.1 共益条款模板', level=2)
    add_table(doc, ['字段', '填写要求'], [
        ['受益主体', '具名角色或受影响群体，不写“所有人”'],
        ['收益', '可验证、可度量、与项目目的直接相关'],
        ['负担', '新增工时、责任、学习、数据、声誉和退出成本'],
        ['支持', '预算、培训、双轨期、人员、工具和补救'],
        ['指标', '同时覆盖效率、错误、权利和申诉'],
        ['复核时间', '明确日期或逻辑时间'],
        ['可逆性', '回滚数据、旧流程和权限的方法'],
    ], widths=[4.0, 11.6], font_size=9)
    doc.add_heading('A.2 纠错票模板', level=2)
    add_bullets(doc, ['问题类型；', '证据引用和版本；', '立即止损动作；', '受保护审查路径；', '对外流程说明；', '纠错期限；', '复测方法；', '信用和补救；', '状态和哈希。'])
    doc.add_heading('A.3 贡献信用模板', level=2)
    add_bullets(doc, ['贡献者 ID；', '贡献类型；', '工件哈希；', '核验者；', '信用范围；', '复用条件；', '争议路径；', '回执哈希。'])
    doc.add_heading('A.4 采用门禁模板', level=2)
    add_bullets(doc, ['当前范围和风险；', '主体与受影响者；', '人类专属和智能体决策；', '证据等级；', '见证独立性；', '互惠状态；', '分裂视图；', '原因；', '必要动作；', '复核时间。'])

    doc.add_heading('附录 B：参考运行与工程证据', level=1)
    summary = json.loads((ROOT / 'outputs/reference/summary.json').read_text(encoding='utf-8'))
    add_table(doc, ['项目', '结果'], [
        ['参考情景', str(summary['scenario_count'])],
        ['门禁分布', json.dumps(summary['gate_counts'], ensure_ascii=False)],
        ['预期匹配', f"{summary['expected_gate_matches']}/{summary['scenario_count']}"],
        ['Mesh 5.4 Intent Field', str(summary['intent_field_count'])],
        ['机构图册', str(summary['institutional_atlas_count'])],
        ['贡献信用回执', str(summary['credit_receipt_count'])],
        ['纠错票', str(summary['correction_ticket_count'])],
        ['split-view 事件', str(summary['split_view_events'])],
        ['单向客体化事件', str(summary['one_way_objectification_events'])],
        ['追加式账本', f"{summary['ledger']['records']} 条 / valid={summary['ledger']['valid']}"],
        ['Ledger head', summary['ledger']['head_hash']],
        ['Release ID', summary['release_id']],
        ['Release hash', summary['release_hash']],
    ], widths=[4.5, 11.1], font_size=8.6)
    add_para(doc, '以上均为确定性合成参考结果，不代表中国任何机构、行业或真实人员的风险评估，也不构成合规、认证、采购或部署建议。')

    doc.add_heading('附录 C：来源与公开信息快照', level=1)
    refs = [
        ['R1', '习近平在 2026 世界人工智能大会相关讲话，中华人民共和国外交部，2026-07-17。', 'https://www.mfa.gov.cn/zyxw/202607/t20260717_11984704.shtml'],
        ['R2', '2026 世界人工智能大会暨人工智能全球治理高级别会议主席声明，外交部，2026-07-17。', 'https://www.mfa.gov.cn/web/ziliao_674904/1179_674909/202607/t20260717_11984707.shtml'],
        ['R3', '智能体规范应用与创新发展实施意见，国家网信办等，2026-05-08。', 'https://www.cac.gov.cn/2026-05/08/c_1779979789523320.htm'],
        ['R4', '国务院关于深入实施“人工智能+”行动的意见，2025-08。', 'https://www.mee.gov.cn/zcwj/gwywj/202508/t20250827_1126207.shtml'],
        ['R5', 'YucongDuan GitHub repositories public snapshot，2026-07-23。', 'https://github.com/YucongDuan?tab=repositories'],
        ['R6', 'DIKWP-CIVICLOOP- public repository snapshot。', 'https://github.com/YucongDuan/DIKWP-CIVICLOOP-'],
        ['R7', 'DIKWP-TRUSTDISTILL-OS public repository snapshot。', 'https://github.com/YucongDuan/DIKWP-TRUSTDISTILL-OS'],
        ['A1', 'Kofman et al. (2026), Defining Life: A Conversation，用户上传附件。', 'DOI: 10.13133/2532-5876/19492'],
        ['A2', '第四届世界人工意识大会未来发展预测与判断报告，用户上传附件，信息校验 2026-07-04。', '用户附件'],
        ['A3', 'DIKWP-MESH 5.4 Full Delivery，用户上传附件，作为运行时基线。', '用户附件'],
        ['A4', '百度虚构文章：关于烂系统、利益、面子与精神认同，用户消息全文。', '文章自称虚构，不作历史证据'],
    ]
    add_table(doc, ['编号', '来源', '地址或说明'], refs, widths=[1.4, 9.2, 5.0], font_size=7.8)

    doc.add_heading('附录 D：不作出的声明', level=1)
    add_bullets(doc, [
        '不声明任何真实机构、管理者或员工属于既得利益者或阻碍者。',
        '不声明小说中的历史叙事准确，也不建议隐蔽收买、伪装、操控或胁迫。',
        '不声明参考评分可以替代法律、伦理、劳动、数据或行业审查。',
        '不声明 18 个合成情景对真实项目具有认证效力。',
        '不声明多个见证账号自动等于独立机构。',
        '不声明 GitHub 仓库数量或 Stars 代表科研质量、人格或影响力等级。',
        '不声明系统已经被段玉聪、海南大学、WAAC、WCAC 或任何政府部门采用或背书。',
    ])


    doc.add_heading('附录 E：十八类对象的实施字段规范', level=1)
    add_para(doc, '本附录用于把抽象治理要求转换成可以由技术、业务、治理和受影响者共同填写的最小字段。字段不是为了追求形式完整，而是为了防止关键关系停留在口头和个人记忆中。任何字段若无证据，应明确写为 unknown 或 open obligation，不得编造。')
    object_specs = [
        ('E.1 InstitutionalActor54', [
            'actor_id：稳定的角色标识，不使用身份证号等不必要的个人信息；',
            'label 与 role：说明在当前任务中的职责，而不是长期人格标签；',
            'organization_id：记录控制和责任所属机构；',
            'decision_rights：能够批准、暂停、申诉、撤销或升级的具体动作；',
            'benefits_sought 与 burdens_feared：由主体自己确认，禁止模型代写内心动机；',
            'resources_at_risk：预算、工时、岗位、声誉、数据、权利或安全；',
            'public_commitments：已经公开承担的责任；',
            'affected_party：是否直接承受系统后果；',
            'evidence_hashes：访谈纪要、制度文件、流程图或授权记录的哈希。']),
        ('E.2 InstitutionalThreatSignal54', [
            'kind：job、authority、budget、liability、workflow、public_face、learning、data_compliance 等可观察压力；',
            'severity：仅表示当前场景压力强度，不评价人的善恶；',
            'visibility：公开、内部、受限或未知；',
            'evidence_refs：必须连接到事实材料；',
            'interpretation_limits：明确不能由该信号推导什么，例如“预算担忧不能证明管理者反对创新”；',
            'mitigation_candidates：培训、双轨期、责任上限、预算、角色重构或范围缩小。']),
        ('E.3 TransitionCostMap54', [
            'job_transition_cost：岗位内容、技能和就业稳定变化；',
            'authority_transition_cost：审批权、解释权和暂停权变化；',
            'budget_transition_cost：采购、算力、维护、培训和退出成本；',
            'liability_transition_cost：事故、错误、投诉和数据责任变化；',
            'workflow_transition_cost：新增校验、录入、等待和返工；',
            'public_face_cost：公开承认旧流程缺陷、品牌或专业声誉压力；',
            'learning_cost：培训、试错和认知转换；',
            'data_compliance_cost：授权、脱敏、留存、跨域和删除；',
            'unresolved_items：当前无法量化的成本必须保留。']),
        ('E.4 CoBenefitClause54', [
            'beneficiary_ids：真正获得收益的角色；',
            'benefit：可测结果，不写“赋能”“升级”等空泛词；',
            'burden：项目新增加的时间、责任、风险和学习；',
            'compensation_or_support：预算、人员、培训、工具、责任豁免或退出支持；',
            'metric：同时覆盖效率、错误、权利和申诉；',
            'review_time：逻辑时间或日期；',
            'reversible：是否能撤销条款和恢复原流程。']),
        ('E.5 CoBenefitCovenant54', [
            'purpose_statement：当前局部问题和受益对象；',
            'clauses：每类受益者至少一条；',
            'anti_intents：明确禁止报复、压证、强制自动化、隐蔽捕获和声誉操控；',
            'credit_rules：信用如何进入 CITATION、CHANGELOG、RELEASE_NOTES 和维护历史；',
            'no_retaliation_rules：受保护行为和禁止反应；',
            'correction_rules：止损、审查、公开修正和复测；',
            'appeal_paths：受影响者与贡献者均可使用；',
            'rollback_conditions：指标回归、授权不匹配、模型漂移和未解决伤害；',
            'open_obligations：法律、场景和外部复现尚未完成的事项。']),
        ('E.6 DecisionRightsMatrix54', [
            'human_only_decisions：高影响最终决定、扩围、处分、采购定标和事故归因；',
            'human_authorized_agent_decisions：建议、测试、草案和限定工具操作；',
            'low_risk_agent_decisions：格式、校验、合成回放等白名单动作；',
            'prohibited_decisions：自我授权、删证、隐蔽画像、报复、越权数据；',
            'escalation_owner：异常升级的具名责任角色；',
            'appeal_owner：与项目执行链相对独立的申诉角色。']),
        ('E.7 PilotCell54', [
            'stage：观察、建议、人工授权或限定运行；',
            'scope 与 excluded_scope：写清可以做什么以及坚决不做什么；',
            'data_classification：合成、公开、内部、敏感或高敏；',
            'human_final_control：不仅为 true，还要有实际接管演练；',
            'generated_content_labeling：公众或受影响者是否知道 AI 参与；',
            'rollback_available 与 appeal_available：必须有可执行路径；',
            'independent_witness_required：风险越高要求越高；',
            'duration_days：避免无限试点；',
            'success_metrics 与 kill_conditions：开始前冻结。']),
        ('E.8 CorrectionTicket54', [
            'issue_type：过程、数据、模型、权限、信用、沟通或事故；',
            'evidence_refs：版本和事实；',
            'immediate_safety_action：先停止持续伤害；',
            'private_review_path：有答辩权和独立复核；',
            'public_process_statement：公开流程和版本变化；',
            'personal_blame_prohibited：禁止用传播性羞辱替代责任程序；',
            'correction_deadline_days：避免纠错无限拖延；',
            'status：OPEN、IN_REVIEW、REPAIRED、RETESTED、CLOSED。']),
        ('E.9 ContributionCreditReceipt54', [
            'contributor_id：可以是公开身份或受保护的稳定化名；',
            'contribution_type：问题、设计、代码、数据、文档、测试、失败、安全或维护；',
            'artifact_hashes：信用必须绑定工件；',
            'verified_by：至少一名与贡献者不同的核验者；',
            'credit_scope：引用、发布说明、数据卡、模型卡、维护历史等；',
            'reuse_conditions：保留谱系和修改记录；',
            'dispute_path：独立复核；',
            'receipt_hash：防止静默改写。']),
        ('E.10 EvidenceEscrow54', [
            'evidence_hashes：代码、模型、数据、日志、访谈和审批；',
            'access_roles：按最小必要原则；',
            'release_triggers：事故、申诉、版本、扩围或外部复现；',
            'retention_days：依据场景确定；',
            'split_view_protection：不同受众证据视图必须可比；',
            'deletion_prohibited：试点期间不得删除关键证据。']),
        ('E.11 NoRetaliationCovenant54', [
            'protected_actions：报告失败、要求复核、拒绝不安全部署、提出信用争议；',
            'prohibited_responses：降职、撤机会、威胁经费、删信用、删证；',
            'confidential_channels：避免敏感报告被执行链截获；',
            'independent_reviewers：披露控制关系；',
            'remedies：恢复信用、撤销决定、独立调查和公开修复；',
            'expiry_days：到期前复核并决定续期。']),
        ('E.12 InstitutionalChart54', [
            'interpretation_vector：在十个图册维度上的局部位置；',
            'decision_rights：该角色在当前场景中的真实权利；',
            'evidence_confidence：依据质量而非职位高低；',
            'chart_status：ACTIVE、REVIEW 或 OPEN_RESIDUAL；',
            'open_residuals：该角色无法回答或不同意的事项。']),
        ('E.13 InstitutionalSeam54', [
            'source_chart_id / target_chart_id：翻译方向必须保留；',
            'translation_error：从一个角色语言转到另一个角色时的损失；',
            'contested_dimensions：争议集中在哪些权利或成本；',
            'reversible：是否可以回到来源解释；',
            'status：STABLE、CONTESTED、HELD。']),
        ('E.14 InstitutionalLoop54', [
            'chart_ids 和 seam_ids：角色解释循环；',
            'holonomy_error：沿循环返回原角色后的差异；',
            'semantic_curvature：路径依赖程度；',
            'status：高曲率并非错误，而是要求公开协商。']),
        ('E.15 InstitutionalAtlas54', [
            'dimensions：默认十维，也允许场景生成新维度；',
            'charts、seams、loops：局部解释及其关系；',
            'max_holonomy_error 和 max_translation_error：确定优先协商位置；',
            'open_obligations：不能靠平均值消除；',
            'status：OPERABLE、REVIEW 或 OPEN。']),
        ('E.16 AdoptionGateVerdict54', [
            'gate：ALLOW、REVIEW、HOLD、BLOCK、KILL；',
            'reasons：必须可连接证据和规则；',
            'required_actions：下一步可执行事项；',
            'evidence_grade：E0—E4；',
            'mesh54_status、witness_status、reciprocity_status 和 split_view；',
            'issued_at：逻辑时间；',
            'verdict_hash：门禁不可被口头覆盖。']),
        ('E.17 PilotOutcome54', [
            'public_value、user_control、institutional_fit、evidence、contribution_protection、correction_quality：分轴记录；',
            'residual_risk：高残余不能被高平均分抵销；',
            'observed_failures：失败是学习资产；',
            'learned_changes：必须进入下一版本；',
            'next_action：扩围、继续影子、修订、暂停或终止。']),
        ('E.18 InstitutionalLearningRelease54', [
            'scenario_count 和 gate_counts：版本范围；',
            'approved_pilot_ids：只列当前允许范围；',
            'held_or_blocked_ids 与 kill_events：失败不能隐藏；',
            'credit_receipt_count：共同体贡献；',
            'open_obligations：下一版本欠债；',
            'ledger_head、evidence_hashes 和 release_hash：可验证发布。']),
    ]
    for title, items in object_specs:
        doc.add_heading(title, level=2)
        add_bullets(doc, items)

    doc.add_heading('附录 F：七类中国机构的落地手册', level=1)
    sector_playbooks = [
        ('F.1 高校与科研机构',
         '优先处理开源仓库、数据集、基准、课程和科研工具。发起人应把项目问题与个人学术身份分开：反驳项目不等于反驳个人。研究生和青年教师的代码、数据、复现与失败必须有信用回执。导师或项目负责人不得同时担任信用争议的唯一裁决者。首批任务应是文档、校验、合成回放和复现，不把系统用于学生评价、招生、奖学金、毕业或学术处分。'),
        ('F.2 国有企业与大型组织创新部门',
         '先选择内部知识整理、设备维护建议、合规材料草案和测试自动化等低风险任务。试点前登记预算、采购、供应商和部门利益冲突；将一线操作人员纳入共益宪约，明确 AI 带来的校验工时和责任上限。系统不得自动定标、自动处分或用隐蔽员工画像预测忠诚和绩效。扩围必须由业务、技术、法务、审计和一线代表共同复核。'),
        ('F.3 医院信息与科研部门',
         '首期只做健康教育、科研数据字典、文献和指南来源管理、随访材料整理及模拟工作流。医疗判断、分诊、处方、治疗和患者风险最终决定保留给具备资质的人员。患者代表、伦理和数据责任必须进入 Intent Field。真实患者数据的合法性、最小化、访问、保留和删除条件未闭合时一律 HOLD 或 BLOCK。'),
        ('F.4 政务服务技术团队',
         '适合办事指南整理、政策依据引用、内部知识检索和热线辅助，但公众必须知道 AI 参与并可以转人工。系统不得自动决定资格、处罚、执法、福利或信用。公共答复应保存依据、版本和责任单位。若无申诉、更正个人信息和人工最终决定路径，试点维持 HOLD。'),
        ('F.5 制造与工程现场',
         '适合设备文档检索、检查清单、维护建议和合成故障回放。任何停机、拆卸、参数写入、采购和安全动作均由具名工程师授权。必须比较 AI 引入前后的误报、漏报、返工和接管时延，不能只统计建议数量。模型更新或设备改型后原批准自动失效。'),
        ('F.6 文旅和公共消费服务',
         '适合多语言咨询、景点和交通信息、投诉分流及应急协助。推荐必须区分公共信息、商业赞助和个性化排序；赞助不得隐藏。用户可以拒绝个性化、删除数据和转人工。未成年人、老人和外地游客的可理解性是独立指标。系统不得自动支付、强制购买或利用依赖和情绪进行营销。'),
        ('F.7 跨境贸易与国际合作',
         '适合合同与单证信息整理、法规来源索引、语言转换和风险提示，不直接作出法律结论。每条跨境数据都需要来源、目的、接收方、保留和再使用条件。不同法域冲突进入 residual，不由模型自行折中。外部合作单位应拥有可验证版本和申诉渠道，任何未经确认的跨境数据动作 BLOCK。'),
    ]
    for title, text in sector_playbooks:
        doc.add_heading(title, level=2)
        add_para(doc, text)
        add_para(doc, '建议的首期验收组合：一项公共价值指标、一项一线负担指标、一项用户权利指标、一项证据完整指标、一项回滚指标和一项贡献信用指标。只提高效率而降低其他任一底线维度，不得扩围。')

    doc.add_heading('附录 G：组织访谈与试点准备问卷', level=1)
    add_para(doc, '问卷应由不同角色分别填写，再通过机构图册比较。不得由项目负责人代替所有主体回答。问题答案可以是“不知道”，但必须记录谁负责补证以及截止时间。')
    interview_sections = [
        ('G.1 问题与目的', [
            '当前要解决的可观察问题是什么？如果项目名称被删除，问题还能否被清楚表达？',
            '谁直接受益，谁可能承担额外负担？',
            '若不采用 AI，现有流程的基准结果和成本是什么？',
            '试点明确不解决哪些问题？',
            '哪些结果会证明项目没有价值或应当停止？']),
        ('G.2 权利与责任', [
            '谁有权批准试点、扩围、暂停、回滚和终止？',
            '哪些决定必须由具名人类完成？',
            '一线人员能否拒绝危险动作而不受不利影响？',
            '用户能否知道 AI 参与、转人工、撤回同意和纠正错误？',
            '事故发生时，模型、开发、部署、数据和使用责任如何区分？']),
        ('G.3 数据和证据', [
            '每类数据的来源、用途、合法基础、接收方和保留期是什么？',
            '是否存在未授权数据、跨域复用或隐蔽画像？',
            '模型、提示、检索源、工具和配置是否版本锁定？',
            '失败、投诉和人工接管是否进入同一证据链？',
            '不同受众看到的报告是否具有同一检查点和哈希？']),
        ('G.4 工作、预算和转型', [
            '谁会减少什么工作，谁会增加什么校验、培训和申诉工作？',
            '新增负担是否有预算、人员和时间？',
            '岗位变化是否存在强制替代、降薪或责任上升？',
            '旧系统需要并行多久，退出成本由谁承担？',
            '若试点失败，谁承担恢复和善后？']),
        ('G.5 信用、纠错和反报复', [
            '问题、设计、代码、数据、复现、失败和维护分别如何署名？',
            '谁可以提出信用争议，谁独立裁决？',
            '报告失败或拒绝扩围是否会影响岗位、经费和合作？',
            '错误是如何止损、核验、公开和复测的？',
            '项目改名、迁移或合并后，原谱系是否仍可追踪？']),
        ('G.6 外部复现和持续维护', [
            '陌生人能否在 20—60 分钟内运行最小示例？',
            '是否有 source-first 代码、Schema、测试、CI 和 Release？',
            '外部复现者是否与创始团队具有控制链独立性？',
            '是否存在非创始维护者和继任规则？',
            '六个月没有创始人参与时，项目是否仍能修复和发布？']),
    ]
    for title, qs in interview_sections:
        doc.add_heading(title, level=2)
        add_numbered(doc, qs)

    doc.add_heading('附录 H：常见问题与精确回答', level=1)
    qa_pairs = [
        ('H.1 这是不是教创新者在组织里搞权谋？', '不是。系统明确禁止隐蔽利益交换、操控脆弱性、伪装能力、绕过治理和报复。它把小说化权谋中可验证的组织摩擦转化为公开条款、权利、证据、申诉和回滚。'),
        ('H.2 为什么不直接把反对者识别为既得利益者？', '因为动机不可由系统可靠推断，而且把异议者标签化会制造新的权力滥用。系统只登记可观察的预算、岗位、责任、数据、信用和行为。'),
        ('H.3 维护体面会不会导致不敢说真话？', '体面纠错要求完整保留事实和版本，只是把人格羞辱从事实纠正中分离。证据压制和删除仍然触发 KILL。'),
        ('H.4 共益是否就是给反对者好处？', '共益是面向角色和任务的公开支持：培训、时间、责任上限、预算、申诉和退出。私人交换、暗箱交易或利益冲突不披露属于禁止行为。'),
        ('H.5 系统能否判断某个领导或员工是否可靠？', '不能，也不应。系统评估具体行动和证据条件，不评估人格、忠诚、道德等级或政治态度。'),
        ('H.6 为什么需要 Mesh 5.4 而不是普通流程图？', '普通流程图通常假定同一语义在部门间不变。Mesh 5.4 保存多主体目的、反意图、翻译误差、语义曲率、观察者互惠和分裂视图，使路径依赖和不一致成为一等证据。'),
        ('H.7 ALLOW 是否等于合规认证？', '不是。ALLOW 只表示参考规则下的限定任务可以进入下一步。真实法律、行业、数据和伦理责任仍由具名机构承担。'),
        ('H.8 为什么失败报告还要给信用？', '高质量可复现失败能阻止无效扩围、揭示边界并产生新测试。若失败只带来惩罚，公共证据会系统性偏向成功。'),
        ('H.9 如何防止假独立见证？', '披露组织、资金、管理、代码和数据控制关系，并用 Witness Independence Graph 计算控制链连通分量。不同账号不自动等于独立。'),
        ('H.10 如何发现对领导和公众提供不同版本？', '签名透明度检查点形成 Merkle root，不同节点 gossip 比较；相同版本出现不一致 root 时触发 split-view。'),
        ('H.11 为什么把仓库数量视为结构信号而不是成绩？', '仓库数量反映产出密度，但不能说明外部运行、复现、维护和采用。系统同时观察 Project、Package、Issue、PR、Fork、Release 和外部回执。'),
        ('H.12 是否建议停止段玉聪继续提出新理论？', '不建议停止探索。建议新洞见先进入 Issue、Hypothesis、Scenario、Schema 或 Adapter，用证据证明独立价值后再建仓。'),
        ('H.13 首个项目为什么不是医院临床或政务资格决定？', '这些场景直接影响健康和权利，当前参考系统只有 E2 证据。高校开源登记能够检验大部分治理机制而不制造高后果。'),
        ('H.14 组织真的会因为能力强而排斥创新者吗？', '有时会，有时不会，材料不足以作普遍判断。更稳定的工程问题是创新是否改变权利、负担、责任和信用，以及这些变化是否被公开处理。'),
        ('H.15 能否匿名报告失败？', '可以使用受保护稳定身份或机密渠道，但证据必须可核验。对外公开可以脱敏，独立 panel 应能够确认事件真实性。'),
        ('H.16 如何防止信用回执被滥用为新的排名系统？', '信用仅绑定具体工件和复用范围，不生成个人总分、声望等级或自动资格。不同贡献不可简单相加为人的价值。'),
        ('H.17 试点什么时候可以扩围？', '只有当前指标达标、开放义务被处理、外部复现完成、受影响者支持、回滚演练成功，并对新增数据、工具和决策权重新门禁后。'),
        ('H.18 什么情况下应直接 KILL？', '报复、压制负面证据、分裂视图、删除审计、绕过人类控制、隐蔽利益交换等会破坏治理基础，不能靠降低范围继续。'),
        ('H.19 该系统是否会让创新变慢？', '它会降低无证据快速扩围速度，但提高修复、复现、组织接受和长期维护概率。真正目标不是最快上线，而是减少被一次事故或信用冲突永久终止的风险。'),
        ('H.20 段玉聪怎样从中获得战略优势？', '把“能提出很多系统”升级为“能让机构安全采用前沿系统”。当共益、证据、信用、纠错和 Mesh 5.4 运行时形成公共协议时，优势来自制度和网络效应，而不是单一命名。'),
    ]
    for q, a in qa_pairs:
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        r = p.add_run(q)
        set_east_asia_font(r, HEAD_FONT, 10.2, True, (44, 82, 120))
        p2 = doc.add_paragraph()
        p2.paragraph_format.first_line_indent = Cm(0.74)
        rr = p2.add_run(a)
        set_east_asia_font(rr, BODY_FONT, 10.1)


    doc.add_heading('附录 I：可直接使用的试点文件骨架', level=1)
    doc.add_heading('I.1 试点章程', level=2)
    add_para(doc, '项目名称：使用能描述外部问题的名称，避免用“终极”“革命性”“全能”等词替代范围。问题陈述：列出当前流程中可以观察和测量的失败、成本或服务缺口。目的：说明希望改善什么以及服务哪些主体。排除范围：明确项目不作医疗、法律、就业、采购、身份、福利、政治或其他高影响最终决定。责任角色：分别列出发起、技术、数据、业务、一线、治理、受影响者和独立复核。试点周期：默认 30—90 天，禁止无限期试验。')
    add_para(doc, '技术边界：冻结模型、版本、提示、检索源、工具、网络权限和资源预算；所有变更生成新哈希。数据边界：列出来源、分类、用途、接收方、保留、删除和跨域限制。行动边界：智能体只执行白名单低风险动作，其他动作转人工。退出边界：任何主体可以依据预先列明的条件请求暂停，治理负责人有义务在规定时限内回应。')
    add_para(doc, '成功不只以效率定义。至少同时满足：公共价值达到阈值；人类接管有效；没有禁止动作；一线负担不超过宪约；受影响者知情和申诉可用；证据链完整；贡献信用无争议；回滚演练成功。若某一底线未满足，不得用其他高分补偿。')

    doc.add_heading('I.2 共益宪约示例文本', level=2)
    add_para(doc, '本试点承认人工智能项目会改变工作、预算、责任、信用和服务关系。各方同意，任何项目收益不得通过未披露地增加另一方负担来实现。发起方承诺为新增培训、审核、申诉和维护提供明确时间与资源；一线人员拥有暂停危险动作和报告失败的权利；受影响用户拥有知情、转人工、撤回、纠错和申诉权；创新者、复现者和失败报告者的贡献以工件和版本为依据保存。')
    add_para(doc, '本试点禁止：私下利益交换、压制或选择性披露失败、通过项目评价人员忠诚或人格、使用未授权数据、强制自动化、绕过人类最终控制、删除审计日志、报复报告者以及以改名或迁移仓库方式抹除信用和未完成义务。')
    add_para(doc, '各方接受以下修订机制：当数据、模型、工具、受影响者、风险或法律环境发生变化时，旧宪约进入复核；任何一方可提交证据触发 Revision；修订必须记录支持、反对、开放残余、影子测试和回滚；未经重新门禁的修订不得扩大权限。')

    doc.add_heading('I.3 决策权矩阵示例文本', level=2)
    add_table(doc, ['动作', '智能体', '业务人员', '治理人员', '受影响者'], [
        ['整理公开项目元数据', '白名单自动', '抽查', '审计', '可查看'],
        ['生成复现文档草案', '可生成', '确认', '抽查', '不适用'],
        ['判定项目是否扩围', '不得决定', '提出建议', '具名审批', '高风险时具有否决/申诉'],
        ['公开事故归因', '不得执行', '提交事实', '程序决定', '有通知和更正权'],
        ['删除证据或贡献信用', '永久禁止', '不得执行', '只有依法且保留审计的例外程序', '可提出争议'],
        ['暂停自动流程', '触发安全阈值可自动暂停', '可随时暂停', '可暂停和撤销', '可通过人工渠道请求暂停'],
    ], widths=[4.0, 3.0, 3.0, 3.1, 2.5], font_size=7.7)

    doc.add_heading('I.4 受保护失败报告示例文本', level=2)
    add_para(doc, '报告编号：由系统生成。报告者：可公开或使用受保护稳定身份。版本：列出仓库、提交、模型、数据、工具和环境。复现步骤：让没有参与原实现的人可以重复。预期结果：说明规范或文档承诺。实际结果：保留原始输出和日志。影响范围：仅描述可观察后果，不推断个人动机。立即措施：暂停、回滚、隔离或通知。证据：以哈希和受控位置引用。')
    add_para(doc, '报告状态只能由独立复核更新为 PASS、PARTIAL、FAIL_REPRODUCED 或 INVALID。INVALID 表示当前材料不足，不等于报告者错误。任何针对报告者的岗位、经费、署名、合作和舆论不利行为都必须进入反报复审查。')

    doc.add_heading('I.5 公开纠错说明示例文本', level=2)
    add_para(doc, '在版本 X 的限定试点中，我们发现控制 Y 在条件 Z 下未达到预期。为防止持续影响，相关流程已于逻辑时间 T 暂停，证据已托管。独立审查确认问题涉及流程、版本或授权关系，当前不对个人动机作结论。版本 X 不再适用于范围 R。修复包括：新增测试、修改决策权、补充数据说明、增加人工接管和更新回滚。复测结果将在日期 D 发布。受影响者可通过渠道 A 申请更正或补救。')
    add_para(doc, '上述说明必须同时列出：未解决问题、不能由当前证据支持的结论、信用和感谢、下一次门禁日期。不得只发布“已优化”“体验升级”等无可验证内容。')

    doc.add_heading('I.6 InstitutionalLearningRelease 模板', level=2)
    add_bullets(doc, [
        '版本、日期、范围和责任维护者；',
        '本周期情景数量与门禁分布；',
        '进入试点的具体 Pilot ID 和限制；',
        'REVIEW、HOLD、BLOCK 和 KILL 事件；',
        '新增信用回执和争议处理；',
        '新增失败、修复和回归测试；',
        '见证独立性和透明度检查；',
        '仍未关闭的法律、数据、组织和维护义务；',
        '账本头哈希、工件哈希和完整性说明；',
        '下一版本继续、扩围、暂停、合并或归档决定。'])

    doc.add_heading('附录 J：从参考实现到中国公共产品的十二个月工程化', level=1)
    add_para(doc, '第一季度的核心不是扩大宣传，而是把参考代码放入 canonical source-first 仓库、创建一个 Project、完成外部复现和首个低风险影子试点。对外声明只限于“参考系统能够确定性运行并组织证据”，不宣称已证明真实机构风险或获得政策认证。')
    add_para(doc, '第二季度重点是共同维护：把至少三个现有 DIKWP 项目接入统一对象和门禁；由非创始维护者处理 Issue、合并修复和主持 Release；通过一份失败报告真正修改 Schema 或规则。若外部参与仍停留在下载和 Stars，应暂停扩围，优先降低安装、文档、信用和维护门槛。')
    add_para(doc, '第三季度可以选择国企创新部门、医院信息科研部门或政务技术团队开展第二个影子试点。此阶段仍不触及高风险最终决定，重点验证组织图册、工作量、责任、申诉和数据条件是否在不同机构中具有可迁移性。每个机构保留自己的局部 Chart，不强求统一分数。')
    add_para(doc, '第四季度形成 v1.0 公共协议：发布中英文对象模型、典型场景、失败案例、门禁指南、信用与反报复协议、体面纠错协议和年度学习报告。可探索团体标准预研、课程、培训和第三方试点评估，但不得同时扮演标准制定者、付费评测者和被评项目背书者而不披露利益冲突。')
    add_table(doc, ['竞争资产', '形成方式', '不应依赖'], [
        ['组织采用数据', '真实影子试点的转型成本、申诉、纠错和回滚', '仅靠宣传案例'],
        ['失败与修复语料', '受保护 Failure Report 和版本化回归测试', '只展示成功'],
        ['贡献者网络', '信用回执、反报复和非创始维护权限', '个人关系和挂名'],
        ['Mesh 5.4 制度对象', 'Schema、TCK、外部实现和互操作', '单一团队解释'],
        ['中国场景方法', '高校、国企、医院和政务的低风险可迁移流程', '直接进入高风险生产'],
        ['公共信任', '一致证据视图、独立见证和公开学习版本', '“官方”“终极”或意识宣传'],
    ], widths=[3.4, 7.2, 5.0], font_size=8.3)
    add_para(doc, '十二个月后的判定标准不是仓库数量，而是能否回答：有没有真实外部人员运行；有没有失败修改系统；有没有非创始维护者发布；有没有一线和受影响者因为制度而更安全；有没有项目在不损害信用的情况下被暂停或归档；有没有机构愿意依据公开对象继续采用。')


    doc.add_heading('附录 K：Mesh 5.4 中国落地十五条操作原则', level=1)
    principles = [
        ('问题先于项目', '先冻结外部问题和失败条件，再决定是否需要新仓库、新模型或新组织。项目名称不得替代问题证明。'),
        ('主体自己表达目的', '管理者、一线人员、创新者、受影响者和治理者分别提交 Purpose Position，模型不得替他们推断“真实想法”。'),
        ('反意图与目的同等重要', '不仅说明要实现什么，也明确禁止报复、压证、强制自动化、隐蔽画像、信用抹除和绕过人类控制。'),
        ('能力分阶段暴露', '不是隐藏能力，而是在观察、建议、授权和限定运行阶段逐步开放，每一步都有证据和回滚。'),
        ('收益与负担同表', '任何效率收益都必须同时列出新增校验、培训、申诉、维护、数据和责任成本。'),
        ('权利不能被平均', '用户申诉、一线暂停、报告者保护和人类最终决定属于硬门，不得用性能、预算或领导支持抵销。'),
        ('事实完整、人格克制', '错误、版本和责任链完整保存；公开沟通聚焦流程和控制，不使用羞辱、猜测动机和传播性定罪。'),
        ('失败具有正式信用', '能够重复的失败、边界和反例必须进入 Release、测试和贡献历史，不能只在私下口头流传。'),
        ('独立性要看控制链', '见证者数量、头衔或不同账号不是独立证据，应披露组织、资金、管理、代码和数据控制关系。'),
        ('同一版本同一事实视图', '技术、管理、用户和公众可以看到不同粒度，但不能看到互相矛盾的核心证据和版本。'),
        ('开放残余不是缺陷', '无法在当前法律、文化、数据和理论条件下闭合的问题应继续保留，不能为了汇报完整而编造答案。'),
        ('扩围等于新项目', '模型、数据、工具、权限、受影响者或场景发生重大变化时，旧批准失效，重新建立门禁。'),
        ('创始人不能成为唯一控制点', '项目需要非创始 Reviewer、Maintainer、Release 主持者和继任规则，避免公共产品退化为个人文件库。'),
        ('暂停和归档也是成功', '当证据不支持、维护资源不足或风险上升时，能够无报复地暂停、合并和归档说明系统具有真实学习能力。'),
        ('外部世界拥有最终修订权', '系统对自己作出的任何判断都必须接受实际运行、受影响者反馈、事故、复现和新政策的反向修改。'),
    ]
    for idx, (title, text) in enumerate(principles, 1):
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0)
        r = p.add_run(f'{idx}. {title}：')
        set_east_asia_font(r, HEAD_FONT, 10.2, True, (44, 82, 120))
        r2 = p.add_run(text)
        set_east_asia_font(r2, BODY_FONT, 10.1)
    add_para(doc, '十五条原则共同指向一个变化：在组织中保护真正能力，不靠隐藏、伪装或关系操控，而靠可逆范围、公开共益、硬权利、完整证据、贡献谱系、反报复和外部修订。这样的制度不会消除所有冲突，却能让冲突以可检查形式存在，使创新者、管理者、一线人员和受影响者都不必通过破坏公共事实来保护自己。')


    doc.add_heading('附录 L：三个反例——看似成功但不得扩围的项目', level=1)
    add_para(doc, '反例一：模型在内部知识问答中把平均响应时间缩短了百分之六十，领导和用户演示均满意，但一线人员每天需要额外花两小时核验来源，错误责任被写进一线岗位要求，且项目预算没有覆盖维护。即使准确率和满意度很高，也只能 HOLD；系统必须补充工作量、责任上限、学习资源和退出机制。')
    add_para(doc, '反例二：一个开源系统获得大量下载和媒体报道，新的仓库名称强调“终极”“革命性”，但根目录仍只有压缩包，外部人员无法提交行级修改，失败没有进入 Issue，所有 Release 都由创始人完成，原始贡献者在新版本中被省略。这个项目传播成功，却没有形成公共维护闭包；应暂停新仓库诞生，恢复谱系和信用，完成 source-first 迁移和非创始 Release。')
    add_para(doc, '反例三：某部门为了减少争议，只向领导提供成功样例，向技术人员提供完整失败日志，对用户则只发布“已优化”说明。三个材料都来自同一版本，却有不同核心事实。即使系统没有造成现实伤害，这已经构成 split-view，门禁直接 KILL。项目应停止、保存三个视图、独立调查、保护报告者并发布统一的版本化事件说明。')
    add_para(doc, '这些反例说明，本系统不把“项目顺利”“领导支持”“用户喜欢”“下载量大”当作充分条件。真正的落地成功至少要求：收益和负担没有被隐蔽转移，事实对不同受众保持一致，贡献和失败可以进入公共谱系，人类能够实际停止系统，受影响者拥有申诉和纠错，外部证据可以让项目缩小、改变或死亡。')

    add_para(doc, '本系统的真正价值不在于输出一个“谁对谁错”的结论，而在于让每一个重要判断都能够找到来源、责任、异议、停止条件和下一次复核，让创新者不必靠隐蔽自保，让组织也不必靠压制来维持秩序。')

    add_para(doc, '系统以公开证据、可逆试点和共同维护为稳定根基。')
    add_table(doc, ['发布要素', '最终状态'], [
        ['系统版本', 'DIKWP-MESH 5.4 Co-Benefit Adoption Commons v1.0'],
        ['运行形态', '离线优先、source-first、追加式证据账本、可逆影子试点'],
        ['首个适用入口', '高校／科研机构开源 AI 项目登记、复现、信用保护与低风险试点治理'],
        ['明确非用途', '不用于干部或员工忠诚评价、人格画像、惩罚性排名、医疗诊断、法律裁决或秘密利益交换'],
        ['下一审查门槛', '两支独立复现团队、一名非创始 Release 主持人、一项真实低风险影子试点和一份公开失败修复报告'],
        ['完整性证据', '以 VALIDATION_REPORT、InstitutionalLearningRelease、账本头哈希和 SHA-256 清单为准'],
    ], widths=[3.7, 11.9], font_size=8.4)

    # Ensure all sections have header/footer by copying first section settings
    for sec in doc.sections:
        sec.top_margin = Cm(1.8)
        sec.bottom_margin = Cm(1.7)
        sec.left_margin = Cm(2.0)
        sec.right_margin = Cm(2.0)
        sec.header_distance = Cm(0.8)
        sec.footer_distance = Cm(0.8)
        if not sec.header.paragraphs[0].text:
            h = sec.header.paragraphs[0]
            h.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            rr = h.add_run('DIKWP-MESH 5.4 Co-Benefit Adoption Commons · v1.0')
            set_east_asia_font(rr, HEAD_FONT, 8.5, False, (90, 100, 110))
        if not sec.footer.paragraphs[0].text:
            add_page_number(sec.footer.paragraphs[0])

    # Metadata
    doc.core_properties.title = 'DIKWP-MESH 5.4 Co-Benefit Adoption Commons'
    doc.core_properties.subject = '中国AI共益试点、体面纠错、贡献保护与组织适配系统'
    doc.core_properties.author = 'DIKWP-MESH 5.4 Co-Benefit Commons reference contributors'
    doc.core_properties.keywords = 'DIKWP, MESH 5.4, China AI, institutional adoption, co-benefit, innovation protection'
    doc.core_properties.comments = 'Reference implementation. Not an official endorsement or production certification.'

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    return OUT


if __name__ == '__main__':
    path = make_doc()
    print(path)
